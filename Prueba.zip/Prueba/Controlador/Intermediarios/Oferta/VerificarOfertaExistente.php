<?php
// Verificar ofertas existentes
require '../../../Modelo/BD/ConexionBD.php';
require '../../../Modelo/BD/ModeloBD.php';
require '../../../Modelo/DAOs/OfertaDAO.php';

// ----------------------------------------------------------------------
// Autor: Miguel Angel Lara Hermosillo 
//middleware/controllerAuth.php
require_once __DIR__. '/../../middleware/controllerAuth.php';
requireRole(["Administrador", "JefeDeCarrera"]);
// ----------------------------------------------------------------------

header('Content-Type: application/json');

$datos = json_decode(file_get_contents("php://input"));

$respuesta = ['existe' => false];

if ($datos) {
    $c = new ConexionBD($DatosBD);
    $conexion = $c->Conectar();
    $dao = new OfertaDAO($conexion);

    $existe = $dao->OfertaYaExiste($datos);
    $respuesta['existe'] = $existe;
}

echo json_encode($respuesta);

<?php
 
// Intermediario para manejar solicitudes de captura de calificaciones
// Recibe datos desde el cliente, procesa la solicitud y delega la lógica al DAO correspondiente.

// Importar clases necesarias para conexión y manejo de la base de datos.
require '../../../Modelo/BD/ConexionBD.php';
require '../../../Modelo/BD/ModeloBD.php';
require '../../../Modelo/DAOs/OfertaDAO.php';

// ----------------------------------------------------------------------
// Autor: Miguel Angel Lara Hermosillo 
//middleware/controllerAuth.php
require_once __DIR__. '/../../middleware/controllerAuth.php';
requireRole(["Administrador", "JefeDeCarrera"]);
// ----------------------------------------------------------------------

header('Content-Type: application/json');

$pidPeriodo = json_decode(file_get_contents("php://input"));

$c = new ConexionBD($DatosBD);
$pdo = $c->Conectar();

// DAO de calificacion
$objDaoOferta = new OfertaDAO($pdo);

    $resultado = $objDaoOferta->ObtenerOfertasAsignadasPorPeriodo($pidPeriodo);

echo json_encode($resultado);
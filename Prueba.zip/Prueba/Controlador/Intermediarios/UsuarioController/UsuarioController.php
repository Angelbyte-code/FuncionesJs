<?php
/**
 * AUTOR: Miguel Angel Lara Hermosillo
 * funcionamiento: En este controlador obtenemos el estado en el que se encuentra el usuario
 * ya que si el estado cambia aun el usuario estando en sesion se se actualiza el estado y se hacen las validaciones correspondientes
 */

// Rutas corregidas según ubicación real del archivo
require_once __DIR__ . "/../../../Modelo/BD/ModeloBD.php";
require_once __DIR__ . "/../../../Modelo/BD/ConexionBD.php";
require_once __DIR__ . "/../../../Modelo/DAOs/EstadoUsuarioDAO.php";


class UsuarioController
{
    private $usuarioDAO;

    public function __construct()
    {
        // Cargar arreglo $DatosBD desde ModeloBD.php
        require __DIR__ . "/../../../Modelo/BD/ModeloBD.php";

        // Crear conexión PDO
        $c = new ConexionBD($DatosBD);
        $pdo = $c->Conectar();

        // Inicializar DAO
        $this->usuarioDAO = new EstadoUsuarioDAO($pdo);
    }

    public function usuarioEstaActivo($idUsuario)
    {
        $estado = $this->usuarioDAO->obtenerEstadoPorID($idUsuario);
        return ($estado === "Activo");
    }
}


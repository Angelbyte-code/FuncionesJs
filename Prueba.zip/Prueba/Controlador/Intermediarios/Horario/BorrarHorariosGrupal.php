<?php

// ----------------------------------------------------------------------
// Intermediario para borrar todos los horarios de un grupo de alumnos.
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/errores.log');
error_reporting(E_ALL);

// Autor: Miguel Angel Lara Hermosillo 
//middleware/controllerAuth.php
require_once __DIR__. '/../../middleware/controllerAuth.php';
requireRole(["Administrador","JefeDeCarrera"]);

// Archivo intermediario que recibe una solicitud del cliente para borrar todos los Horarios de un grupo de alumnos,
// procesa los datos y llama al método del modelo que realiza la eliminación en la base de datos.

// Importación de archivos necesarios para la conexión y la lógica de base de datos.
require '../../../Modelo/BD/ConexionBD.php';
require '../../../Modelo/BD/ModeloBD.php';
require '../../../Modelo/DAOs/HorarioDAO.php';

// Decodificación del JSON recibido desde el cliente. Convierte los datos en un objeto PHP.
$datos = json_decode(file_get_contents("php://input"));

// Respuesta predeterminada en caso de error. Inicializamos la respuesta en un estado de error.
$resultado = ['estado' => 'Error'];

// Instanciamos la clase de conexión a la base de datos y el DAO de Horario.
$c = new ConexionBD($DatosBD);
$conexion = $c->Conectar();
$objDaoHorario = new HorarioDAO($conexion);

try {

    $resultado = $objDaoHorario->BorrarHorariosGrupal($datos);

} catch (PDOException $e) {
    // Capturamos cualquier error relacionado con la base de datos y lo registramos.
    $resultado['mensaje'] = "Ocurrió un problema al comunicarse con la base de datos. Por favor, intente nuevamente más tarde." . $e->getMessage();
    error_log("Excepción PDO al borrar los horarios: " . $e->getMessage());
}

// Enviamos la respuesta al cliente en formato JSON, para que pueda procesarla adecuadamente.
echo json_encode($resultado);


<?php
// Miguel Angel lara Hermosillo
// Fecha: 12-08-2025
/**
Funcionamiento: Controlador que maneja el proceso de inicio de sesión de los usuarios.
 Recibe las credenciales, valida y crea la sesión correspondiente.
 */


header('Content-Type: application/json');

// =========================
// INCLUDES (rutas correctas)
// =========================
require '../../../Modelo/BD/ConexionBD.php';
require '../../../Modelo/BD/ModeloBD.php';
require '../../../Modelo/DAOs/LoginDAO.php';
require '../../../config.php'; //ruta base

session_start();

// Recibir datos por POST 
$idUsuario = $_POST['idUsuario'] ?? '';
$password  = $_POST['password'] ?? '';
$rol       = $_POST['rol'] ?? '';

if ($idUsuario === '' || $password === '' || $rol === '') {
    header("Location: " . BASE_URL . "Vista/login.php?estado=datos_vacios");
    exit;
} 

// Sanitizar
$idUsuario = htmlspecialchars($idUsuario);
$password  = htmlspecialchars($password);
$rol       = htmlspecialchars($rol);


// =========================
// Conexión a BD
// =========================
$c = new ConexionBD($DatosBD);
$pdo = $c->Conectar();

//DAO
$dao = new LoginDAO($pdo);
// Buscamos usuario
$usuario = $dao->login($idUsuario, $password, $rol);

switch ($usuario["estado"]) {

    case "NO_EXISTE":
        header("Location: " . BASE_URL . "Vista/login.php?estado=login_failed");
        exit;

    case "PASSWORD_INCORRECTA":
        header("Location: " . BASE_URL . "Vista/login.php?estado=login_failed");
        exit;

    case "ROL_INCORRECTO":
        header("Location: " . BASE_URL . "Vista/login.php?estado=login_failed");
        exit;

    case "INACTIVO":
        header("Location: " . BASE_URL . "Vista/login.php?estado=user_inactivo");
        exit;

    case "OK":
        $usuario = $usuario["datos"];

         // LOGIN EXITOSO → Crear sesión
        $_SESSION["idUsuario"] = $usuario["claveUsuario"];
        $_SESSION["nombre"]    = $usuario["nombre"];
        $_SESSION["apellido_paterno"] = $usuario["apellidoPaterno"];
        $_SESSION["apellido_materno"] = $usuario["apellidoMaterno"];
        $_SESSION["rol"] = $usuario["rol"];
        header("Location: " . BASE_URL . "Vista/redirect.php");
        exit;
        
        break;

    default:
        header("Location: " . BASE_URL . "Vista/login.php?estado=error");
        exit;
       
}

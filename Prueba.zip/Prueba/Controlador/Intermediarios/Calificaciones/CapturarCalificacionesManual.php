<?php

// Intermediario para manejar solicitudes de captura de calificaciones

require '../../../Modelo/BD/ConexionBD.php';
require '../../../Modelo/BD/ModeloBD.php';
require '../../../Modelo/DAOs/CalificacionDAO.php';
//--------------------------------------------------------------
// Autor: Miguel Angel Lara Hermosillo 
//middleware/controllerAuth.php
require_once __DIR__. '/../../middleware/controllerAuth.php';
requireRole(["Administrador", "Docente" , "JefeDeCarrera"]);
//--------------------------------------------------------------
header('Content-Type: application/json');

$datos = json_decode(file_get_contents("php://input"), true);

$c = new ConexionBD($DatosBD);
$pdo = $c->Conectar();
$objDaoCalif = new CalificacionDAO($pdo);

// Bandera de control
$todoOK = true; 
$errores = [];

foreach ($datos['calificaciones'] as $c) {

    $resultado = $objDaoCalif->AgregarCalificacionManual(
        $c['pidCalif'],
        $c['punidad'],
        $c['pcalificacion'],
        $c['pidParcial'],
        $c['pidHorario']
    );

    // Si algo falla, registras el error y marcas la bandera
    if ($resultado['estado'] !== "OK") {
        $todoOK = false;
        $errores[] = [
            "entrada" => $c,
            "error" => $resultado['mensaje']
        ];
    }
}

// Salida final
if ($todoOK) {
    echo json_encode([
        "estado" => "OK",
        "mensaje" => "Todas las calificaciones fueron guardadas correctamente."
    ]);
} else {
    echo json_encode([
        "estado" => "Error",
        "mensaje" => "Una o más calificaciones no pudieron guardarse.",
        "errores" => $errores
    ]);
}

<?php

require '../../../Modelo/BD/ConexionBD.php';
require '../../../Modelo/BD/ModeloBD.php';
require '../../../Modelo/DAOs/CalificacionDAO.php';
//--------------------------------------------------------------
// Autor: Miguel Angel Lara Hermosillo 
//middleware/controllerAuth.php
require_once __DIR__. '/../../middleware/controllerAuth.php';
requireRole(["Administrador"]);
//--------------------------------------------------------------
header("Content-Type: application/json");

$body = json_decode(file_get_contents("php://input"), true);

$c = new ConexionBD($DatosBD);
$pdo = $c->Conectar();

$dao = new CalificacionDAO($pdo);

$res = $dao->filtrar($body);

echo json_encode($res["datos"]);
exit;

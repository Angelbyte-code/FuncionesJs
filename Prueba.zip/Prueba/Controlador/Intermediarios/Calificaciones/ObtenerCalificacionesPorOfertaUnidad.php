<?php
// Intermediario para manejar solicitudes para obtener calificaciones por estado y unidad
// Recibe datos desde el cliente, procesa la solicitud y delega la lógica al DAO correspondiente.
//--------------------------------------------------------------
// Autor: Miguel Angel Lara Hermosillo 
//middleware/controllerAuth.php
require_once __DIR__. '/../../middleware/controllerAuth.php';
requireRole(["Administrador"]);
//--------------------------------------------------------------
// Importar clases necesarias para conexión y manejo de la base de datos.
require '../../../Modelo/BD/ConexionBD.php';
require '../../../Modelo/BD/ModeloBD.php';
require '../../../Modelo/DAOs/CalificacionDAO.php';

header('Content-Type: application/json');

$datos = json_decode(file_get_contents("php://input"), true);

$c = new ConexionBD($DatosBD);
$pdo = $c->Conectar();

// DAO de calificacion
$objDaoCalif = new CalificacionDAO($pdo);


    $resultado = $objDaoCalif->BuscarCalificacionesPorOfertaUnidad(
        $datos['pidOferta'],
        $datos['punidad'],
    );

echo json_encode($resultado);
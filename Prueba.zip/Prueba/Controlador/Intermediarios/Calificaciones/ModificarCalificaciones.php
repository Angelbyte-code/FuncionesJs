<?php
// Intermediario para manejar solicitudes de búsqueda y modificación de calificaciones.
// Recibe datos desde el cliente, procesa la solicitud y delega la lógica al DAO correspondiente.

// Importar clases necesarias para conexión y manejo de la base de datos.
require '../../../Modelo/BD/ConexionBD.php';
require '../../../Modelo/BD/ModeloBD.php';
require '../../../Modelo/DAOs/CalificacionDAO.php';
//--------------------------------------------------------------
// Autor: Miguel Angel Lara Hermosillo 
//middleware/controllerAuth.php
require_once __DIR__. '/../../middleware/controllerAuth.php';
requireRole(["Docente"]);
//--------------------------------------------------------------
// Obtener los datos enviados en el cuerpo de la solicitud HTTP en formato JSON.
$datos = json_decode(file_get_contents("php://input"), true);

error_log("DEBUG idCalificacion recibido: " . json_encode($datos['idCalificacion']));

// Inicializar la respuesta por defecto con estado de error.
$resultado = ['estado' => 'Error'];

// Crear instancia de conexión y del DAO de parciales.
$c = new ConexionBD($DatosBD);
$conexion = $c->Conectar();
$objDaoCalif = new CalificacionDAO($conexion);

try {
    if (isset($datos['Buscar']) && $datos['Buscar'] === true) {
        $resultado = $objDaoCalif->BuscarCalificacionesPorId($datos['idCalificacion']);
    } elseif (isset($datos['Modificar']) && $datos['Modificar'] === true) {
        $resultado = $objDaoCalif->AgregarCalificacionManual(
            $datos['pidCalif'],
            $datos['punidad'],
            $datos['pcalificacion'],
            $datos['pidParcial'],
            $datos['pidHorario']
        );
    } else {
        $resultado['mensaje'] = "Ocurrió un error al procesar la solicitud. Por favor intenta nuevamente.";
        error_log("Intermediario: Acción no válida recibida (ni Buscar ni Modificar). Datos: " . json_encode($datos));
    }
} catch (Exception $e) {
    $resultado['mensaje'] = "No fue posible completar la operación en este momento. Por favor, intenta nuevamente en unos instantes.";
    error_log("Excepción PDO al modificar calif: " . $e->getMessage());
}

// Devolver la respuesta al cliente en formato JSON.
echo json_encode($resultado);

<?php


// Archivo Intermediario para obtener las carreras activas desde la base de datos
require '../../../Modelo/BD/ConexionBD.php';
require '../../../Modelo/BD/ModeloBD.php';
require '../../../Modelo/DAOs/OfertaDAO.php';
//--------------------------------------------------------------
//middleware/controllerAuth.php
require_once __DIR__ . '/../../middleware/controllerAuth.php';
requireRole(["Administrador", "JefeDeCarrera"]);
//--------------------------------------------------------------
header('Content-Type: application/json'); // Para que el navegador entienda que es JSON

$c = new ConexionBD($DatosBD);
$pdo = $c->Conectar();
$objDao = new OfertaDAO($pdo);

$resultado = $objDao->BuscarCarrerasActivas('Activo');

echo json_encode($resultado);

<?php

// Archivo Intermediario para obtener los docentes activos
require '../../../Modelo/BD/ConexionBD.php';
require '../../../Modelo/BD/ModeloBD.php';
require '../../../Modelo/DAOs/OfertaDAO.php';
//--------------------------------------------------------------
// Autor: Miguel Angel Lara Hermosillo 
//middleware/controllerAuth.php
require_once __DIR__. '/../../middleware/controllerAuth.php';
requireRole(["Administrador"]);
//--------------------------------------------------------------
header('Content-Type: application/json'); // Para que el navegador entienda que es JSON

$c = new ConexionBD($DatosBD);
$pdo = $c->Conectar();
$objDao = new OfertaDAO($pdo);

$resultado = $objDao->BuscarDocentesActivos();

echo json_encode($resultado);
?>

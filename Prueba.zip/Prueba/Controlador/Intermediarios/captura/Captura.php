<?php
//header('Content-Type: application/json; charset=utf-8');
/*
// Verificar si llegó un archivo
if (!isset($_FILES['archivo'])) {
    echo json_encode([
        "ok" => false,
        "mensaje" => "No se recibió ningún archivo."
    ]);
    exit;
}

// Datos del archivo recibido
$nombre = $_FILES['archivo']['name'];
$tamano = $_FILES['archivo']['size'];
$tipo   = $_FILES['archivo']['type'];

echo json_encode([
    "ok" => true,
    "mensaje" => "Archivo recibido correctamente.",
    "archivo" => [
        "nombre" => $nombre,
        "tamano" => $tamano,
        "tipo"   => $tipo
    ]
]);*/


// Obtener el cuerpo de la petición
/*Este es para encontrar Usuarios
$input = json_decode(file_get_contents("php://input"), true);

// Validar que llegue el ID
if (!isset($input["id_usuario"])) {
    echo json_encode([
        "success" => false,
        "message" => "No se recibió el ID del usuario.",
        "data" => null
    ]);
    exit;
}

// Simulación de datos (mock)
$usuariosFake = [
    "TED-9632" => [
        "id_usuario" => "TED-9632",
        "nombre_usuario" => "Juan Carlos",
        "apellido_paterno" => "Ramírez",
        "apellido_materno" => "González",
        "rol" => "Docente",
        "status" => "Activo"
    ],

    "TED-0010" => [
        "id_usuario" => "TED-0010",
        "nombre_usuario" => "María Fernanda",
        "apellido_paterno" => "López",
        "apellido_materno" => "Hernández",
        "rol" => "Secretaria",
        "status" => "Inactivo"
    ]
];

// ID que estás buscando
$id = $input["id_usuario"];

// Buscar el usuario
if (isset($usuariosFake[$id])) {
    echo json_encode([
        "success" => true,
        "message" => "Usuario encontrado.",
        "data" => $usuariosFake[$id]
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Usuario no encontrado.",
        "data" => null
    ]);
}*/


//simular datos de unidades para mostrar en boton mas detalles

/*
// Leer JSON recibido
$input = json_decode(file_get_contents("php://input"), true);
$noControl = $input["noControl"] ?? null;

if (!$noControl) {
    echo json_encode(["error" => "No se envió número de control"]);
    exit;
}




// Ejemplo: simulamos datos distintos dependiendo del número de control
$datosSimulados = [
    "200112332" => [
        ["unidad" => 1, "calificacion" => 80, "nombreAlumno" => "Oscar Rivera Rodríguez", "nombreMateria" => "Programación Orientada a Objetos", "calFinal" => 90],
        ["unidad" => 2, "calificacion" => 90, "nombreAlumno" => "Oscar Rivera Rodríguez", "nombreMateria" => "Programación Orientada a Objetos", "calFinal" => 90],
        ["unidad" => 3, "calificacion" => 95, "nombreAlumno" => "Oscar Rivera Rodríguez", "nombreMateria" => "Programación Orientada a Objetos", "calFinal" => 90],
        ["unidad" => 4, "calificacion" => 90, "nombreAlumno" => "Oscar Rivera Rodríguez", "nombreMateria" => "Programación Orientada a Objetos", "calFinal" => 90],
        ["unidad" => 5, "calificacion" => 95, "nombreAlumno" => "Oscar Rivera Rodríguez", "nombreMateria" => "Programación Orientada a Objetos", "calFinal" => 90],
        ["unidad" => 6, "calificacion" => null, "nombreAlumno" => "Oscar Rivera Rodríguez", "nombreMateria" => "Programación Orientada a Objetos", "calFinal" => 90],
    ],

    "200111570" => [
        ["unidad" => 1, "calificacion" => 70, "nombreAlumno" => "Raul García Ríos", "nombreMateria" => "Cálculo Diferencial", "calFinal" => 75],
        ["unidad" => 2, "calificacion" => 80, "nombreAlumno" => "Raul García Ríos", "nombreMateria" => "Cálculo Diferencial", "calFinal" => 75],
        ["unidad" => 3, "calificacion" => 75, "nombreAlumno" => "Raul García Ríos", "nombreMateria" => "Cálculo Diferencial", "calFinal" => 75],
        ["unidad" => 4, "calificacion" => null, "nombreAlumno" => "Raul García Ríos", "nombreMateria" => "Cálculo Diferencial", "calFinal" => 75],
        ["unidad" => 5, "calificacion" => null, "nombreAlumno" => "Raul García Ríos", "nombreMateria" => "Cálculo Diferencial", "calFinal" => 75],
        ["unidad" => 6, "calificacion" => null, "nombreAlumno" => "Raul García Ríos", "nombreMateria" => "Cálculo Diferencial", "calFinal" => 75],
    ]
];

// Si el número de control existe, devolver su información simulada
if (array_key_exists($noControl, $datosSimulados)) {
    echo json_encode($datosSimulados[$noControl]);
} else {
    // Respuesta cuando no existe
    echo json_encode([]);
}
exit;
*/

// Simulación de respuesta del backend
// NO usa BD, NO usa sesión real
// Solo para probar render dinámico en JS

//header("Content-Type: application/json");

// Simular que el usuario está autenticado




header("Content-Type: application/json");
session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["error" => "Método no permitido"]);
    exit;
}

if (!isset($_SESSION['idUsuario'])) {
    http_response_code(401);
    echo json_encode(["error" => "Sesión no válida"]);
    exit;
}


// Simulación de datos
$response = [
    [
        "idCarrera" => 1,
        "nombreCarrera" => "Ingeniería en Sistemas Computacionales",
        "materias" => [
            [

                "claveMateria" => "SIS101",
                "nombreMateria" => "Programación I",
                "idPeriodo" => 3,
                "nombrePeriodo" => "Enero - Junio 2025",
                "grupo" => "A",
                "idDocente" => 7,
                "docente" => "Mtro. Juan Pérez",
                "capturaRealizada" => false
            ],
            [

                "claveMateria" => "SIS305",
                "nombreMateria" => "Base de Datos",
                "idPeriodo" => 3,
                "nombrePeriodo" => "Enero - Junio 2025",
                "grupo" => "B",
                "idDocente" => 8,
                "docente" => "Ing. Ana López",
                "capturaRealizada" => true
            ],
            [

                "claveMateria" => "SIS402",
                "nombreMateria" => "Ingeniería de Software",
                "idPeriodo" => 3,
                "nombrePeriodo" => "Enero - Junio 2025",
                "grupo" => "A",
                "idDocente" => 9,
                "docente" => "Mtro. Luis Hernández",
                "capturaRealizada" => true
            ],
            [

                "claveMateria" => "SIS502",
                "nombreMateria" => "Redes Avanzadas",
                "idPeriodo" => 3,
                "nombrePeriodo" => "Enero - Junio 2025",
                "grupo" => "C",
                "idDocente" => 10,
                "docente" => "Mtro. Carlos Rodríguez",
                "capturaRealizada" => false
            ]
        ]
    ],
    [
        "idCarrera" => 2,
        "nombreCarrera" => "Ingeniería Industrial",
        "materias" => [
            [

                "claveMateria" => "IND204",
                "nombreMateria" => "Estadística Industrial",
                "idPeriodo" => 4,
                "nombrePeriodo" => "Agosto - Diciembre 2025",
                "grupo" => "A",
                "idDocente" => 11,
                "docente" => "Mtra. Sofía Hernández",
                "capturaRealizada" => false
            ],
            [

                "claveMateria" => "IND305",
                "nombreMateria" => "Procesos de Manufactura",
                "idPeriodo" => 4,
                "nombrePeriodo" => "Agosto - Diciembre 2025",
                "grupo" => "B",
                "idDocente" => 12,
                "docente" => "Ing. Mario Romero",
                "capturaRealizada" => true
            ],
            [

                "claveMateria" => "IND401",
                "nombreMateria" => "Control de Calidad",
                "idPeriodo" => 4,
                "nombrePeriodo" => "Agosto - Diciembre 2025",
                "grupo" => "A",
                "idDocente" => 13,
                "docente" => "Ing. Daniela Cruz",
                "capturaRealizada" => false
            ],
            [

                "claveMateria" => "IND502",
                "nombreMateria" => "Logística y Producción",
                "idPeriodo" => 4,
                "nombrePeriodo" => "Agosto - Diciembre 2025",
                "grupo" => "C",
                "idDocente" => 14,
                "docente" => "Mtro. Javier Morales",
                "capturaRealizada" => false
            ]
        ]
    ]
];

// Enviar respuesta
echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

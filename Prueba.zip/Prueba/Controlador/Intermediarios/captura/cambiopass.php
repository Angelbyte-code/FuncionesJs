<?php
header("Content-Type: application/json");

// ================================
// LEER JSON ENVIADO POR FETCH
// ================================
$input = json_decode(file_get_contents("php://input"), true);

$pass1 = $input["nuevaPass"] ?? null;
$pass2 = $input["confirmarPass"] ?? null;

// ================================
// VALIDACIONES
// ================================

// Falta pass1
if (!$pass1) {
    echo json_encode([
        "status" => "falta",
        "message" => "Falta la nueva contraseña (nuevaPass)."
    ]);
    exit;
}

// Falta pass2
if (!$pass2) {
    echo json_encode([
        "status" => "falta",
        "message" => "Falta la confirmación de contraseña (confirmarPass)."
    ]);
    exit;
}

// No coinciden
if ($pass1 !== $pass2) {
    echo json_encode([
        "status" => "error",
        "message" => "Las contraseñas no coinciden."
    ]);
    exit;
}


echo json_encode([
    "status" => "ok",
    "message" => "La contraseña se recibió correctamente y coincide."
]);
exit;

<?php
 

require '../../../Modelo/BD/ConexionBD.php';
require '../../../Modelo/BD/ModeloBD.php';
require '../../../Modelo/DAOs/ParcialDAO.php';

//-----------------------------------------------------------------------
// Autor: Miguel Angel Lara Hermosillo 
//middleware/controllerAuth.php
require_once __DIR__. '/../../middleware/controllerAuth.php';
requireRole(["Administrador", "JefeDeCarrera", "Docente"]);
// ----------------------------------------------------------------------

header('Content-Type: application/json'); // Para que el navegador entienda que es JSON

$c = new ConexionBD($DatosBD);
$pdo = $c->Conectar();
$objDaoParcial = new ParcialDAO($pdo);

$estado = json_decode(file_get_contents("php://input"));

$resultado = $objDaoParcial->BuscarParcialPorEstado($estado);

echo json_encode($resultado);
?>

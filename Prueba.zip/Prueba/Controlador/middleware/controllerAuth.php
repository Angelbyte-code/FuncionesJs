<?php
// Autor: Miguel Angel Lara Hermosillo
// Fecha: 12-08-2025

/**
 Middleware para controlar acceso a controladores.
  Si el usuario no tiene sesión activa  se envía al login con un estado.
 */

// middleware/controllerAuth.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . "/../../Controlador/Intermediarios/UsuarioController/UsuarioController.php";
// Importar BASE_URL para usar rutas absolutas
require_once __DIR__ . "/../../config.php";

$usuarioController = new UsuarioController();



// Validar usuario logueado
if (!isset($_SESSION["idUsuario"]) || !isset($_SESSION["rol"])) {
    // Estado para manejar mensaje en login
    $estado = "invalid";
    // Redirigir al login
    header("Location: " . BASE_URL . "Vista/login.php?estado={$estado}");
    exit;
}

// Si se quiere agregar verificación de usuario inactivo:
if (isset($_SESSION["estado"]) && $_SESSION["estado"] !== "Activo") {
    $_SESSION = [];
    session_destroy();
    header("Location: " . BASE_URL . "Vista/login.php?estado=user_inactivo");
    exit;
}





/**
 * Función: requireRole
 * Valida que el usuario tenga uno de los roles permitidos.
 *
 * @param array $rolesPermitidos  Lista de roles que pueden acceder al recurso
 */
function requireRole(array $rolesPermitidos)
{
    // Verificar si existe rol en la sesión
    if (!isset($_SESSION["rol"])) {
        header("Location: " . BASE_URL . "Vista/login.php?estado=invalid");
        exit;
    }

    $rolUsuario = $_SESSION["rol"];

    // Si el rol NO está en la lista de roles válidos → prohibido
    if (!in_array($rolUsuario, $rolesPermitidos)) {
        header("Location: " . BASE_URL . "Vista/redirect.php");
        exit;
    }
}

<?php
// Autor Miguel Angel Lara Hermosillo
// middleware/controllerAuth.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Validar sesión para ENDPOINTS
 */
function requireAuth()
{
    if (!isset($_SESSION["idUsuario"]) || !isset($_SESSION["rol"])) {
        http_response_code(401);
        echo json_encode([
            "ok" => false,
            "error" => "Sesión no válida"
        ]);
        exit;
    }

    if (isset($_SESSION["estado"]) && $_SESSION["estado"] !== "Activo") {
        http_response_code(403);
        echo json_encode([
            "ok" => false,
            "error" => "Usuario inactivo"
        ]);
        exit;
    }
}

/**
 * Validar rol para ENDPOINTS
 */
function requireRole(array $rolesPermitidos)
{
    requireAuth();

    $rolUsuario =  trim($_SESSION["rol"]);

    if (!in_array($rolUsuario, $rolesPermitidos)) {
        http_response_code(403);
        echo json_encode([
            "ok" => false,
            "error" => "Acceso denegado"
        ]);
        exit;
    }
}



<?php

// Miguel Angel Lara Hermosillo
// Fecha: 12-08-2025
/**
 * Archivo de configuración global del proyecto.
 * Define BASE_URL apuntando SIEMPRE a la carpeta raíz del proyecto.
 */

// Detectar protocolo automáticamente
$protocolo = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') 
    ? "https://" 
    : "http://";

// Dominio actual
$host = $_SERVER['HTTP_HOST'];

// Nombre de la carpeta principal del proyecto
$proyecto = "prueba";  // <-- AJUSTA SOLO ESTO SI CAMBIA EL NOMBRE DEL PROYECTO

// BASE_URL SIEMPRE será la raíz del proyecto
define("BASE_URL", $protocolo . $host . '/' . $proyecto . '/');

?>

<?php
// Miguel Angel Lara Hermosillo
// Fecha: 12-08-2025    
/**
 DAO que maneja el inicio de sesión.
 Retorna estados detallados .
*/

class LoginDAO
{
    private $conector;

    public function __construct($conexionBD)
    {
        $this->conector = $conexionBD;
    }

    public function login($idUsuario, $password, $rol)
    {
        try {

            // Buscar solo el usuario por ID
            $sql = "
                SELECT 
                    claveUsuario,
                    nombre,
                    apellidoPaterno,
                    apellidoMaterno,
                    contrasena,
                    rol,
                    estado
                FROM usuario
                WHERE claveUsuario = :claveUsuario
                LIMIT 1
            ";

            $stmt = $this->conector->prepare($sql);
            $stmt->bindParam(":claveUsuario", $idUsuario, PDO::PARAM_STR);
            $stmt->execute();

            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

            // Usuario NO existe
            if (!$usuario) {
                return ["estado" => "NO_EXISTE"];
            }

            // Contraseña incorrecta
            if ($usuario["contrasena"] !== $password) {
                return ["estado" => "PASSWORD_INCORRECTA"];
            }

            // Rol incorrecto
            if ($usuario["rol"] !== $rol) {
                return ["estado" => "ROL_INCORRECTO"];
            }

            // Usuario inactivo
            if ($usuario["estado"] !== "Activo") {
                return ["estado" => "INACTIVO"];
            }

            // Login exitoso
            return [
                "estado" => "OK",
                "datos" => $usuario
            ];

        } catch (Exception $e) {
            return ["estado" => "ERROR"];
        }
    }
}

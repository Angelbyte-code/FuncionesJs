
<?php

//autor: Miguel Angel Lara Hermosillo 
/**
 * funcion: permite saber si el usuario cambia de estado Activo o Inactivo
 */

class EstadoUsuarioDAO
{
    private $pdo;

    public function __construct($pdo)
    {
        $this->pdo = $pdo;
    }

    // Consulta el estado del usuario en tiempo real
    public function obtenerEstadoPorID($idUsuario)
    {
        try {
            $sql = "SELECT estado FROM usuario WHERE claveUsuario = ? LIMIT 1";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute([$idUsuario]);

            return $stmt->fetchColumn();  // Activo | Inactivo | false
        } catch (Exception $e) {
            error_log("Error UsuarioDAO: ".$e->getMessage());
            return false;
        }
    }
}

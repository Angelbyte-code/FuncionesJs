<?php

class CalificacionDAO
{

    private $conector;

    /**
     * Constructor de la clase CalificacionDAO.
     * @param PDO $conector - Objeto de conexión a la base de datos.
     */
    public function __construct($conector)
    {
        $this->conector = $conector;
    }
    /**
     * Busca las calificaciones de una oferta académica filtradas por unidad.
     *
     * Validaciones realizadas:
     *  - Ningún parámetro obligatorio debe estar vacío.
     *  - El ID de la oferta debe ser un entero positivo.
     *  - La unidad debe ser un entero positivo.
     *  - Debe existir la oferta indicada.
     *  - Debe existir la unidad solicitada dentro de la información almacenada.
     *
     *  @param int $pidOferta   ID de la oferta académica donde se buscarán calificaciones.
     *  @param int $punidad     Número de unidad a consultar.
     *
     *  @return array Arreglo con:
     *               - 'estado': "OK" si la consulta fue exitosa, "Error" si ocurrió algún problema.
     *               - 'mensaje': Mensaje claro y entendible para el usuario sobre el resultado.
     *               - 'datos' (opcional): Resultado obtenido del procedimiento almacenado.
     */
    public function AgregarCalificacionManual($pidCalif, $punidad, $pcalificacion, $pidParcial, $pidHorario)
    {
        $resultado = ['estado' => 'Error'];
        $c = $this->conector;

        // -----------------------------------------
        // Validaciones básicas
        // -----------------------------------------

        // Validación de campos vacíos
        if ($pidCalif === "" || $punidad === "" || $pcalificacion === "" || $pidParcial === "" || $pidHorario === "") {
            $resultado['mensaje'] = "Faltan datos necesarios para completar la operación. Por favor revisa la información proporcionada y asegúrate de llenar todos los campos obligatorios.";
            return $resultado;
        }

        // Validar el formato de pidCalif
        if (!filter_var($pidCalif, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]])) {
            $resultado['mensaje'] = "El id de calificación no es válido. Debe ser un número entero positivo.";
            return $resultado;
        }

        // Validar el formato de punidad
        if (!filter_var($punidad, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]])) {
            $resultado['mensaje'] = "La unidad ingresada no es válida. Debe ser un número entero positivo.";
            return $resultado;
        }

        // Validar el formato de pidParcial
        if (!filter_var($pidParcial, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]])) {
            $resultado['mensaje'] = "El id de parcial proporcionado no es válido. Debe ser un número entero positivo.";
            return $resultado;
        }

        // Validar el formato de pidHorario
        if (!filter_var($pidHorario, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]])) {
            $resultado['mensaje'] = "El id de horario proporcionado no es válido. Debe ser un número entero positivo.";
            return $resultado;
        }

        // Validar el formato de calificación 
        if (!filter_var($pcalificacion, FILTER_VALIDATE_INT)) {
            $resultado['mensaje'] = "La calificación debe ser un número entero. Se permiten valores negativos para NC.";
            return $resultado;
        }

        // -----------------------------------------
        // Validar calificacion
        // -----------------------------------------

        $sp = $c->prepare("CALL spBuscarCalificacionByID(:pid, @mensaje)");
        $sp->bindParam(':pid', $pidCalif, PDO::PARAM_INT);
        $sp->execute();
        $parcial = $sp->fetch(PDO::FETCH_ASSOC);
        $sp->closeCursor();

        // Recuperar el mensaje de salida del SP
        $mensajeSP = $c->query("SELECT @mensaje");
        $mensaje = $mensajeSP->fetch(PDO::FETCH_ASSOC);
        $resultado['respuestaSP'] = $mensaje['@mensaje'] ?? null;

        // Validar que el id de parcial existe
        if ($resultado['respuestaSP'] === 'Estado: No se encontro el registro') {
            $resultado['mensaje'] = "No existe ningúna calificacion con el ID proporcionado.";
            return $resultado;
        }

        // -----------------------------------------
        // Validar parcial
        // -----------------------------------------

        $sp = $c->prepare("CALL spBuscarParcialByID(:pidParcial, @mensaje)");
        $sp->bindParam(':pidParcial', $pidParcial, PDO::PARAM_INT);
        $sp->execute();
        $parcial = $sp->fetch(PDO::FETCH_ASSOC); // Datos del parcial (si existen)
        $sp->closeCursor();

        // Recuperar el mensaje de salida del SP
        $mensajeSP = $c->query("SELECT @mensaje");
        $mensaje = $mensajeSP->fetch(PDO::FETCH_ASSOC);
        $resultado['respuestaSP'] = $mensaje['@mensaje'] ?? null;

        // Validar que el id de parcial existe
        if ($resultado['respuestaSP'] === 'Estado: No se encontro el registro') {
            $resultado['mensaje'] = "No existe ningún parcial con el ID proporcionado.";
            return $resultado;
        }

        // Validar que el estado del parcial sea valido
        if ($resultado['respuestaSP'] === 'Estado: Exito' && $parcial['estado'] !== 'Abierto') {
            $resultado['mensaje'] = "El parcial ingresado no está en estado 'Abierto'. Por favor use un parcial disponible.";
            return $resultado;
        }

        // -----------------------------------------
        // Validar horario
        // -----------------------------------------

        $sp = $c->prepare("CALL spBuscarHorarioByID(:pid, @mensaje)");
        $sp->bindParam(':pid', $pidHorario, PDO::PARAM_INT);
        $sp->execute();
        $horario = $sp->fetch(PDO::FETCH_ASSOC); // Datos del parcial (si existen)
        $sp->closeCursor();

        // Recuperar el mensaje de salida del SP
        $mensajeSP = $c->query("SELECT @mensaje");
        $mensaje = $mensajeSP->fetch(PDO::FETCH_ASSOC);
        $resultado['respuestaSP'] = $mensaje['@mensaje'] ?? null;

        // Validar que el id de horario existe
        if ($resultado['respuestaSP'] === 'Error: No existe un registro con el parametro solicitado') {
            $resultado['mensaje'] = "No existe ningún horario con el ID proporcionado.";
            return $resultado;
        }

        // Validar que el estado del horario sea valido
        if ($resultado['respuestaSP'] === 'Estado: Exito' && $horario['estado'] !== 'Activo') {
            $resultado['mensaje'] = "El horario ingresado no está en estado 'Activo'. Por favor use un horario disponible.";
            return $resultado;
        }

        // -----------------------------------------
        // Llamada al SP para Capturar Calificacion
        // -----------------------------------------

        try {
            $sp = $c->prepare("CALL spCapturarCalificacion(:pidCalif, :punidad, :pcalificacion, :pidParcial, :pidHorario, @mensaje)");
            $sp->bindParam(':pidCalif', $pidCalif, PDO::PARAM_INT);
            $sp->bindParam(':punidad', $punidad, PDO::PARAM_INT);
            $sp->bindParam(':pcalificacion', $pcalificacion, PDO::PARAM_INT);
            $sp->bindParam(':pidParcial', $pidParcial, PDO::PARAM_INT);
            $sp->bindParam(':pidHorario', $pidHorario, PDO::PARAM_INT);
            $sp->execute();
            $sp->closeCursor();

            $mensajeSP = $c->query("SELECT @mensaje")->fetch(PDO::FETCH_ASSOC);
            $resultado['respuestaSP'] = $mensajeSP['@mensaje'] ?? null;

            switch ($resultado['respuestaSP']) {
                case 'Estado: Exito':
                    $resultado['estado'] = "OK";
                    $resultado['mensaje'] = "Las calificacion se han guardado correctamente.";
                    break;

                case 'Error: El horario no es valido':
                    $resultado['mensaje'] = "El horario proporcionado no existe o no está activo. Verifique los datos e inténtelo nuevamente.";
                    break;

                case 'Error: El registro no existe':
                    $resultado['mensaje'] = "No existen registros de calificación para esta unidad y horario.";
                    break;

                case 'Error: El parcial no es valido':
                    $resultado['mensaje'] = "El parcial ingresado no existe o no está en estado 'Abierto'.";
                    break;

                case 'Error: Ocurrio un error al intentar la operacion':
                    $resultado['mensaje'] = "Ocurrió un problema al intentar guardar la calificacion. Por favor, inténtelo nuevamente.";
                    break;

                default:
                    $resultado['mensaje'] = "Ocurrió un error inesperado. Contacta al administrador si el problema persiste.";
                    error_log("[CapturarCalificacion] SP devolvió estado inesperado: " . $resultado['respuestaSP']);
                    break;
            }
        } catch (PDOException $e) {
            $resultado['mensaje'] = "No fue posible completar la operación en este momento. Por favor, intenta nuevamente en unos instantes.";
            error_log("[CapturarCalificacion] Error en BD al capturar califiaciones manual: " . $e->getMessage());
        }

        return $resultado;
    }

    /**
     * Busca los registros calificaciones filtradas por oferta academica y unidad.
     *
     * Validaciones realizadas:
     *  - Ningún parámetro obligatorio debe estar vacío.
     *  - El ID de la oferta debe ser un entero positivo.
     *  - La unidad debe ser un entero positivo.
     *  - Debe existir la oferta indicada.
     *  - Debe existir la unidad solicitada dentro de la información almacenada.
     *
     *  @param int $pidOferta   ID de la oferta académica donde se buscarán calificaciones.
     *  @param int $punidad     Número de unidad a consultar.
     *
     *  @return array Arreglo con:
     *               - 'estado': "OK" si la consulta fue exitosa, "Error" si ocurrió algún problema.
     *               - 'mensaje': Mensaje claro y entendible para el usuario sobre el resultado.
     *               - 'datos' (opcional): Resultado obtenido del procedimiento almacenado.
     */
    public function BuscarCalificacionesPorOfertaUnidad($pidOferta, $punidad)
    {
        $resultado = ['estado' => 'Error'];
        $c = $this->conector;

        // -----------------------------------------
        // Validaciones básicas
        // -----------------------------------------

        // Validación de campos vacíos
        if ($pidOferta === "" || $punidad === "") {
            $resultado['mensaje'] = "Faltan datos necesarios para completar la operación. Por favor revisa la información proporcionada y asegúrate de llenar todos los campos obligatorios.";
            return $resultado;
        }

        // Validar el formato de pidOferta
        if (!filter_var($pidOferta, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]])) {
            $resultado['mensaje'] = "El id de la oferta no es válido. Debe ser un número entero positivo.";
            return $resultado;
        }

        // Validar el formato de punidad
        if (!filter_var($punidad, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]])) {
            $resultado['mensaje'] = "La unidad ingresada no es válida. Debe ser un número entero positivo.";
            return $resultado;
        }

        // -----------------------------------------
        // Validar Oferta
        // -----------------------------------------

        $sp = $c->prepare("CALL spBuscarOfertaByID(:pid, @mensaje)");
        $sp->bindParam(':pid', $pidOferta, PDO::PARAM_INT);
        $sp->execute();
        $horario = $sp->fetch(PDO::FETCH_ASSOC);
        $sp->closeCursor();

        // Recuperar el mensaje de salida del SP
        $mensajeSP = $c->query("SELECT @mensaje");
        $mensaje = $mensajeSP->fetch(PDO::FETCH_ASSOC);
        $resultado['respuestaSP'] = $mensaje['@mensaje'] ?? null;

        // Validar que el id de horario existe
        if ($resultado['respuestaSP'] === 'Error: No existen registros con el parámetro solicitado') {
            $resultado['mensaje'] = "No existe ningúna oferta con el ID proporcionado.";
            return $resultado;
        }

        // -----------------------------------------
        // Llamada al SP para Buscar Calificaciones
        // -----------------------------------------

        try {
            $sp = $c->prepare("CALL spBuscarCalificacionesByOfertaUnidad(:pidOferta, :punidad, @mensaje)");
            $sp->bindParam(':pidOferta', $pidOferta, PDO::PARAM_INT);
            $sp->bindParam(':punidad', $punidad, PDO::PARAM_INT);
            $sp->execute();

            $datos = $sp->fetchAll(PDO::FETCH_ASSOC);

            $sp->closeCursor();

            $mensajeSP = $c->query("SELECT @mensaje")->fetch(PDO::FETCH_ASSOC);
            $resultado['respuestaSP'] = $mensajeSP['@mensaje'] ?? null;

            switch ($resultado['respuestaSP']) {
                case 'Estado: Exito':
                    $resultado['estado'] = "OK";
                    $resultado['datos'] = $datos;
                    break;

                case 'Error: El horario no es valido':
                    $resultado['mensaje'] = "El horario proporcionado no existe o no está activo. Verifique los datos e inténtelo nuevamente.";
                    break;

                case 'Error: El registro no existe':
                    $resultado['mensaje'] = "No existen registros de calificación para esta unidad y horario.";
                    break;

                case 'Error: El parcial no es valido':
                    $resultado['mensaje'] = "El parcial ingresado no existe o no está en estado 'Abierto'.";
                    break;

                case 'Error: Ocurrio un error al intentar la operacion':
                    $resultado['mensaje'] = "Ocurrió un problema al intentar guardar las calificaciones. Por favor, inténtelo nuevamente.";
                    break;

                default:
                    $resultado['mensaje'] = "Ocurrió un error inesperado. Contacta al administrador si el problema persiste.";
                    error_log("[CapturarCalificacion] SP devolvió estado inesperado: " . $resultado['respuestaSP']);
                    break;
            }
        } catch (PDOException $e) {
            $resultado['mensaje'] = "No fue posible completar la operación en este momento. Por favor, intenta nuevamente en unos instantes.";
            error_log("[CapturarCalificacion] Error en BD al capturar califiaciones manual: " . $e->getMessage());
        }

        return $resultado;
    }

    public function mostrarCalificacion()
    {
        try {
            $stmt = $this->conector->prepare("CALL spMostrarCalificacion(@mensaje)");
            $stmt->execute();

            $datos = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $stmt->closeCursor();

            $stmt2 = $this->conector->query("SELECT @mensaje AS mensaje");
            $mensajeOut = $stmt2->fetch(PDO::FETCH_ASSOC)['mensaje'];

            return [
                "datos" => $datos,
                "filas" => count($datos),
                "mensaje" => $mensajeOut
            ];
        } catch (Exception $e) {
            return [
                "datos" => [],
                "filas" => 0,
                "mensaje" => "Error DAO: " . $e->getMessage()
            ];
        }
    }

    public function filtrar($f)
    {
        try {
            if (!empty($f["noControl"]) || !empty($f["nombre"])) {

                $param = !empty($f["noControl"]) ? $f["noControl"] : $f["nombre"];

                $stmt = $this->conector->prepare("CALL spBuscarCalificacionByNoControlNombreAlumno(:param, @mensaje)");
                $stmt->bindParam(":param", $param);
            } else if (!empty($f["parcial"])) {

                $stmt = $this->conector->prepare("CALL spBuscarCalificacionByParcial(:param, @mensaje)");
                $stmt->bindParam(":param", $f["parcial"]);
            } else if (!empty($f["unidad"]) || !empty($f["horario"])) {

                $param = !empty($f["unidad"]) ? $f["unidad"] : $f["horario"];

                $stmt = $this->conector->prepare("CALL spBuscarCalificacionByUnidadCalificacionGrupoHorario(:param, @mensaje)");
                $stmt->bindParam(":param", $param);
            } else {
                return $this->mostrarCalificacion();
            }

            $stmt->execute();
            $datos = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $stmt->closeCursor();

            return [
                "datos" => $datos,
                "filas" => count($datos),
                "mensaje" => "OK"
            ];
        } catch (Exception $e) {
            return [
                "datos" => [],
                "filas" => 0,
                "mensaje" => "Error DAO: " . $e->getMessage()
            ];
        }
    }

    /**
     * Busca una calificación específica utilizando su ID.
     *
     * Validaciones realizadas:
     *  - El ID de la calificación no debe estar vacío.
     *  - El ID debe ser un número entero positivo.
     *  - Debe existir una calificación asociada al ID proporcionado.
     * 
     * @param int $idCalificacion  ID de la calificación a consultar.
     *
     * @return array Arreglo con:
     *               - 'estado': "OK" si la consulta fue exitosa, "Error" si ocurrió algún problema.
     *               - 'mensaje': Mensaje descriptivo del resultado (solo en caso de error).
     *               - 'datos': Información obtenida si la búsqueda fue exitosa.
     *               - 'respuestaSP': Mensaje devuelto directamente por el SP.
     */
    public function BuscarCalificacionesPorId($idCalificacion)
    {
        $resultado = ['estado' => 'Error'];
        $c = $this->conector;

        // -----------------------------------------
        // Validaciones básicas
        // -----------------------------------------

        // Validación de campos vacíos
        if ($idCalificacion === "") {
            $resultado['mensaje'] = "Hubo un problema al obtener la información del registro seleccionado. Por favor vuelve a intentarlo.";
            return $resultado;
        }

        // Validar el formato de pidCalif
        if (!filter_var($idCalificacion, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]])) {
            $resultado['mensaje'] = "El id de calificación no es válido. Debe ser un número entero positivo.";
            return $resultado;
        }

        // -----------------------------------------
        // Llamada al SP para Buscar Calificaciones
        // -----------------------------------------

        try {
            $sp = $c->prepare("CALL spBuscarCalificacionByID(:pid, @mensaje)");
            $sp->bindParam(':pid', $idCalificacion, PDO::PARAM_INT);
            $sp->execute();

            $datos = $sp->fetchAll(PDO::FETCH_ASSOC);

            $sp->closeCursor();

            $mensajeSP = $c->query("SELECT @mensaje")->fetch(PDO::FETCH_ASSOC);
            $resultado['respuestaSP'] = $mensajeSP['@mensaje'] ?? null;

            switch ($resultado['respuestaSP']) {
                case 'Estado: Exito':
                    $resultado['estado'] = "OK";
                    $resultado['datos'] = $datos;
                    break;

                case 'Estado: No se encontro el registro':
                    $resultado['mensaje'] = "No sea encontrado la informacion de la califiacion seleccionada";
                    break;

                case 'Estado: No hay registros':
                    $resultado['mensaje'] = "No existen informacion de la calificación seleccionada.";
                    break;

                default:
                    $resultado['mensaje'] = "Ocurrió un error inesperado. Contacta al administrador si el problema persiste.";
                    error_log("[BuscarCalifbyid] SP devolvió estado inesperado: " . $resultado['respuestaSP']);
                    break;
            }
        } catch (PDOException $e) {
            $resultado['mensaje'] = "No fue posible completar la operación en este momento. Por favor, intenta nuevamente en unos instantes.";
            error_log("[BuscarCalifbyid] Error en BD al capturar califiaciones manual: " . $e->getMessage());
        }

        return $resultado;
    }

}

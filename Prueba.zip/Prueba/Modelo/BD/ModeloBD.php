<?php
/**
 * Archivo de configuración con los parámetros para la conexión a la base de datos.
 * Este archivo contiene las credenciales necesarias para conectar con la base de datos.
 */

$host = "127.0.0.1";    // Dirección del servidor de la base de datos (por ahora)
$user = "root";         //dba Nombre de usuario para acceder a la base de datos
$pass = "root";     //Indica25**_1 Contraseña del usuario para acceder a la base de datos
$db = "indicadoresdb";  //indicadoresdb Nombre de la base de datos con la que se desea trabajar

/**
 * Array que contiene los datos de conexión a la base de datos.
 * Se utiliza para pasar los parámetros necesarios al crear una instancia de la clase ConexionBD.
 */
$DatosBD = array(
    "host" => $host,  // Host de la base de datos
    "user" => $user,  // Usuario de la base de datos
    "pass" => $pass,  // Contraseña del usuario
    "db" => $db       // Nombre de la base de datos
);
?>

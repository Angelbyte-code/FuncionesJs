<?php
//Autor Miguel Angel Lara Hermosillo
//Fecha 12-08-2025
/**
Funcionamiento: Este archivo cierra la sesión del usuario y lo redirige a la página de inicio de sesión.
 */

session_start();

require_once __DIR__ . '/../config.php'; // BASE_URL correcta

// Limpiar sesión
$_SESSION = [];
session_unset();
session_destroy();

// Redirigir al login
header("Location: " . BASE_URL . "Vista/login.php?estado=" . ($_GET['estado'] ?? 'logout_success'));
exit;
?>

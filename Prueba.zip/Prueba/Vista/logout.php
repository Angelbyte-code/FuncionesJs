<?php
// Autor: Miguel Angel Lara Hermosillo
// Fecha: 12-08-2025
/**
 * Cierra la sesión del usuario de forma segura y redirige al login.
 */

require_once __DIR__ . '/../config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


  // EVITAR CACHE

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: 0");


  // LIMPIAR SESIÓN

$_SESSION = [];
session_unset();


  // ELIMINAR COOKIE DE SESIÓN

if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}

session_destroy();


   //ESTADO PERMITIDO

$estado = 'logout_success';
$estadosPermitidos = ['logout_success', 'session_expirada', 'user_inactivo'];

if (isset($_GET['estado']) && in_array($_GET['estado'], $estadosPermitidos, true)) {
    $estado = $_GET['estado'];
}


   //REDIRECCIÓN

header("Location: " . BASE_URL . "Vista/login.php?estado=" . $estado);
exit;

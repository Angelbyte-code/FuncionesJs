<?php
//Autor Miguel Angel Lara Hermosillo 
//Fecha 12-08-2025
/**
Funcionamiento: Este archivo redirige a los usuarios a su dashboard correspondiente según su rol después de iniciar sesión.
 */
require_once __DIR__ . '/../config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Si no hay rol → volver a login
if (!isset($_SESSION['rol'])) {
    header("Location: " . BASE_URL . "/Vista/login.php");
    exit;
}

switch ($_SESSION["rol"]) {

    case "Administrador":
        header("Location: " . BASE_URL . "Vista/admin/index.php");
        break;

    case "JefeDeCarrera":
        header("Location: " . BASE_URL . "Vista/jefeCarrera/index.php");
        break;

    case "Docente":
        header("Location: " . BASE_URL . "Vista/docente/index.php");
        break;

    default:
        header("Location: " . BASE_URL . "Vista/login.php");
        break;
}

exit;



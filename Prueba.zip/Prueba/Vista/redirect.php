<?php
//Autor Miguel Angel Lara Hermosillo 
//Fecha 12-08-2025

/**
Funcionamiento: Este archivo redirige a los usuarios a su dashboard correspondiente según su rol después de iniciar sesión.
 */
require_once __DIR__ . '/../config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
//Validar sesión completa y estado
if (
    !isset($_SESSION['idUsuario']) ||
    !isset($_SESSION['rol']) ||
    !isset($_SESSION['estado']) ||
    $_SESSION['estado'] !== 'Activo'
) {
    session_destroy();
    header("Location: " . BASE_URL . "Vista/login.php?estado=session_expirada");
    exit;
}

//Mapeo de direcciones 
$dashboards = [
    "Administrador"   => "Vista/admin/index.php",
    "JefeDeCarrera"   => "Vista/jefeCarrera/index.php",
    "Docente"         => "Vista/docente/index.php"
];

//comprovar la existencia del rol en el dashboard
$rol = $_SESSION['rol'];

if (!isset($dashboards[$rol])) {
    session_destroy();
    header("Location: " . BASE_URL . "Vista/login.php?estado=rol_invalido");
    exit;
}

header("Location: " . BASE_URL . $dashboards[$rol]);
exit;

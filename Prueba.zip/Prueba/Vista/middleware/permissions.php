<?php

//Miguel Angel Lara Hermosillo

/*
|--------------------------------------------------------------------------
| Función: canAccess()
|--------------------------------------------------------------------------
| Esta función valida si el usuario autenticado tiene permiso para acceder
| a una acción o módulo específico del sistema.
|
| Funcionamiento:
| - Obtiene el rol del usuario desde la sesión activa ($_SESSION['rol']).
| - Consulta el mapa de permisos definido en roles.php.
| - Verifica si el rol actual se encuentra dentro de los roles permitidos
|   para el permiso solicitado.
|
| Uso principal:
| - Controlar la visibilidad de botones, enlaces y acciones en las vistas.
| - Mantener consistencia entre la lógica de permisos del frontend y backend.
|
| Importante:
| - Esta función NO reemplaza el middleware de seguridad.
| - La validación real y obligatoria de permisos siempre se realiza en el backend.
|--------------------------------------------------------------------------
*/


function canAccess(string $permission): bool
{
    if (!isset($_SESSION['rol'])) {
        return false;
    }

    $rolesMap = require __DIR__ . "/roles.php";

    if (!isset($rolesMap[$permission])) {
        return false;
    }

    $rolUsuario = trim($_SESSION['rol']);

    return in_array($rolUsuario, $rolesMap[$permission], true);
}

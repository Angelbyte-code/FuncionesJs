<?php
session_start();


require_once __DIR__ . "/../config.php";

// Si ya inició sesión, redirigir según rol
if (isset($_SESSION["rol"])) {
    header("Location: redirect.php");
    exit;
}
// Capturar estado si viene en la URL
$estado = $_GET["estado"] ?? "";
$mensaje = "";

switch ($estado) {

    case "session_expirada":
        $mensaje = "Tu sesión ha expirado. Vuelve a ingresar.";
        break;

    case "session_error":
        $mensaje = "Ocurrió un problema al validar la sesión. Vuelve a iniciar sesión.";
        break;
    case "logout_success":
        $mensaje = "Sesión cerrada correctamente.";
        break;

    case "datos_vacios":
        $mensaje = "Faltan datos por completar. verifícalos e intenta de nuevo.";
        break;

    case "login_failed":
        $mensaje = "Datos incorrectos, intenta de nuevo..";
        break;

    case "user_inactivo":
        $mensaje = "Tu usuario está deshabilitado. Contacta al administrador.";
        break;

    case "invalid":
        $mensaje = "No tienes permiso para acceder a esta área.";
        break;
    default:
        $mensaje = "";
}

?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>SICIA - Login</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #f4f6f9;
        }

        .login-card {
            max-width: 430px;
            margin: auto;
            margin-top: 6rem;
            padding: 2rem;
            border-radius: 12px;
            background: #fff;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .logo {
            width: 120px;
            margin-bottom: 1rem;
        }
    </style>
</head>

<body>

    <div class="login-card text-center">

        <img src="img/logo-tecmm.png" class="logo" alt="Institución">

        <h4 class="mb-3">Inicio de Sesión</h4>

        <?php if ($mensaje): ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <?= $mensaje ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo BASE_URL; ?>Controlador/Intermediarios/LoginController/LoginController.php">
            <div class="mb-3 text-start">
                <label class="form-label">Usuario</label>
                <input type="text" name="idUsuario" class="form-control" required>
            </div>

            <div class="mb-3 text-start">
                <label class="form-label">Contraseña</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <div class="mb-3 text-start">
                <label class="form-label">Rol</label>
                <select name="rol" class="form-select" required>
                    <option value="">Seleccionar rol</option>
                    <option value="Administrador">Administrador</option>
                    <option value="JefeDeCarrera">Jefe de Carrera</option>
                    <option value="Docente">Docente</option>
                </select>
            </div>

            <div class="d-grid">
                <button class="btn btn-primary" type="submit">Ingresar</button>
            </div>
        </form>
    </div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="library/dataTables/js/bootstrap.bundle.min.js"></script>
</body>

</html>
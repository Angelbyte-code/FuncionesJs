<?php
session_start();

require_once __DIR__ . "/../config.php";

// Si ya inició sesión, redirigir según rol
if (isset($_SESSION["rol"])) {
    header("Location: redirect.php");
    exit;
}
// Capturar estado si viene en la URL
$estado = $_GET["estado"] ?? "";
$mensaje = "";

switch ($estado) {
    case "session_expirada":
        $mensaje = "Tu sesión ha expirado. Vuelve a ingresar.";
        break;
    case "session_error":
        $mensaje = "Ocurrió un problema al validar la sesión. Vuelve a iniciar sesión.";
        break;
    case "logout_success":
        $mensaje = "Sesión cerrada correctamente.";
        break;
    case "datos_vacios":
        $mensaje = "Faltan datos por completar. verifícalos e intenta de nuevo.";
        break;
    case "login_failed":
        $mensaje = "Datos incorrectos, intenta de nuevo..";
        break;
    case "user_inactivo":
        $mensaje = "Tu usuario está deshabilitado. Contacta al administrador.";
        break;
    case "invalid":
        $mensaje = "No tienes permiso para acceder a esta área.";
        break;
    default:
        $mensaje = "";
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SICIA - Login</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/login.css" rel="stylesheet">
    <style>
       
    </style>
</head>

<body>
    <!-- Capas de fondo para transición -->
    <div class="background-layer bg-default" id="bg-default"></div>
    <div class="background-layer bg-admin" id="bg-admin" style="opacity: 0;"></div>
    <div class="background-layer bg-jefe" id="bg-jefe" style="opacity: 0;"></div>
    <div class="background-layer bg-docente" id="bg-docente" style="opacity: 0;"></div>

    <div class="login-container">
        <div class="login-card">
            <div class="logo-container">
                <img src="img/logo-tecmm.png" class="logo" alt="TecNM">
            </div>

            <h4>Inicio de Sesión</h4>

            <?php if ($mensaje): ?>
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <?= $mensaje ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo BASE_URL; ?>Controlador/Intermediarios/LoginController/LoginController.php" id="loginForm">
                <div class="mb-3">
                    <label class="form-label">Usuario</label>
                    <input type="text" name="idUsuario" class="form-control" placeholder="Ingresa tu usuario" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Contraseña</label>
                    <div class="input-group-icon">
                        <input type="password" name="password" id="password" class="form-control" placeholder="Ingresa tu contraseña" required>
                        <span class="toggle-password" id="togglePassword">👁️</span>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="form-label">Rol</label>
                    <select name="rol" id="rolSelect" class="form-select" required>
                        <option value="">Selecciona tu rol</option>
                        <option value="Administrador">Administrador</option>
                        <option value="JefeDeCarrera">Jefe de Carrera</option>
                        <option value="Docente">Docente</option>
                    </select>
                    <div id="roleIndicator" style="text-align: center; min-height: 24px;"></div>
                </div>

                <div class="d-grid">
                    <button class="btn btn-primary" type="submit">Ingresar al Sistema</button>
                </div>
            </form>
        </div>
    </div>

    <script src="library/dataTables/js/bootstrap.bundle.min.js"></script>
    <script>
        // Toggle password visibility
        const togglePassword = document.getElementById('togglePassword');
        const passwordInput = document.getElementById('password');

        togglePassword.addEventListener('click', function() {
            const type = passwordInput.type === 'password' ? 'text' : 'password';
            passwordInput.type = type;
            this.textContent = type === 'password' ? '👁️' : '🔒';
        });

        // Cambiar fondo según rol seleccionado
        const rolSelect = document.getElementById('rolSelect');
        const roleIndicator = document.getElementById('roleIndicator');
        
        const backgrounds = {
            'default': document.getElementById('bg-default'),
            'Administrador': document.getElementById('bg-admin'),
            'JefeDeCarrera': document.getElementById('bg-jefe'),
            'Docente': document.getElementById('bg-docente')
        };

        const roleLabels = {
            'Administrador': { text: '👔 Administrador del Sistema', class: 'role-admin' },
            'JefeDeCarrera': { text: '📋 Jefe de Carrera', class: 'role-jefe' },
            'Docente': { text: '👨‍🏫 Docente', class: 'role-docente' }
        };

        function changeBackground(role) {
            // Ocultar todos los fondos
            Object.values(backgrounds).forEach(bg => {
                bg.style.opacity = '0';
            });

            // Mostrar el fondo seleccionado
            if (role && backgrounds[role]) {
                backgrounds[role].style.opacity = '1';
                rolSelect.classList.add('role-selected');
                
                // Mostrar indicador de rol
                const roleInfo = roleLabels[role];
                roleIndicator.innerHTML = `<span class="role-indicator ${roleInfo.class}">${roleInfo.text}</span>`;
            } else {
                backgrounds['default'].style.opacity = '1';
                rolSelect.classList.remove('role-selected');
                roleIndicator.innerHTML = '';
            }
        }

        rolSelect.addEventListener('change', function() {
            changeBackground(this.value);
        });

        // Animación suave al enviar formulario
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            const btn = this.querySelector('button[type="submit"]');
            btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Ingresando...';
            btn.disabled = true;
        });
    </script>
</body>

</html>
<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . "/../config.php";

// Si ya inició sesión, redirigir según rol
if (isset($_SESSION["rol"])) {
    header("Location: redirect.php");
    exit;
}
// Capturar estado si viene en la URL
$estado = $_GET["estado"] ?? "";
$mensaje = "";

switch ($estado) {

    case "session_expirada":
        $mensaje = "Tu sesión ha expirado. Vuelve a ingresar.";
        break;

    case "session_error":
        $mensaje = "Ocurrió un problema al validar la sesión. Vuelve a iniciar sesión.";
        break;
    case "logout_success":
        $mensaje = "Sesión cerrada correctamente.";
        break;

    case "datos_vacios":
        $mensaje = "Faltan datos por completar. verifícalos e intenta de nuevo.";
        break;

    case "login_failed":
        $mensaje = "Datos incorrectos, intenta de nuevo..";
        break;

    case "user_inactivo":
        $mensaje = "Tu usuario está deshabilitado. Contacta al administrador.";
        break;

    case "invalid":
        $mensaje = "No tienes permiso para acceder a esta área.";
        break;
    default:
        $mensaje = "";
}

?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>SICIA - Login</title>

    <link href="css/login.css" rel="stylesheet">

</head>

<body>

    <div class="login-container">

        <!-- Lado izquierdo -->
        <div class="login-left">
            <div class="logo-container">
                <img src="img/logo-tecmm.png" alt="Institución">
            </div>
            <h2>Sistema Académico</h2>
            <p>
                Accede al sistema institucional para la gestión académica.
                Control de docentes, carreras y administración general.
            </p>
        </div>

        <!-- Lado derecho -->
        <div class="login-right">
            <h3>Inicio de Sesión</h3>

            <?php if ($mensaje): ?>
                <div class="alert">
                    <?= $mensaje ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo BASE_URL; ?>Controlador/Intermediarios/LoginController/LoginController.php">

                <div class="form-group">
                    <label>Usuario</label>
                    <input type="text" name="idUsuario" required>
                </div>

                <div class="form-group">
                    <label>Contraseña</label>
                    <input type="password" name="password" required>
                </div>

                <div class="form-group">
                    <label>Rol</label>
                    <select name="rol" required>
                        <option value="">Seleccionar rol</option>
                        <option value="Administrador">Administrador</option>
                        <option value="JefeDeCarrera">Jefe de Carrera</option>
                        <option value="Docente">Docente</option>
                    </select>
                </div>

                <button class="btn-login" type="submit">Ingresar</button>
            </form>
        </div>

    </div>

</body>

</html>
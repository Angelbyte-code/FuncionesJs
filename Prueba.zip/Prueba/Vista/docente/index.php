<?php
session_start();
require_once __DIR__ . "/../../config.php"; //ruta base
require_once __DIR__ . "/../middleware/auth.php";


?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SICIA - TSJ TEQUILA</title>
    <!-- CSS de Select2 -->
    <link rel="stylesheet" href="../library/select2/select2.min.css">
    <!-- DataTables + Bootstrap 5 CSS -->
    <link rel="stylesheet" href="../library/dataTables/css/dataTables.bootstrap5.css">
    <!-- DataTables Responsive + Bootstrap 5 CSS -->
    <link rel="stylesheet" href="../library/dataTables/css/responsive.bootstrap5.css">
    <!-- para cambiar el icono de DataTables -->
    <link rel="stylesheet" href="../css/iconsDatatable.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../css/fontawesome-free-7.1.0-web/css/all.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../css/style.css">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="../css/bootstrap-icons-1.11.3/font/bootstrap-icons.css">
</head>

<body>
    <!-- Botón de menú para móvil -->
    <button class="menu-toggle d-lg-none" id="menuToggle">
        <i class="fas fa-bars"></i>
    </button>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0 sidebar" id="sidebar">
                <div class="logo">
                    <a href="index.php"> <img src="../img/logo-tecmm.png" alt="TecJalisco Logo" class="img-fluid"></a>
                </div>


                <!-- Menú Configuraciones -->
                <div class="nav flex-column">
                    <h5 class="section-title"> <i class="fas fa-cog me-2"></i>Mi cuenta</h5>
                    <a href="javascript:void(0);" onclick="vistasDocente('myAccount', '');" class="nav-link"><i class="fas fa-user-cog me-2"></i>
                        Cambio de contraceña</a>
                    <a href="javascript:void(0);"
                        onclick="cerrarSesion();"
                        class="nav-link">
                        <i class="fas fa-user-cog me-2"></i>
                        Cerrar Sesión
                    </a>

                </div>
            </div>

            <!-- Contenido principal -->
            <div class="col-md-9 col-lg-10 ms-auto p-4 scrollApp">
                <div id="contenidoDocente" class="p-3 rounded text-center">
                    <!-- El contenido se cargará aquí dinámicamente -->
                    <h2 class="my-4">Bienvenido al sistema</h2>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery  -->
    <script src="../library/dataTables/js/jquery-3.7.1.js"></script>
    <!-- Bootstrap 5 JS Bundle -->
    <script src="../library/dataTables/js/bootstrap.bundle.min.js"></script>
    <!-- DataTables núcleo -->
    <script src="../library/dataTables/js/dataTables.js"></script>
    <!-- DataTables integración con Bootstrap 5 -->
    <script src="../library/dataTables/js/dataTables.bootstrap5.js"></script>
    <!-- DataTables extensión Responsive -->
    <script src="../library/dataTables/js/dataTables.responsive.js"></script>
    <script src="../library/dataTables/js/responsive.bootstrap5.js"></script>
    <!-- JS de Select2 -->
    <script src="../library/select2/select2.min.js"></script>
    <!--Libreria de excel-->
    <script src="../library/Sheetjs/xlsx.full.min.js"></script>
    <!-- Scripts personalizados (después de librerías) -->
  
    <script src="../js/docente/functionDocente.js"></script>
    <script src="../js/docente/cargaFormulariosCap.js"></script>
    <script src="../js/funcionesGlobales.js"></script>
    <script src="../js/functions/CambioPassword/cambioContraseña.js"></script>
    <script src="../js/modales.js"></script>
 
 
    <!-- Pasar variables de PHP a JavaScript siempre al final -->
    <script>
    window.USER_ROLE = "<?php echo htmlspecialchars($_SESSION['rol']); ?>";
    </script>
    <script>
        const BASE_URL = "<?php echo htmlspecialchars(BASE_URL); ?>";
    </script>

</body>

</html>
<?php
//Validar acceso por rol y de acceso
require_once __DIR__ .'/../../middleware/auth.php';
requireRole("capturaJefe.import");
?>

<div id="frmArea">
    <h2 class="mb-4">Mostrar Captura de Calificaciones</h2>
    <!-- Contenedor de Tablas -->
    <div id="tablasContainer">

        <!-- ========================================================= -->
        <!--            EJEMPLO 1 — INGENIERÍA EN SISTEMAS            -->
        <!-- ========================================================= -->
        <div class="carrera-section mb-5">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h4 class="card-title mb-0">
                        <i class="fas fa-graduation-cap me-2"></i> Ingeniería en Sistemas Computacionales
                    </h4>
                </div>

                <div class="card-body">
                    <table class="table table-hover table-responsive table-striped calificacion-table">
                        <thead>
                            <tr class="table-dark text-center">
                                <th>Clave</th>
                                <th>Materia</th>
                                <th>Semestre</th>
                                <th>Grupo</th>
                                <th>Docente</th>
                                <th>Opciones</th>
                            </tr>
                        </thead>

                        <tbody class="text-center">
                            <tr>
                                <td>SIS101</td>
                                <td>Programación I</td>
                                <td>1</td>
                                <td>A</td>
                                <td>Mtro. Juan Pérez</td>
                                <td>
                                    <div class="d-flex gap-2 justify-content-center">
                                        <button type="button" class="btn" style="background-color: #009475; border-color: #009475; color: white;"
                                            onclick="">
                                            <i class="fas fa-plus-circle"></i> Importar Calificaciones
                                        </button>
                                        <button type="button" class="btn btn-primary btn-sm d-flex align-items-center"
                                            onclick="">
                                            <i class="fas fa-edit me-1"></i>
                                            <span>Ver Calificaciones</span>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td>SIS305</td>
                                <td>Base de Datos</td>
                                <td>3</td>
                                <td>B</td>
                                <td>Ing. Ana López</td>
                                <td>
                                    <div class="d-flex gap-2 justify-content-center">
                                        <button type="button" class="btn" style="background-color: #009475; border-color: #009475; color: white;"
                                            onclick="">
                                            <i class="fas fa-plus-circle"></i> Importar Calificaciones
                                        </button>
                                        <button type="button" class="btn btn-primary btn-sm d-flex align-items-center"
                                            onclick="">
                                            <i class="fas fa-edit me-1"></i>
                                            <span>Ver Calificaciones</span>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td>SIS502</td>
                                <td>Redes Avanzadas</td>
                                <td>5</td>
                                <td>A</td>
                                <td>Mtro. Carlos Rodríguez</td>
                                <td>
                                    <div class="d-flex gap-2 justify-content-center">
                                        <button type="button" class="btn" style="background-color: #009475; border-color: #009475; color: white;"
                                            onclick="">
                                            <i class="fas fa-plus-circle"></i> Importar Calificaciones
                                        </button>
                                        <button type="button" class="btn btn-primary btn-sm d-flex align-items-center"
                                            onclick="">
                                            <i class="fas fa-edit me-1"></i>
                                            <span>Ver Calificaciones</span>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ========================================================= -->
        <!--        EJEMPLO 2 — INGENIERÍA INDUSTRIAL                 -->
        <!-- ========================================================= -->
        <div class="carrera-section mb-5">
            <div class="card">
                <div class="card-header bg-success text-white">
                    <h4 class="card-title mb-0">
                        <i class="fas fa-industry me-2"></i> Ingeniería Industrial
                    </h4>
                </div>

                <div class="card-body">
                    <table class="table table-hover table-responsive table-striped calificacion-table">
                        <thead>
                            <tr class="table-dark text-center">
                                <th>Clave</th>
                                <th>Materia</th>
                                <th>Semestre</th>
                                <th>Grupo</th>
                                <th>Docente</th>
                                <th>Opciones</th>
                            </tr>
                        </thead>

                        <tbody class="text-center">
                            <tr>
                                <td>IND204</td>
                                <td>Estadística Industrial</td>
                                <td>2</td>
                                <td>A</td>
                                <td>Mtra. Sofía Hernández</td>
                                <td>
                                    <div class="d-flex gap-2 justify-content-center">
                                        <button type="button" class="btn" style="background-color: #009475; border-color: #009475; color: white;"
                                            onclick="">
                                            <i class="fas fa-plus-circle"></i> Importar Calificaciones
                                        </button>
                                        <button type="button" class="btn btn-primary btn-sm d-flex align-items-center"
                                            onclick="">
                                            <i class="fas fa-edit me-1"></i>
                                            <span>Ver Calificaciones</span>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td>IND401</td>
                                <td>Control de Calidad</td>
                                <td>4</td>
                                <td>B</td>
                                <td>Ing. Mario Romero</td>
                                <td>
                                    <div class="d-flex gap-2 justify-content-center">
                                        <button type="button" class="btn" style="background-color: #009475; border-color: #009475; color: white;"
                                            onclick="">
                                            <i class="fas fa-plus-circle"></i> Importar Calificaciones
                                        </button>
                                        <button type="button" class="btn btn-primary btn-sm d-flex align-items-center"
                                            onclick="">
                                            <i class="fas fa-edit me-1"></i>
                                            <span>Ver Calificaciones</span>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ========================================================= -->
        <!--        EJEMPLO 3 — GESTIÓN EMPRESARIAL                   -->
        <!-- ========================================================= -->
        <div class="carrera-section mb-5">
            <div class="card">
                <div class="card-header bg-warning">
                    <h4 class="card-title mb-0">
                        <i class="fas fa-briefcase me-2"></i> Ingeniería en Gestión Empresarial
                    </h4>
                </div>

                <div class="card-body">
                    <table class="table table-hover table-responsive table-striped calificacion-table">
                        <thead>
                            <tr class="table-dark text-center">
                                <th>Clave</th>
                                <th>Materia</th>
                                <th>Semestre</th>
                                <th>Grupo</th>
                                <th>Docente</th>
                                <th>Opciones</th>
                            </tr>
                        </thead>

                        <tbody class="text-center">
                            <tr>
                                <td>IGE101</td>
                                <td>Fundamentos de Gestión</td>
                                <td>1</td>
                                <td>C</td>
                                <td>Mtra. Karla Mendoza</td>
                                <td>
                                    <div class="d-flex gap-2 justify-content-center">
                                        <button type="button" class="btn" style="background-color: #009475; border-color: #009475; color: white;"
                                            onclick="">
                                            <i class="fas fa-plus-circle"></i> Importar Calificaciones
                                        </button>
                                        <button type="button" class="btn btn-primary btn-sm d-flex align-items-center"
                                            onclick="">
                                            <i class="fas fa-edit me-1"></i>
                                            <span>Ver Calificaciones</span>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                            <tr>
                                <td>IGE305</td>
                                <td>Administración Financiera</td>
                                <td>3</td>
                                <td>D</td>
                                <td>Ing. Roberto Sánchez</td>
                                <td>
                                    <div class="d-flex gap-2 justify-content-center">
                                        <button type="button" class="btn" style="background-color: #009475; border-color: #009475; color: white;"
                                            onclick="">
                                            <i class="fas fa-plus-circle"></i> Importar Calificaciones
                                        </button>
                                        <button type="button" class="btn btn-primary btn-sm d-flex align-items-center"
                                            onclick="">
                                            <i class="fas fa-edit me-1"></i>
                                            <span>Ver Calificaciones</span>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

    <!-- Paginación -->
    <div class="row mt-4">
        <div class="col-12">
            <nav aria-label="Paginación de carreras">
                <ul class="pagination justify-content-center" id="paginationCarreras">
                    <!-- Aquí se puede agregar paginación con JS -->
                </ul>
            </nav>
        </div>
    </div>
</div>


<?php
//Validar acceso por rol y de acceso
require_once __DIR__ . '/../../middleware/auth.php';
requireRole("capturaJefe.import");
?>

<div id="frmArea">
    <h2 class="mb-4">Mostrar Captura de Calificaciones</h2>
    <!-- Contenedor de Tablas -->
    <div id="tablasContainer">


    </div>
</div>


<!-- Paginación -->
<div class="row mt-4">
    <div class="col-12">
        <nav aria-label="Paginación de carreras">
            <ul class="pagination justify-content-center" id="paginationCarreras">
                <!-- Aquí se puede agregar paginación con JS -->
            </ul>
        </nav>
    </div>
</div>



<!-- ================== TEMPLATES  ================== -->

<template id="tplCarreraSection">
    <div class="carrera-section mb-5" data-id-carrera="">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h4 class="card-title mb-0">
                    <i class="fas fa-graduation-cap me-2"></i>
                    <span class="carrera-nombre"></span>
                </h4>
            </div>

            <div class="card-body">
                <table class="table table-hover table-responsive table-striped calificacion-table">
                    <thead>
                        <tr class="table-dark text-center">
                            <th class="text-center">Clave</th>
                            <th class="text-center">Materia</th>
                            <th class="text-center">Periodo</th>
                            <th class="text-center">Grupo</th>
                            <th class="text-center">Docente</th>
                            <th class="text-center">Opciones</th>
                        </tr>
                    </thead>
                    <tbody class="text-center"></tbody>
                </table>
            </div>
        </div>
    </div>
</template>

<template id="tplRowMateria">
    <tr class="row-materia"
        data-id-carrera=""
        data-id-periodo=""
        data-id-materia=""
        data-id-grupo=""
        data-id-docente="">

        <td class="materia-clave"></td>
        <td class="materia-nombre"></td>

        <td>
            <span class="periodo-nombre"></span>
            <input type="hidden" class="hdn-id-periodo">
        </td>

        <td class="grupo-nombre"></td>
        <td class="docente-nombre"></td>

        <td>
            <input type="hidden" class="hdn-id-carrera">
            <div class="d-flex gap-2 justify-content-center align-items-center">

                

                <button type="button"
                    class="btn btn-importar-calificaciones"
                    data-action="importar"
                    style="background-color: #009475; border-color: #009475; color: white;">
                    <i class="fas fa-plus-circle"></i> Importar Calificaciones
                </button>

                <button type="button"
                    class="btn btn-primary btn-sm d-flex align-items-center btn-ver-calificaciones"
                    data-action="ver">
                    <i class="fas fa-edit me-1"></i>
                    <span>Ver Calificaciones</span>
                </button>

                    
                 <span class="estado-captura ms-2"></span>
            </div>
        </td>
    </tr>
</template>



<?php include_once __DIR__ . '/../../Templates/modales/modalImportarArchivo.php'; ?>
<?php include_once __DIR__ . '/../../Templates/modales/previewExcel.php'; ?>
<?php include_once __DIR__ . '/../../Templates/modales/errorModal.php'; ?>
<?php
$loaderText = "Espere un momento.....";
include_once __DIR__ . '/../../Templates/modales/ModalLoader.php';
?>
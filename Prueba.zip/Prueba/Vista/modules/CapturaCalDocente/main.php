<div id="frmArea">
    <h2 class="mb-4">Administracion de grupos</h2>

    <div class="d-flex gap-2 justify-content-center">
        <button type="button" class="btn" style="background-color: #009475; border-color: #009475; color: white;"
            onclick="">
            <i class="fas fa-plus-circle"></i> Captura de calificacion Individual
        </button>
    </div>

    <table class="table table-hover table-responsive table-striped" id="tableAsignatura">
        <thead>
            <tr class="table-dark text-center">
                <th>Grupo</th>
                <th>Asignatura</th>
                <th>Plan</th>
                <th>Programa</th>
                <th>Opciones</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>3A</td>
                <td>AED-1026 ESTRUCTURA DE DATOS</td>
                <td>IINF-2010-220</td>
                <td>IIFN</td>
                <td>
                    <div class="d-flex gap-2 justify-content-center">
                        <button type="button" class="btn" style="background-color: #009475; border-color: #009475; color: white;"
                            onclick="cargaFormDocenteCaptura('frmCaptura','');">
                            <i class="fas fa-plus-circle"></i> Captura
                        </button>
                        <button type="button" class="btn btn-primary btn-sm d-flex align-items-center"
                            onclick="cargaFormDocenteCaptura('modCaptura','27');">
                            <i class="fas fa-edit me-1"></i>
                            <span>Editar</span>
                        </button>
                    </div>
                </td>
            </tr>
            <tr>
                <td>7A</td>
                <td>IFF-1026 TOPICOS DE BASE DE DATOS</td>
                <td>IINF-2010-220</td>
                <td>IIFN</td>
                <td>
                    <div class="d-flex gap-2 justify-content-center">
                        <button type="button" class="btn" style="background-color: #009475; border-color: #009475; color: white;"
                            onclick="cargaFormDocenteCaptura('frmCaptura','');">
                            <i class="fas fa-plus-circle"></i> Captura
                        </button>
                        <button type="button" class="btn btn-primary btn-sm d-flex align-items-center"
                        onclick="cargaFormDocenteCaptura('modCaptura','28');">
                            
                            <i class="fas fa-edit me-1"></i>
                            <span>Editar</span>
                        </button>
                    </div>
                </td>
            </tr>
            <tr>
                <td>3A</td>
                <td>ERF-1030 TALLER ASISTENCIA INFORMATICA</td>
                <td>IINF-2010-217</td>
                <td>IIFN</td>
                <td>
                    <div class="d-flex gap-2 justify-content-center">
                        <button type="button" class="btn" style="background-color: #009475; border-color: #009475; color: white;"
                            onclick="cargaFormDocenteCaptura('frmCaptura','');">
                            <i class="fas fa-plus-circle"></i> Captura
                        </button>
                        <button type="button" class="btn btn-primary btn-sm d-flex align-items-center"
                        onclick="cargaFormDocenteCaptura('modCaptura','22');"
                        >
                            <i class="fas fa-edit me-1"></i>
                            <span>Editar</span>
                        </button>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div>
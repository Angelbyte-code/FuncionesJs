<?php



// validar autenticacion y verificar el rol correspondiente al modulo
require_once __DIR__ .'/../../middleware/auth.php';
requireRole("usuario.add");
?>


<div id="frmArea">
    <h2 class="mb-4">Usuarios</h2>

    <div class="row mb-3">
        <div class="col-12 text-end">
            <button type="button" class="btn" style="background-color: #E74C3C; border-color: #E74C3C; color: white;"
                onclick="location.href='index.php';">
                <i class="fas fa-arrow-circle-left"></i> Regresar
            </button>
            <button type="button" class="btn" style="background-color: #009475; border-color: #009475; color: white;"
                onclick="loadFormUser('frmUser', '');">
                <i class="fas fa-plus-circle"></i> Agregar Usuario
            </button>
        </div>
    </div>
   <!--Tabla De usuarios-->
    <table class="table table-hover table-responsive table-striped" id="tableUsuarios">
        <thead>
            <tr class="table-dark text-center">
                <th>ID de Usuario</th>
                <th>Nombre</th>
                <th>Rol</th>
                <th>Estado</th>
                <th>opciones</th>
            </tr>
        </thead>
        <tbody class="">
            <tr>
                <td>TED-9632</td>
                <td>Juan Carlos Ramirez Gonzalez</td>
                <td>Docente</td>
                <td><span class="badge bg-danger">Inactivo</span></td>
                <td>
                    <div class="d-flex gap-2 justify-content-center">
                        <button class="btn btn-primary btn-sm d-flex align-items-center"
                            onclick="loadFormUser('modUser', 'TED-9632');">
                            <i class="fas fa-edit me-1"></i>
                            <span>Editar</span>
                        </button>
                        <label>
                            <select class="form-select form-select-sm btn-warning"
                                style="width: auto; color: #212529; background-color: #ffc107; border-color: #ffc107;"
                                id="estado-TED-9632<?php //$fila['id_usuario'] ?>"
                                onchange="changeStatusUsuario('Juan Carlos Ramirez Gonzalez', 'TED-9632', this.value, 'Inactivo', this.id)">
                                <option value="" disabled selected>Cambiar estado</option>
                                <option value="Activo">Activo</option>
                                <option value="Inactivo">Inactivo</option>
                            </select>
                        </label>
                    </div>
                </td>
            </tr>
            <tr>
                <td>TED-0002</td>
                <td>Ernestina Gody</td>
                <td>Secretaria</td>
                <td><span class="badge bg-success">Activo</span></td>
                <td>
                    <div class="d-flex gap-2 justify-content-center">
                        <button class="btn btn-primary btn-sm d-flex align-items-center"
                            onclick="loadFormUser('modUser', 'SAS-999');">
                            <i class="fas fa-edit me-1"></i>
                            <span>Editar</span>
                        </button>
                        <label>
                            <select class="form-select form-select-sm btn-warning"
                                style="width: auto; color: #212529; background-color: #ffc107; border-color: #ffc107;"
                                 id="estado-TED-0002<?php //$fila['id_usuario'] ?>"  
                                 onchange="changeStatusUsuario('Juan Carlos Ramirez Gonzalez', 'TED-9632', this.value, 'Activo', this.id)">
                                >
                                <option value="" disabled selected>Cambiar estado</option>
                                <option value="Activo">Activo</option>
                                <option value="Inactivo">Inactivo</option>
                            </select>
                        </label>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div>

<!--Modal de carga-->
<?php
$loaderText = "Espere un momento...";
 include __DIR__ . "/../../Templates/modales/ModalLoader.php" 
 ?>



<?php
// validar autenticacion y verificar el rol correspondiente al modulo
require_once __DIR__ .'/../../middleware/auth.php';
requireRole("usuario.add");
?>


<link rel="stylesheet" href="../css/styleInterno.css">

<div class="container" id="frmUser">
    <div class="row justify-content-center">
        <div class="ampliacion">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">
                        <i class="bi bi-people-fill me-"></i>
                        Modificar Datos de Usuario
                    </h5>
                </div>
                <div class="card-body p-4">
                    <form>
                        <div class="mb-4">
                            <label for="clave" class="form-label">ID de Usuario</label>
                            <div class="input-group">
                                <span class="input-group-text bg-blue-light"><i class="fas fa-id-card"></i></span>
                                <input
                                    type="text"
                                    maxlength="9"
                                    title="Solo letras, números y guion medio. Máximo 9 caracteres."
                                    class="form-control"
                                    id="UserID"
                                    required
                                    disabled>
                            </div>

                        </div>

                        <div class="mb-4">
                            <label class="form-label">Datos del Usuario</label>

                            <div class="row g-3">

                                <!-- Nombre(s) -->
                                <div class="col-md-4">
                                    <div class="input-group">
                                        <span class="input-group-text bg-blue-light">
                                            <i class="fas fa-user"></i>
                                        </span>
                                        <input type="text"
                                            maxlength="30"
                                            title="Nombre(s)"
                                            class="form-control"
                                            id="nombreuser"
                                            oninput="validaCamposDeUsuarios('nombreuser', 'col-md-4', '');"
                                            placeholder="Nombre(s)"
                                            required>
                                    </div>
                                </div>

                                <!-- Apellido paterno -->
                                <div class="col-md-4">
                                    <div class="input-group">
                                        <span class="input-group-text bg-blue-light">
                                            <i class="fas fa-user-tag"></i>
                                        </span>
                                        <input type="text"
                                            maxlength="50"
                                            title="Apellido paterno"
                                            class="form-control"
                                            id="apellidopUser"
                                            oninput="validaCamposDeUsuarios('apellidopUser', 'col-md-4', '');"
                                            placeholder="Apellido Paterno"
                                            required>
                                    </div>
                                </div>

                                <!-- Apellido materno -->
                                <div class="col-md-4">
                                    <div class="input-group">
                                        <span class="input-group-text bg-blue-light">
                                            <i class="fas fa-user-tag"></i>
                                        </span>
                                        <input type="text"
                                            maxlength="50"
                                            title="Apellido Materno"
                                            class="form-control"
                                            id="apellidomUser"
                                            oninput="validaCamposDeUsuarios('apellidomUser', 'col-md-4', '');"
                                            placeholder="Apellido Materno"
                                            required>
                                    </div>
                                </div>

                            </div>
                        </div>

                        <!-- Generar Contraseña -->
                        <div class="mb-4">
                            <label class="form-label fw-bold">Contraseña</label>
                            <div class="input-group">
                                <span class="input-group-text bg-blue-light">
                                    <i class="fas fa-lock"></i>
                                </span>

                                <input
                                    type="text"
                                    title="Contraseña generada"
                                    class="form-control"
                                    id="passwordUser"
                                    placeholder="password"
                                    disabled>

                                <!-- Botón para generar la contraseña -->
                                <button
                                    class="btn btn-primary"
                                    type="button"
                                    onclick="generarPasswordUsuario()">
                                    <i class="fas fa-sync-alt"></i> Restablecer Password
                                </button>
                            </div>
                        </div>


                        <!--  Rol -->
                        <div class="mb-4">
                            <label class="form-check-label" for="estado">Rol de Usuario</label>
                            <div class="input-group">
                                <span class="input-group-text bg-blue-light"><i class="fas fa-check-circle"></i></span>
                                <select class="form-select" id="RolUsuario" onchange="validaCamposDeUsuarios('RolUsuario', 'mb-4', '');">
                                    <option value="" selected disabled>Seleccione un Rol</option>
                                    <option value="JefedeCarrera">Jefe de Carrera</option>
                                    <option value="Secretaria">Secretaria</option>
                                    <option value="Docente">Docente</option>
                                </select>
                            </div>
                        </div>


                        <!-- Apellido Estado -->
                        <div class="mb-4">
                            <label class="form-check-label" for="estado">Estado</label>
                            <div class="input-group">
                                <span class="input-group-text bg-blue-light"><i class="fas fa-check-circle"></i></span>
                                <select class="form-control" disabled id="statusUser">
                                    <option value="Activo" selected>Activo</option>
                                    <option value="Inactivo">Inactivo</option>
                                </select>
                            </div>
                        </div>


                        <!-- Botones -->
                        <div class="row">
                            <div class="col-12 separarBotones gap-2">
                                <button type="button"
                                    id="btnGuardarJ"
                                    class="btn btn3 btn-primary"
                                    onclick="validarFormulariosUsuario('modificar')"
                                    disabled>
                                    <i class="fas fa-save me-2"></i>Actualizar
                                </button>
                                <button type="button"
                                    class="btn btn-outline-secondary"
                                    onclick="option('user')">
                                    <i class="fas fa-times-circle me-2"></i>Cancelar
                                </button>

                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!--Modal de carga-->
<?php
$loaderText = "Espere un momento...";
include __DIR__ . "/../../Templates/modales/ModalLoader.php";
?>
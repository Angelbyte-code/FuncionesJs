<?php
//Validar acceso por rol
require_once __DIR__ .'/../../middleware/auth.php';
requireRole("captura.main");
?>

<div class="container mt-4">
    <div class="card shadow-sm border-0">


        <div class="card-header bg-primary text-white d-flex justify-content-center gap-2 align-items-center">
            <h5 class="mb-0">Cambio de estado de Parciales</h5>
            <button type="button" class="btn"
                style="background-color: #E74C3C; border-color: #E74C3C; color: white;"
                onclick="goTo('captura','');">
                <i class="fas fa-arrow-circle-left"></i> Regresar
            </button>
        </div>


        <div class="card-body">
            <table class="table table-hover table-striped align-middle text-center" id="tableListaParciales">
                <thead class="table-primary">
                    <tr>
                        <th class="text-center">ID Parcial</th>
                        <th class="text-center">Nombre del Parcial</th>
                        <th class="text-center">ID Periodo</th>
                        <th class="text-center">Nombre del Periodo</th>
                        <th class="text-center">Estado</th>
                        <th class="text-center">Opciones</th>
                    </tr>
                </thead>
                <tbody>
                    <!--Aqui se insertan los datos Dinamicamente-->
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#tableListaParciales').DataTable({
            language: {
                url: 'https://cdn.datatables.net/plug-ins/1.13.5/i18n/es-ES.json',
                paginate: {
                    previous: "Anterior",
                    next: "Siguiente"
                }
            },
            responsive: true,
            pageLength: 10,
            pagingType: "simple",
            columnDefs: [{
                orderable: false,
                targets: [1, 2, 3, 4]
            }],
        });

        $('[data-toggle="tooltip"]').tooltip();


    });
</script>
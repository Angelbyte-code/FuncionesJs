<?php
//Validar acceso por rol
require_once __DIR__ .'/../../middleware/auth.php';
requireRole("captura.main");
?>

<div id="frmArea">
    <h2 class="mb-4">Captura</h2>

    <div class="row mb-3">
        <div class="col-12 text-end">
            <button type="button" class="btn" style="background-color: #E74C3C; border-color: #E74C3C; color: white;"
                onclick="location.href='index.php';">
                <i class="fas fa-arrow-circle-left"></i> Regresar
            </button>
            <button type="button" class="btn" style="background-color: #009475; border-color: #009475; color: white;"
                onclick="loadFormJcaptura('frmCaptura', '')">
                <i class="fas fa-plus-circle"></i> Agregar Calificación
            </button>
            <button type="button" class="btn btn-primary"
                onclick="buscarArchivoImportado()"
                id="btnBuscar">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-table"
                    viewBox="0 0 16 16">
                    <path d="M0 2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm15 2h-4v3h4zm0 4h-4v3h4zm0 4h-4v3h3a1 1 0 0 0 1-1zm-5 3v-3H6v3zm-5 0v-3H1v2a1 1 0 0 0 1 1zm-4-4h4V8H1zm0-4h4V4H1zm5-3v3h4V4zm4 4H6v3h4z" />
                </svg>
                Importar Archivo
            </button>
            <input type="file" id="fileImport" accept=".xlsx,.xls" style="display:none">

            </script>
            <button type="button" class="btn btn-secondary"
                data-bs-toggle="modal"
                data-bs-target="#modalFiltros">
                <i class="fas fa-filter"></i> Filtros
            </button>
            <button type="button" class="btn"
                style="background-color: #ddc917ff; border-color: #cabd04ff; color: white;"
                onclick="loadFormJcaptura('cambioEstado', '');">
                <i class="fas fa-plus-circle"></i> Periodo/Parcial
            </button>
        </div>
    </div>

    <table class="table table-hover table-responsive table-striped" id="tableCaptura">
    <thead>
        <tr class="table-dark text-center">
            <th style="display:none;">ID Calificación</th>
            <th>Numero de Control</th>
            <th>Nombre del Alumno</th>
            <th>Parcial</th>
            <th>Semestre</th>
            <th>Clave de Materia</th>
            <th>Nombre de Materia</th>
            <th>Grupo</th>
            <th>Opciones</th>
        </tr>

        <!-- FILTROS -->
        <tr>
            <th style="display:none;"></th>
            <th><input type="text" class="form-control form-control-sm" placeholder="Buscar..."></th>
            <th><input type="text" class="form-control form-control-sm" placeholder="Buscar..."></th>
            <th><input type="text" class="form-control form-control-sm" placeholder="Buscar..."></th>
            <th><input type="text" class="form-control form-control-sm" placeholder="Buscar..."></th>
            <th><input type="text" class="form-control form-control-sm" placeholder="Buscar..."></th>
            <th><input type="text" class="form-control form-control-sm" placeholder="Buscar..."></th>
            <th><input type="text" class="form-control form-control-sm" placeholder="Buscar..."></th>
            <th></th>
        </tr>
    </thead>

    <tbody class="text-center">
        <!--Contenido Dinamico con JS-->
    </tbody>
</table>

</div>

<!-- Modal Filtros -->
<div class="modal fade" id="modalFiltros" tabindex="-1" aria-labelledby="modalFiltrosLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="modalFiltrosLabel">Filtrar Resultados</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
            </div>
            <div class="modal-body">
                <form id="formFiltros">
                    <div class="mb-3">
                        <label class="form-label">Número de Control</label>
                        <input type="text" id="filtroNoControl" class="form-control" placeholder="Ej. 210115087">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Nombre del Alumno</label>
                        <input type="text" id="filtroNombre" class="form-control" placeholder="Ej. José Pérez">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Parcial</label>
                        <select id="filtroParcial" class="form-select">
                            <option value="">-- Seleccionar --</option>
                            <option value="Primero">Primero</option>
                            <option value="Segundo">Segundo</option>
                            <option value="Tercero">Tercero</option>
                            <option value="Cuarto">Cuarto</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Carrera</label>
                        <input type="text" id="filtroCarrera" class="form-control" placeholder="Informatica">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Grupo</label>
                        <input type="text" id="filtroGrupo" class="form-control" placeholder="Ej. B">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Grado</label>
                        <input type="text" id="filtroGrado" class="form-control" placeholder="Ej. 1">
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-success" id="btnAplicarFiltros" onclick="tomarFiltros()">
                    Aplicar filtros
                </button>
            </div>
        </div>
    </div>
</div>

<?php
$loaderText = "Espere un momento....";
include __DIR__ . "/../../Templates/modales/ModalLoader.php";
?>

<!-- Modal de Error -->
<!--Modal Importar Archivos-->
<?php
include __DIR__ . "/../../Templates/modales/errorModal.php";
?>


<!--Modal Importar Archivos-->
<?php
include __DIR__ . "/../../Templates/modales/modalImportarArchivo.php";
?>

<!-- MODAL VISTA PREVIA -->
<?php
include __DIR__ . "/../../Templates/modales/previewExcel.php";
?>

<?php
include __DIR__ . "/../../Templates/modales/modalDetallesPorUnidad.php";
?>
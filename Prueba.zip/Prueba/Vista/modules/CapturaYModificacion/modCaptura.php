<?php
//Validar acceso por rol
require_once __DIR__ .'/../../middleware/auth.php';
requireRole("captura.grup");
?>


<link rel="stylesheet" href="../css/styleInterno.css">
<link rel="stylesheet" href="../css/captura.css">
<style>
    /* Estilos para campos no editables en modo edición */
    .form-select.bg-light:disabled,
    .form-control.bg-light:disabled {
        background-color: #e9ecef !important;
        cursor: not-allowed;
        opacity: 0.7;
    }

    .form-select:disabled,
    .form-control:disabled {
        background-color: #f8f9fa;
        cursor: not-allowed;
    }
</style>
<div class="container" id="modCaptura">
    <div class="row justify-content-center">
        <div class="ampliacion">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-edit me-2"></i>
                        Modificar Calificaciones
                    </h5>
                </div>
                <div class="card-body p-4">
                    <form id="formModificarCalificaciones">

                        <!-- Sección de Selección de Criterios -->
                        <div class="row mb-4">
                            <div class="col-md-4 mb-3">
                                <label for="parcialSelectMod" class="form-label">
                                    Parcial <span class="text-danger">*</span>
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text bg-blue-light">
                                        <i class="fas fa-calendar-check"></i>
                                    </span>
                                    <select id="parcialSelectMod" class="form-select" required>
                                        <option value="">Seleccione un parcial...</option>
                                        <!-- Opciones se cargarán dinámicamente (solo parciales abiertos) -->
                                    </select>
                                </div>
                                <div class="error-message" id="errorParcialMod" style="display: none;"></div>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label for="horarioSelectMod" class="form-label">
                                    Materia <span class="text-danger">*</span>
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text bg-blue-light">
                                        <i class="fas fa-clock"></i>
                                    </span>
                                    <select id="horarioSelectMod" class="form-select" disabled required>
                                        <option value="">Seleccione una materia...</option>
                                        <!-- Opciones se cargarán dinámicamente -->
                                    </select>
                                </div>
                                <div class="error-message" id="errorHorarioMod" style="display: none;"></div>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label for="unidadSelectMod" class="form-label">
                                    Unidad <span class="text-danger">*</span>
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text bg-blue-light">
                                        <i class="fas fa-book"></i>
                                    </span>
                                    <select id="unidadSelectMod" class="form-select" disabled required>
                                        <option value="">Seleccione unidad...</option>
                                        <option value="1">Unidad 1</option>
                                        <option value="2">Unidad 2</option>
                                        <option value="3">Unidad 3</option>
                                        <option value="4">Unidad 4</option>
                                        <option value="5">Unidad 5</option>
                                        <option value="6">Unidad 6</option>
                                        <option value="7">Unidad 7</option>
                                        <option value="8">Unidad 8</option>
                                    </select>
                                </div>
                                <div class="error-message" id="errorUnidadMod" style="display: none;"></div>
                            </div>
                        </div>

                        <!-- Alerta de estado del parcial -->
                        <div class="row mb-4" id="alertaParcialMod" style="display: none;">
                            <div class="col-12">
                                <div class="alert alert-warning mb-0" role="alert">
                                    <i class="fas fa-exclamation-triangle me-2"></i>
                                    <strong>Atención:</strong>
                                    <span id="mensajeParcialMod">El parcial seleccionado no está abierto. No se pueden modificar calificaciones.</span>
                                </div>
                            </div>
                        </div>

                        <!-- Información del Horario Seleccionado -->
                        <div class="row mb-4" id="infoHorarioMod" style="display: none;">
                            <div class="col-12">
                                <div class="alert alert-info mb-0">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <i class="fas fa-book-open me-2"></i>
                                            <strong>Materia:</strong> <span id="infoMateriaMod">-</span>
                                        </div>
                                        <div class="col-md-4">
                                            <i class="fas fa-chalkboard-teacher me-2"></i>
                                            <strong>Docente:</strong> <span id="infoDocenteMod">-</span>
                                        </div>
                                        <div class="col-md-4">
                                            <i class="fas fa-users me-2"></i>
                                            <strong>Grupo:</strong> <span id="infoGrupoMod">-</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Mensaje cuando no hay calificaciones -->
                        <div class="row mb-4" id="mensajeSinCalificaciones" style="display: none;">
                            <div class="col-12">
                                <div class="alert alert-warning mb-0" role="alert">
                                    <i class="fas fa-clipboard-list me-2"></i>
                                    <strong>Sin datos:</strong> No hay calificaciones registradas para este parcial,
                                    horario y unidad.
                                </div>
                            </div>
                        </div>

                        <!-- Mensaje de advertencia de cambios sin guardar -->
                        <div class="row mb-4" id="alertaCambiosSinGuardar" style="display: none;">
                            <div class="col-12">
                                <div class="alert alert-danger mb-0" role="alert">
                                    <i class="fas fa-exclamation-circle me-2"></i>
                                    <strong>Advertencia:</strong>
                                    <span id="mensajeCambiosSinGuardar">Hay cambios sin guardar. Si cambia los criterios de búsqueda, perderá los cambios realizados.</span>
                                </div>
                            </div>
                        </div>

                        <!-- Mensaje de info cuando no hay cambios -->
                        <div class="row mb-4" id="alertaSinCambios" style="display: none;">
                            <div class="col-12">
                                <div class="alert alert-info mb-0" role="alert">
                                    <i class="fas fa-info-circle me-2"></i>
                                    <span id="mensajeSinCambios">No se detectaron cambios para guardar.</span>
                                </div>
                            </div>
                        </div>

                        <!-- Tabla de Calificaciones -->
                        <div class="mb-4" id="seccionTablaMod" style="display: none;">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h6 class="mb-0">
                                    <i class="fas fa-clipboard-check me-2"></i>
                                    Calificaciones Registradas
                                    <span class="badge bg-secondary ms-2" id="contadorCalificaciones">0</span>
                                </h6>
                                <div>
                                    <span class="badge bg-info me-2" id="promedioCalificaciones"
                                          style="font-size: 0.95rem;">
                                        <i class="fas fa-chart-line me-1"></i>Promedio grupal: --
                                    </span>
                                    <span class="badge bg-success me-2" id="contadorModificados">
                                        <i class="fas fa-edit me-1"></i>Modificados: 0
                                    </span>
                                </div>
                            </div>

                            <div class="table-responsive">
                                <table class="table table-hover table-bordered align-middle"
                                       id="tablaCalificacionesMod">
                                    <thead class="table-warning">
                                    <tr>
                                        <th style="width: 15%;">
                                            <i class="fas fa-id-card me-1"></i>
                                            Número de Control
                                        </th>
                                        <th style="width: 30%;">
                                            <i class="fas fa-user me-1"></i>
                                            Nombre Completo
                                        </th>
                                        <th style="width: 10%;">
                                            <i class="fas fa-layer-group me-1"></i>
                                            Semestre
                                        </th>
                                        <th style="width: 15%;">
                                            <i class="fas fa-star-half-alt me-1"></i>
                                            Calificación Actual
                                        </th>
                                        <th style="width: 20%;">
                                            <i class="fas fa-edit me-1"></i>
                                            Nueva Calificación (0.00-100.00)
                                        </th>
                                        <th style="width: 10%;">
                                            <i class="fas fa-info-circle me-1"></i>
                                            Estado
                                        </th>
                                    </tr>
                                    </thead>
                                    <tbody id="cuerpoCalificacionesMod">
                                    <tr>
                                        <td colspan="6" class="text-center text-muted">
                                            <i class="fas fa-info-circle fa-2x mb-2"></i>
                                            <p class="mb-0">Seleccione parcial, horario y unidad, luego presione "Buscar
                                                Calificaciones"</p>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- Botones de acción -->
                        <div class="row" id="seccionBotonesMod" style="display: none;">
                            <div class="col-12 d-flex justify-content-end gap-2">
                                <button type="button"
                                        id="btnGuardarCambios"
                                        class="btn btn-success"
                                        disabled>
                                    <i class="fas fa-save me-2"></i>Guardar Cambios
                                </button>
                                <button type="button"
                                        id="btnCancelarMod"
                                        class="btn btn-outline-secondary">
                                    <i class="fas fa-times-circle me-2"></i>Cancelar
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Inicializar el módulo de modificar calificaciones cuando el DOM esté listo
    document.addEventListener('DOMContentLoaded', function () {
        console.log('🚀 Inicializando módulo ModificarCalificaciones desde HTML...');
        if (typeof ModificarCalificaciones !== 'undefined') {
            ModificarCalificaciones.inicializar();
        } else {
            console.error('ModificarCalificaciones no está definido. Verifique que el script esté cargado.');
        }
    });
</script>

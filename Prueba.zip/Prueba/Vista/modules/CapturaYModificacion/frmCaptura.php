<?php
//Validar acceso por rol
require_once __DIR__ .'/../../middleware/auth.php';
requireRole("captura.add");
?>


<link rel="stylesheet" href="../css/styleInterno.css">
<link rel="stylesheet" href="../css/captura.css">
<div class="container" id="frmCaptura">
    <div class="row justify-content-center">
        <div class="ampliacion">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-clipboard-check me-2"></i>
                        Captura de Calificaciones
                    </h5>
                </div>
                <div class="card-body p-4">
                    <form id="formCapturaCalificaciones">

                        <!-- Sección de Selección de Criterios -->
                        <div class="row mb-4">
                            <div class="col-md-4 mb-3">
                                <label for="parcialSelect" class="form-label">
                                    Parcial 
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text bg-blue-light">
                                        <i class="fas fa-calendar-check"></i>
                                    </span>
                                    <select id="parcialSelect" class="form-select" required>
                                        <option value="">Seleccione un parcial...</option>
                                        <!-- Opciones se cargarán dinámicamente (solo parciales abiertos) -->
                                    </select>
                                </div>
                                <div class="error-message" id="errorParcial" style="display: none;"></div>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label for="horarioSelect" class="form-label">
                                    Materia
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text bg-blue-light">
                                        <i class="fas fa-clock"></i>
                                    </span>
                                    <select id="horarioSelect" class="form-select" disabled required>
                                        <option value="">Seleccione una materia...</option>
                                        <!-- Opciones se cargarán dinámicamente -->
                                    </select>
                                </div>
                                <div class="error-message" id="errorHorario" style="display: none;"></div>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label for="unidadSelect" class="form-label">
                                    Unidad 
                                </label>
                                <div class="input-group">
                                    <span class="input-group-text bg-blue-light">
                                        <i class="fas fa-book"></i>
                                    </span>
                                    <select id="unidadSelect" class="form-select" disabled required>
                                        <option value="">Seleccione una unidad...</option>
                                        <option value="1">Unidad 1</option>
                                        <option value="2">Unidad 2</option>
                                        <option value="3">Unidad 3</option>
                                        <option value="4">Unidad 4</option>
                                        <option value="5">Unidad 5</option>
                                        <option value="6">Unidad 6</option>
                                        <option value="7">Unidad 7</option>
                                        <option value="8">Unidad 8</option>
                                    </select>
                                </div>
                                <div class="error-message" id="errorUnidad" style="display: none;"></div>
                            </div>
                        </div>

                        <!-- Alerta de estado del parcial -->
                        <div class="row mb-4" id="alertaParcial" style="display: none;">
                            <div class="col-12">
                                <div class="alert alert-warning mb-0" role="alert">
                                    <i class="fas fa-exclamation-triangle me-2"></i>
                                    <strong>Atención:</strong>
                                    <span id="mensajeParcial">El parcial seleccionado no está abierto. No se puede capturar calificaciones.</span>
                                </div>
                            </div>
                        </div>

                        <!-- Información del Horario Seleccionado -->
                        <div class="row mb-4" id="infoHorario" style="display: none;">
                            <div class="col-12">
                                <div class="alert alert-info mb-0">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <i class="fas fa-book-open me-2"></i>
                                            <strong>Materia:</strong> <span id="infoMateria">-</span>
                                        </div>
                                        <div class="col-md-4">
                                            <i class="fas fa-chalkboard-teacher me-2"></i>
                                            <strong>Docente:</strong> <span id="infoDocente">-</span>
                                        </div>
                                        <div class="col-md-4">
                                            <i class="fas fa-users me-2"></i>
                                            <strong>Grupo:</strong> <span id="infoGrupo">-</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Tabla de Alumnos -->
                        <div class="mb-4" id="seccionTabla" style="display: none;">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h6 class="mb-0">
                                    <i class="fas fa-user-graduate me-2"></i>
                                    Alumnos Inscritos
                                    <span class="badge bg-secondary ms-2" id="contadorAlumnos">0</span>
                                </h6>
                                <div>
                                    <span class="badge bg-info me-2" id="promedioCalificaciones"
                                          style="font-size: 0.95rem;">
                                            <i class="fas fa-chart-line me-1"></i>Promedio grupal: --
                                    </span>
                                </div>
                            </div>

                            <div class="table-responsive">
                                <table class="table table-hover table-bordered align-middle" id="tablaAlumnos">
                                    <thead class="table-primary">
                                    <tr>
                                        <th style="width: 15%;">
                                            <i class="fas fa-id-card me-1"></i>
                                            Número de Control
                                        </th>
                                        <th style="width: 35%;">
                                            <i class="fas fa-user me-1"></i>
                                            Nombre Completo
                                        </th>
                                        <th style="width: 10%;">
                                            <i class="fas fa-layer-group me-1"></i>
                                            Semestre del Alumno
                                        </th>
                                        <th style="width: 20%;">
                                            <i class="fas fa-check-circle me-1"></i>
                                            Estado
                                        </th>
                                        <th style="width: 20%;">
                                            <i class="fas fa-star me-1"></i>
                                            Calificación 
                                        </th>
                                    </tr>
                                    </thead>
                                    <tbody id="cuerpoAlumnos">
                                    <tr>
                                        <td colspan="5" class="text-center text-muted">
                                            <i class="fas fa-info-circle fa-2x mb-2"></i>
                                            <p class="mb-0">Seleccione parcial, horario y unidad para cargar los alumnos
                                                automáticamente</p>
                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- Mensaje cuando no hay alumnos -->
                        <div class="row mb-4" id="mensajeSinAlumnos" style="display: none;">
                            <div class="col-12">
                                <div class="alert alert-warning mb-0" role="alert">
                                    <i class="fas fa-users-slash me-2"></i>
                                    <strong>Sin alumnos:</strong> No hay alumnos inscritos en este horario.
                                </div>
                            </div>
                        </div>

                        <!-- Botones de acción -->
                        <div class="row">
                            <div class="col-12 d-flex justify-content-end gap-2">
                                <button type="button"
                                        id="btnGuardarCalificaciones"
                                        class="btn btn-success"
                                        disabled
                                        style="display: none;">
                                    <i class="fas fa-save me-2"></i>Guardar Calificaciones
                                </button>
                                <button type="button"
                                        id="btnCancelar"
                                        class="btn btn-outline-secondary"
                                        onclick="vistasDocente('mostrarCalificaciones','')">
                                    <i class="fas fa-times-circle me-2"></i>Cancelar
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

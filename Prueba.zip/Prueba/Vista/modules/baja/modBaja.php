<?php
//Validar acceso por rol
require_once __DIR__ .'/../../middleware/auth.php';
requireRole("baja.main");
?>

<link rel="stylesheet" href="../css/styleInterno.css">

<div class="container" id="modbaja">
    <div class="row justify-content-center">
        <div class="ampliacion">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-user-minus me-2"></i>
                        Modificar datos de baja
                    </h5>
                </div>
                <div class="card-body p-4">
                    <form>
                        <!-- SECCIÓN 1: INFORMACIÓN DE LA BAJA (Solo lectura) -->
                        <div class="mb-4">
                            <h6 class="text-primary mb-3">
                                <i class="fas fa-info-circle me-2"></i>Información de la Baja
                            </h6>
                            <div class="row">
                                <!-- ID Baja -->
                                <div class="col-md-6 mb-3">
                                    <label for="idBaja" class="form-label">ID Baja</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-blue-light">
                                            <i class="fas fa-hashtag"></i>
                                        </span>
                                        <input
                                                type="text"
                                                class="form-control"
                                                id="idBaja"
                                                disabled>
                                    </div>
                                </div>

                                <!-- ID Alumno -->
                                <div class="col-md-6 mb-3">
                                    <label for="idAlumno" class="form-label">ID Alumno</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-blue-light">
                                            <i class="fas fa-id-card"></i>
                                        </span>
                                        <input
                                                type="text"
                                                class="form-control"
                                                id="idAlumno"
                                                disabled>
                                    </div>
                                </div>

                                <!-- Nombre Alumno -->
                                <div class="col-md-6 mb-3">
                                    <label for="nombreAlumno" class="form-label">Nombre Alumno</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-blue-light">
                                            <i class="fas fa-user"></i>
                                        </span>
                                        <input
                                                type="text"
                                                class="form-control"
                                                id="nombreAlumno"
                                                disabled>
                                    </div>
                                </div>

                                <!-- Tipo Baja -->
                                <div class="col-md-6 mb-3">
                                    <label for="tipoBaja" class="form-label">Tipo de Baja</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-blue-light">
                                            <i class="fas fa-clipboard-list"></i>
                                        </span>
                                        <input
                                                type="text"
                                                class="form-control"
                                                id="tipoBaja"
                                                disabled>
                                    </div>
                                </div>

                                <!-- Estatus -->
                                <div class="col-md-6 mb-3">
                                    <label for="estatus" class="form-label">Estatus</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-blue-light">
                                            <i class="fas fa-check-circle"></i>
                                        </span>
                                        <input
                                                type="text"
                                                class="form-control"
                                                id="estatus"
                                                disabled>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <hr class="my-4">

                        <!-- SECCIÓN 2: DATOS EDITABLES -->
                        <div class="mb-4">
                            <h6 class="text-success mb-3">
                                <i class="fas fa-edit me-2"></i>Datos Editables
                            </h6>
                            <div class="row">
                                <!-- Fecha -->
                                <div class="col-md-6 mb-3 contenedorcampo">
                                    <label for="fecha" class="form-label">Fecha</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-blue-light">
                                            <i class="fas fa-calendar-alt"></i>
                                        </span>
                                        <input
                                                type="date"
                                                class="form-control"
                                                id="fecha"
                                                oninput="verificarInputBaja('fecha', 'btnGuardarBaja')"
                                                required>
                                    </div>
                                </div>

                                <!-- ID Periodo -->
                                <div class="col-md-6 mb-3 contenedorcampo">
                                    <label for="idPeriodo" class="form-label">Periodo</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-blue-light">
                                            <i class="fas fa-calendar"></i>
                                        </span>
                                        <select
                                                id="idPeriodo"
                                                class="form-select listaDespliege"
                                                onchange="retrasoSelectBaja('idPeriodo', 'btnGuardarBaja')">
                                            <option value="">Seleccione un periodo</option>
                                           
                                        </select>
                                    </div>
                                </div>

                                <!-- Motivo -->
                                <div class="col-md-12 mb-3 contenedorcampo">
                                    <label for="motivo" class="form-label">Motivo</label>
                                    <div class="input-group">
                                        <span class="input-group-text bg-blue-light">
                                            <i class="fas fa-comment"></i>
                                        </span>
                                        <textarea
                                                class="form-control"
                                                id="motivo"
                                                rows="3"
                                                maxlength="200"
                                                title="Máximo 200 caracteres. No se permiten caracteres especiales."
                                                placeholder="Ingrese el motivo de la baja"
                                                oninput="verificarInputBaja('motivo', 'btnGuardarBaja')"
                                                required></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Botones -->
                        <div class="row mt-4">
                            <div class="col-12 d-flex gap-2">
                                <button type="button"
                                        id="btnGuardarBaja"
                                        class="btn btn3 btn-primary"
                                        onclick="validarCamposBaja('modificar')"
                                        disabled>
                                    <i class="fas fa-save me-2"></i>Modificar
                                </button>
                                <button type="button"
                                        class="btn btn-outline-secondary"
                                        onclick="goTo('baja','');">
                                    <i class="fas fa-times-circle me-2"></i>Cancelar
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

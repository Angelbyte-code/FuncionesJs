<?php
//Validar acceso por rol
require_once __DIR__ .'/../../middleware/auth.php';
requireRole("baja.main");
?>


<link rel="stylesheet" href="../css/styleInterno.css">

<div class="container" id="frmBajaTemporal">
    <div class="row justify-content-center">
        <div class="ampliacion">
            <div class="card">
                <div class="card-header bg-danger text-white">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-user-minus me-2"></i>
                        Bajas del periodo
                    </h5>
                </div>
                <div class="card-body p-4">
                    <!-- Información del periodo activo -->
                    <div id="infoPeriodo" class="mb-4">
                        <div class="alert alert-success">
                            <h6 class="alert-heading"><i class="fas fa-info-circle me-2"></i>Periodo Abierto</h6>
                            <div class="row">
                                <div class="col-md-6">
                                    <p class="mb-1"><strong>Periodo:</strong> <span id="periodoSeleccionado">AGO-DIC-2025</span>
                                    </p>
                                    <p class="mb-1"><strong>Fecha de inicio:</strong> <span
                                            id="fechaInicio">01/08/2025</span></p>
                                </div>
                                <div class="col-md-6">
                                    <p class="mb-1"><strong>Estado:</strong> <span
                                            class="badge bg-success">Activo</span></p>
                                    <p class="mb-1"><strong>Fecha de cierre:</strong> <span
                                            id="fechaCierre">15/12/2025</span></p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Resumen de alumnos a dar de baja -->
                    <div id="resumenBaja" class="mb-4">
                        <h6 class="mb-3"><i class="fas fa-list-alt me-2"></i>Bajas realizadas durante el periodo
                        </h6>

                        <div class="row g-3 mb-4">
                            <div class="col-md-4">
                                <div class="card border-primary">
                                    <div class="card-body text-center">
                                        <h3 class="text-primary mb-1" id="totalAlumnos">0</h3>
                                        <p class="mb-0 small">Total de Alumnos</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card border-warning">
                                    <div class="card-body text-center">
                                        <h3 class="text-warning mb-1" id="bajasTemporal">0</h3>
                                        <p class="mb-0 small">Bajas Temporales</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card border-danger">
                                    <div class="card-body text-center">
                                        <h3 class="text-danger mb-1" id="bajasDefinitiva">0</h3>
                                        <p class="mb-0 small">Bajas Definitivas</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Tabla de alumnos -->
                        <div class="table-responsive">
                            <table id="bajaTemporal" class="table table-striped table-hover">
                                <thead class="table-dark">
                                <tr>
                                    <th>No. Control</th>
                                    <th>Nombre</th>
                                    <th>Carrera</th>
                                    <th>Semestre</th>
                                    <th>Grupo</th>
                                    <th>Bajas Previas</th>
                                    <th>Tipo de Baja</th>
                                </tr>
                                </thead>
                                <tbody id="tablaAlumnosBajaBody">
                                <!-- Los datos se cargarán dinámicamente -->
                                </tbody>
                            </table>
                        </div>

                    </div>

                    <!-- Botones de acción -->
                    <div class="row" id="botonesAccion">
                        <div class="col-12 separarBotones gap-2">
                            <button type="button"
                                    class="btn btn-outline-secondary"
                                    onclick="cancelarBajaAutomatica();">
                                <i class="fas fa-arrow-left me-2"></i>Regresar
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once dirname(__DIR__, 3) . "/config.php";
require_once dirname(__DIR__, 2) . "/middleware/auth.php";
?>


<link rel="stylesheet" href="../css/styleInterno.css">
<div class="container" id="frmUser">
    <div class="row justify-content-center">
        <div style="width: 75%;">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-key"></i> Cambiar contraseña
                    </h5>
                </div>
                <div class="card-body p-4">
                    <form>
                        <div class="mb-4">
                            <label for="clave" class="form-label">Usuario</label>
                            <div class="input-group">
                                <span class="input-group-text bg-blue-light"> <i class="fas fa-user"></i></span>
                                <input type="hidden" id="idUsuario" value="<?php echo $_SESSION['idUsuario']; ?>" name="idUsuario">
                                <input
                                    type="text"
                                    maxlength="9"
                                    title="Nombre de Usuario."
                                    class="form-control"
                                    id="nombreUsuario"
                                    disabled
                                    placeholder="Nombre de Usuario"
                                    value="<?php echo htmlspecialchars($_SESSION['nombre'] . ' ' . $_SESSION['apellido_paterno'] . ' ' . $_SESSION['apellido_materno']); ?>"
                                     readonly>

                            </div>
                        </div>

                        <!-- Nueva contraseña -->
                        <div class="mb-4">
                            <label class="form-label fw-bold">Nueva contraseña</label>
                            <div class="input-group">
                                <span class="input-group-text bg-blue-light">
                                    <i class="fas fa-lock"></i>
                                </span>

                                <input
                                    type="password"
                                    class="form-control"
                                    id="nuevaPass"
                                    maxlength="20"
                                    name="nuevaPass"
                                    oninput="verificarFortaleza();"
                                    placeholder="Ingrese nueva contraseña"
                                    require>

                                <!-- Botón del ojo -->
                                <button
                                    class="btn btn-outline-secondary"
                                    type="button"
                                    onclick="togglePassword('nuevaPass', this);">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>


                        <!-- Confirmar contraseña -->
                        <div class="mb-4">
                            <label class="form-label fw-bold">Confirmar contraseña</label>
                            <div class="input-group">
                                <span class="input-group-text bg-blue-light">
                                    <i class="fas fa-check-circle"></i>
                                </span>

                                <input
                                    type="password"
                                    class="form-control"
                                    id="confirmarPass"
                                    maxlength="20"
                                    name="confirmarPass"
                                    oninput="activarBTN();"
                                    placeholder="Confirme la contraseña"
                                    require>

                                <!-- Botón del ojo -->
                                <button
                                    class="btn btn-outline-secondary"
                                    type="button"
                                    onclick="togglePassword('confirmarPass', this);">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>

                            <span id="errorPass" class="text-danger d-none">Las contraseñas no coinciden</span>
                        </div>


                        <!-- Medidor -->
                        <div class="mt-2">
                            <div id="barraFortaleza" class="fortaleza-barra"></div>
                            <small id="textoFortaleza" class="fortaleza-texto"></small>
                        </div>


                        <!-- Botones -->
                        <div class="row">
                            <div class="col-12 separarBotones gap-2">
                                <button type="button"
                                    id="btnCambiarPass"
                                    class="btn btn3 btn-primary"
                                    onclick="enviarCambioPassword('<?php echo htmlspecialchars($_SESSION['idUsuario']); ?>');"
                                    disabled>
                                    <i class="fas fa-save me-2"></i>Guardar Cambios
                                </button>
                                <button type="button"
                                    class="btn btn-outline-secondary"
                                    onclick="location.href='index.php';">
                                    <i class="fas fa-times-circle me-2"></i>Cancelar
                                </button>

                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="modalPreview" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content">

            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">Vista previa del archivo</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                <!-- CAMPOS DE INFORMACIÓN -->
                <div class="row g-3 mb-3">

                    <h4 id="tituloActa" class="text-center fw-bold mb-4" style="display:none;">
                        ACTA DE CALIFICACIONES
                    </h4>

                    <div class="col-md-4">
                        <label class="form-label fw-bold">Calendario:</label>
                        <input type="text" id="campoCalendario" class="form-control" readonly>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label fw-bold">Plan:</label>
                        <input type="text" id="campoPlan" class="form-control" readonly>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label fw-bold">Programa:</label>
                        <input type="text" id="campoPrograma" class="form-control" readonly>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label fw-bold">Asignatura:</label>
                        <input type="text" id="campoAsignatura" class="form-control" readonly>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label fw-bold">Docente:</label>
                        <input type="text" id="campoDocente" class="form-control" readonly>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label fw-bold">Grupo:</label>
                        <input type="text" id="campoGrupo" class="form-control" readonly>
                    </div>

                </div>

                <hr>

                <!-- TABLA PREVIEW -->
                <div class="table-responsive">
                    <table id="tablaVistaPrevia" class="table table-bordered table-striped text-center align-middle"></table>
                </div>

            </div>

            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            </div>

        </div>
    </div>
</div>
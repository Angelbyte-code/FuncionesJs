<!-- MODAL IMPORTAR ARCHIVO -->
<div class="modal fade" id="modalImportar" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">

            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">Importar archivo Excel</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body text-center">

                <!-- Zona de carga -->
                <div id="dropZone" class="upload-zone">
                    <div id="zonaCarga">
                        <i class="fas fa-cloud-upload-alt" style="font-size: 40px; color:#0d6efd;"></i>
                        <p class="mt-3 mb-1">Arrastra un archivo aquí</p>
                        <p class="text-muted">o</p>
                    </div>
                    <button class="btn btn-primary" onclick="document.getElementById('fileInput').click()">
                        Examinar archivo
                    </button>

                </div>
                <input type="file" id="fileInput" accept=".xls,.xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" style="display: none;">

                <!-- Lista de archivos -->
                <div id="fileList" class="mt-4"></div>

            </div>

            <div class="modal-footer">
                <button class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                <button class="btn btn-success" id="btnUploadAll">
                    Importar Calificaciones
                </button>
            </div>
        </div>
    </div>
</div>
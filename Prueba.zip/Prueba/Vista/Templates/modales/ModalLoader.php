<!-- Modal de Carga -->
<div id="loaderOverlay" class="loader-overlay">
    <div class="loader-content">
        <div class="spinner"></div>
        <p class="loader-text">
            <?php echo isset($loaderText) ? $loaderText : "Cargando datos..."; ?>
        </p>
    </div>
</div>

<!-- Modal Detalles -->
<div class="modal fade" id="modalDetalles" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title">
          <i class="fas fa-info-circle"></i> Detalles de Calificación
        </h5>
        <button class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <div class="modal-body">

        <h4 id="detalleNombreAlumno" class="text-center mb-3"></h4>
        <h5 id="detalleNombreMateria" class="text-center text-secondary mb-4"></h5>

        <div class="table-responsive">
          <table class="table table-bordered text-center">
            <thead class="table-dark">
              <tr id="detalleHeaderUnidades"></tr>
            </thead>
            <tbody>
              <tr id="detalleValoresUnidades"></tr>
            </tbody>
          </table>
        </div>

      </div>

      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
      </div>

    </div>
  </div>
</div>
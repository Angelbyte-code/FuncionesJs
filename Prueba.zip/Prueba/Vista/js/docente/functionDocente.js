document.addEventListener("DOMContentLoaded", function () {
  console.log("El DOM ya cargó");
  // aquí pones lo que quieras ejecutar
  vistasDocente("mostrarCalificaciones", "");
});

/**
 * Función para cargar contenido dinámicamente en la página
 * @param {string} opc - Opción seleccionada (career, period, etc.)
 * @param {string} filter - Filtro opcional para la consulta
 */
function vistasDocente(opc, filter) {
  try {
    if (typeof $ === "undefined") {
      console.error("jQuery no está cargado");
      alert("Error: jQuery no está disponible");
      return;
    }

    let mainContent = $("#contenidoDocente"); // Usamos jQuery para manipulación más fácil
    if (!mainContent.length) {
      console.error("Elemento mainContent no encontrado");
      return;
    }

    let url = "";
    switch (opc) {
      case "myAccount":
        url = "../modules/InformacionCuenta/main.php";
        break;

      case "mostrarCalificaciones":
        url = "../modules/CapturaCalDocente/main.php";
        break;

      default:
        mainContent.html(
          '<div class="alert alert-warning">Opción no válida</div>'
        );
        return;
    }

    let data = { filter: filter || "" };
    let json = JSON.stringify(data);
    //console.log(`Cargando ${opc} con filtro: ${json}`);

    // Animación: desvanecer el contenido actual antes de limpiarlo
    mainContent.fadeOut(300, function () {
      mainContent
        .html(
          '<div class="text-center"><i class="fas fa-spinner fa-spin fa-3x"></i><p class="mt-2">Cargando...</p></div>'
        )
        .fadeIn(200);

      $.ajax({
        url: url,
        type: "POST",
        data: json,
         headers: {
          "X-Requested-With": "XMLHttpRequest",
        },
        contentType: "application/json",
        timeout: 10000, // 10 segundos de timeout
        success: function (responseText) {
          // Animación: desvanecer el spinner antes de mostrar el nuevo contenido
          mainContent.fadeOut(300, function () {
            mainContent.html(responseText).fadeIn(300);

            // Inicializar DataTables después de la animación
            if ($.fn.DataTable) {
              try {
                const commonConfig = {
                  responsive: true,
                  pageLength: 25,
                  order: [[0, "desc"]],
                  pagingType: "simple_numbers",
                  lengthMenu: [
                    [25, 50, 100, -1],
                    [25, 50, 100, "Todos"],
                  ],
                  language: {
                    url: "../library/dataTables/es-ES.json",
                    paginate: {
                      previous: "Anterior",
                      next: "Siguiente",
                    },
                  },
                };

                if (
                  opc === "mostrarCalificaciones" &&
                  $("#tableAsignatura").length
                ) {
                  $("#tableAsignatura").DataTable({
                    ...commonConfig,
                    language: {
                      url: "../library/dataTables/es-ES.json",
                      emptyTable:
                        "No hay registros de asignaturas disponibles para mostrar",
                    },
                  });
                }
              } catch (tableError) {
                console.error("Error al inicializar DataTable:", tableError);
              }
            }
          });
        },
          error: function (xhr, status, error) {
          // SESIÓN INVÁLIDA O USUARIO INACTIVO
          if (xhr.status === 401) {
            try {
              const data = JSON.parse(xhr.responseText);
              window.location.href =
                "../login.php?estado=" + encodeURIComponent(data.reason);
              return;
            } catch (e) {
              window.location.href = "../login.php?estado=session_error";
              return;
            }
          }

          // ROL INVÁLIDO (USUARIO AUTENTICADO, PERO SIN PERMISOS)
          if (xhr.status === 403) {
            mainContent.fadeOut(200, function () {
              mainContent.html(""); // <-- LIMPIAR VISTA COMPLETAMENTE

              mainContent
                .html(
                  `
            <div class="alert alert-warning mt-4">
                <h4>No tienes permisos para acceder a este módulo.</h4>
                <p>Contacta al administrador si crees que esto es un error.</p>
            </div>
        `
                )
                .fadeIn(200);
            });
            return;
          }

          // OTROS ERRORES
          mainContent.fadeOut(300, function () {
            mainContent
              .html(
                `
            <div class="alert alert-danger">
                <h4>Error al cargar el contenido</h4>
                <p>Estado: ${status}</p>
                <p>Error: ${error}</p>
            </div>
        `
              )
              .fadeIn(300);
          });
        },
      });
    });
  } catch (e) {
    console.error("Error general:", e);
    alert("Ocurrió un error: " + e.message);
  }
}

function clearArea(myArea) {
  document.getElementById(myArea).innerHTML = "";
}

document.addEventListener("DOMContentLoaded", function () {
  const menuToggle = document.getElementById("menuToggle");
  const sidebar = document.getElementById("sidebar");

  if (menuToggle && sidebar) {
    menuToggle.addEventListener("click", function () {
      sidebar.classList.toggle("show");
    });

    // Cerrar menú al hacer clic en un enlace (en dispositivos móviles)
    const navLinks = sidebar.querySelectorAll(".nav-link");
    navLinks.forEach(function (link) {
      link.addEventListener("click", function () {
        if (window.innerWidth < 992) {
          sidebar.classList.remove("show");
        }
      });
    });

    // Cerrar menú al hacer clic fuera del mismo
    document.addEventListener("click", function (event) {
      const isClickInsideMenu = sidebar.contains(event.target);
      const isClickOnToggle = menuToggle.contains(event.target);

      if (
        !isClickInsideMenu &&
        !isClickOnToggle &&
        sidebar.classList.contains("show")
      ) {
        sidebar.classList.remove("show");
      }
    });
  }

  // Ajustar diseño cuando cambia el tamaño de la ventana
  window.addEventListener("resize", function () {
    if (window.innerWidth >= 992 && sidebar.classList.contains("show")) {
      sidebar.classList.remove("show");
    }
  });
});

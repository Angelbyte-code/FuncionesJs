//Autor Miguel Angel Lara Hermosillo
//Fecha de creación: 28/04/2024
//Descripción: Función para cargar los formularios de captura y modificación de datos por parte del docente rol docente.


function cargaFormDocenteCaptura(opc, id = "") {
    let url = "";
    if (opc === "frmCaptura") {
        url = "../modules/CapturaYModificacion/frmCaptura.php";
    } else if (opc === "modCaptura") {
        url = "../modules/CapturaYModificacion/modCaptura.php";
    }

    let datas = {id: id};

    let container = $("#frmArea");

    container.fadeOut(300, function () {
        clearArea("frmArea");

        $.post(url, JSON.stringify(datas), function (responseText, status) {
            try {
                if (status === "success") {
                    container
                        .html(responseText)
                        .hide()
                        .fadeIn(500, function () {
                        })
                        .css("transform", "translateY(-10px)")
                        .animate(
                            {
                                opacity: 1,
                                transform: "translateY(0px)",
                            },
                            300
                        );
                }
            } catch (e) {
                mostrarErrorCaptura("Error al cargar el formulario: " + e);
            }
        }).fail(function (jqXHR, textStatus, errorThrown) {
            mostrarErrorCaptura(
                "Error de conexión: " + textStatus + " - " + errorThrown
            );
        });
    });
}
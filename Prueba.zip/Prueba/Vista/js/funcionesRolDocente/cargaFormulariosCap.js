//Autor Miguel Angel Lara Hermosillo
//Fecha de creación: 28/04/2024
//Descripción: Función para cargar los formularios de captura y modificación de datos por parte del docente rol docente.

function cargaFormDocenteCaptura(opc, id = "") {
  let url = "";
  if (opc === "frmCaptura") {
    url = "../modules/CapturaCalDocente/frmCaptura.php";
  } else if (opc === "modCaptura") {
    url = "../modules/CapturaCalDocente/modCaptura.php";
  }

  let datas = { id: id };

  let container = $("#frmArea");

  container.fadeOut(300, function () {
    clearArea("frmArea");

    $.post(url, JSON.stringify(datas), function (responseText, status) {
      try {
        if (status === "success") {
          container
            .html(responseText)
            .hide()
            .fadeIn(500, function () {})
            .css("transform", "translateY(-10px)")
            .animate(
              {
                opacity: 1,
                transform: "translateY(0px)",
              },
              300
            );
          // Aquí puedes agregar cualquier inicialización adicional que necesites
          // Inicializar el módulo de captura de calificaciones
          if (
            opc === "frmCaptura" &&
            typeof CapturaCalificaciones !== "undefined"
          ) {
            CapturaCalificaciones.inicializar();
          }
          // Inicializar el módulo de modificar calificaciones con el ID
          if (
            opc === "modCaptura" &&
            typeof ModificarCalificaciones !== "undefined"
          ) { 
            ModificarCalificaciones.inicializar(id);
          }
        }
      } catch (e) {
        mostrarErrorCaptura("Error al cargar el formulario: " + e);
      }
    }).fail(function (jqXHR, textStatus, errorThrown) {
      mostrarErrorCaptura(
        "Error de conexión: " + textStatus + " - " + errorThrown
      );
    });
  });
}

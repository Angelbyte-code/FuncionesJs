function inicializarDataTableCapturaJefe() {
  //  ACTIVAR DATATABLES EN TODAS LAS TABLAS DE CALIFICACIONES
  const commonConfig = {
    responsive: true,
    pageLength: 5,
    lengthMenu: [
      [5, 10, 25, -1],
      [5, 10, 25, "Todos"],
    ],
    language: {
      url: "../library/dataTables/es-ES.json",
      paginate: {
        previous: "Anterior",
        next: "Siguiente",
      },
    },
    pagingType: "simple",
  };

  // Seleccionar TODAS las tablas generadas dinámicamente
  const tablas = document.querySelectorAll(".calificacion-table");

  tablas.forEach((tabla, index) => {
    if (!tabla.id) tabla.id = "tablaCalificaciones" + index;
    $(tabla).DataTable(commonConfig);
  });

  // 2 PAGINACIÓN ENTRE CARRERAS
  const carreras = document.querySelectorAll(".carrera-section");
  const pagination = document.getElementById("paginationCarreras");

  if (carreras.length > 1) {
    generarPaginacion(carreras, pagination);
    mostrarCarrera(0, carreras);
  }
}

/* ============================
   FUNCIONES PARA PAGINAR CARRERAS
   ============================ */

function generarPaginacion(carreras, paginationContainer) {
  paginationContainer.innerHTML = "";

  carreras.forEach((carrera, index) => {
    let li = document.createElement("li");
    li.className = "page-item";
    li.innerHTML = `
            <a class="page-link" href="#" onclick="mostrarCarrera(${index})">${
      index + 1
    }</a>
        `;
    paginationContainer.appendChild(li);
  });
}

function mostrarCarrera(indice) {
  const carreras = document.querySelectorAll(".carrera-section");

  carreras.forEach((carrera, i) => {
    carrera.style.display = i === indice ? "block" : "none";
  });

  const items = document.querySelectorAll("#paginationCarreras .page-item");
  items.forEach((li, i) => {
    li.classList.toggle("active", i === indice);
  });
}

//fetch para Importar calificacion en jefe de carrera

//Funcion para obtener las carreras que le pertenecen al jefe de carrera

async function cargarCarrerasJefe() {
  try {
    const response = await fetch(
      "../../Controlador/Intermediarios/captura/Captura.php",
      {
        method: "POST",
        headers: {
          Accept: "application/json",
        },
      }
    );

    if (!response.ok) {
      throw new Error("Error al obtener las carreras");
    }

    const carreras = await response.json();
    renderCarreras(carreras);
  } catch (error) {
    console.error(error);
  }
}

//Funcion para renderizar las carreras y materias en el Modulo de capaptura de calificaciones del jefe de carrera
//Funcion para renderizar las carreras y materias en el Modulo de capaptura de calificaciones del jefe de carrera
function renderCarreras(carreras) {
  const container = document.getElementById("tablasContainer");
  container.innerHTML = "";

  carreras.forEach((carrera) => {
    const section = document
      .getElementById("tplCarreraSection")
      .content.cloneNode(true);

    const carreraDiv = section.querySelector(".carrera-section");
    carreraDiv.dataset.idCarrera = carrera.idCarrera;

    section.querySelector(".carrera-nombre").textContent =
      carrera.nombreCarrera;

    const tbody = section.querySelector("tbody");

    carrera.materias.forEach((materia) => {
      const row = document
        .getElementById("tplRowMateria")
        .content.cloneNode(true);
      const tr = row.querySelector("tr");

      tr.dataset.idCarrera = carrera.idCarrera;
      tr.dataset.idPeriodo = materia.idPeriodo;
      tr.dataset.idMateria = materia.claveMateria;
      tr.dataset.idDocente = materia.idDocente;
      tr.dataset.idGrupo = materia.grupo;

      row.querySelector(".materia-clave").textContent = materia.claveMateria;
      row.querySelector(".materia-nombre").textContent = materia.nombreMateria;
      row.querySelector(".periodo-nombre").textContent = materia.nombrePeriodo;
      row.querySelector(".hdn-id-periodo").value = materia.idPeriodo;
      row.querySelector(".grupo-nombre").textContent = materia.grupo;
      row.querySelector(".docente-nombre").textContent = materia.docente;
      row.querySelector(".hdn-id-carrera").value = carrera.idCarrera;

      tbody.appendChild(row);
      const estadoSpan = tr.querySelector(".estado-captura");

      if (estadoSpan) {
        if (materia.capturaRealizada) {
          estadoSpan.innerHTML = `
      <i class="fas fa-check-circle text-success"
         title="Calificaciones ya importadas"></i>
    `;
        } else {
          estadoSpan.innerHTML = `
      <i class="fas fa-exclamation-triangle text-warning"
         title="Calificaciones pendientes"></i>
    `;
        }
      }
    });

    container.appendChild(section);
  });

  inicializarDataTableCapturaJefe();
  iniciarListenersCapturaJefe();
}

function iniciarListenersCapturaJefe() {
  document
    .getElementById("tablasContainer")
    .addEventListener("click", function (e) {
      const btn = e.target.closest(
        '[data-action="ver"], .btn-ver-calificaciones'
      );
      if (!btn) return;

      let fila = btn.closest("tr");

      // CORRECCIÓN CLAVE PARA RESPONSIVE
      if (fila && fila.classList.contains("child")) {
        fila = fila.previousElementSibling;
      }

      if (!fila) return;

      const datosDeTablaEnBr = {
        idCarrera: fila.dataset.idCarrera,
        idMateria: fila.dataset.idMateria,
        idPeriodo: fila.dataset.idPeriodo,
        idDocente: fila.dataset.idDocente,

      };

      console.log("Datos de la tabla en BR:", datosDeTablaEnBr);
    });

  document
    .getElementById("tablasContainer")
    .addEventListener("click", function (e) {
      const btn = e.target.closest(
        '[data-action="importar"], .btn-importar-calificaciones'
      );
      if (!btn) return;

      let fila = btn.closest("tr");

      // CORRECCIÓN CLAVE PARA RESPONSIVE
      if (fila && fila.classList.contains("child")) {
        fila = fila.previousElementSibling;
      }

      if (!fila) return;

      const datos = {
        idCarrera: fila.dataset.idCarrera,
        idMateria: fila.dataset.idMateria,
        idPeriodo: fila.dataset.idPeriodo,
        idDocente: fila.dataset.idDocente,
      };
      buscarArchivoImportado(datos);
    });
}


//Funcion para Importar datos de calificaciones
async function importarCalificacionesJefeCarrera(datos, id) {
}


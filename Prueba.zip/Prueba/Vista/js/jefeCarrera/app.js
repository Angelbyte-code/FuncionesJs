function inicializarDataTableCapturaJefe() {
    //  ACTIVAR DATATABLES EN TODAS LAS TABLAS DE CALIFICACIONES
    const commonConfig = {
        responsive: true,
        pageLength: 5,
        lengthMenu: [
            [5, 10, 25, -1],
            [5, 10, 25, "Todos"]
        ],
        language: {
            url: "../library/dataTables/es-ES.json",
            paginate: {
                previous: "Anterior",
                next: "Siguiente",
            },
        },
        pagingType: "simple"
    };

    // Seleccionar TODAS las tablas generadas dinámicamente
    const tablas = document.querySelectorAll(".calificacion-table");

    tablas.forEach((tabla, index) => {
        if (!tabla.id) tabla.id = "tablaCalificaciones" + index;
        $(tabla).DataTable(commonConfig);
    });

    // 2️⃣ PAGINACIÓN ENTRE CARRERAS
    const carreras = document.querySelectorAll(".carrera-section");
    const pagination = document.getElementById("paginationCarreras");

    if (carreras.length > 1) {
        generarPaginacion(carreras, pagination);
        mostrarCarrera(0, carreras);
    }

}

/* ============================
   FUNCIONES PARA PAGINAR CARRERAS
   ============================ */

function generarPaginacion(carreras, paginationContainer) {
    paginationContainer.innerHTML = "";

    carreras.forEach((carrera, index) => {
        let li = document.createElement("li");
        li.className = "page-item";
        li.innerHTML = `
            <a class="page-link" href="#" onclick="mostrarCarrera(${index})">${index + 1}</a>
        `;
        paginationContainer.appendChild(li);
    });
}

function mostrarCarrera(indice) {
    const carreras = document.querySelectorAll(".carrera-section");

    carreras.forEach((carrera, i) => {
        carrera.style.display = (i === indice) ? "block" : "none";
    });

    const items = document.querySelectorAll("#paginationCarreras .page-item");
    items.forEach((li, i) => {
        li.classList.toggle("active", i === indice);
    });
}


//DropZone para subir archivos de calificaciones

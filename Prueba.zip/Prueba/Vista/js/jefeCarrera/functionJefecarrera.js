/**
 * Función para cargar contenido dinámicamente en la página
 * @param {string} opc - Opción seleccionada (career, period, etc.)
 * @param {string} filter - Filtro opcional para la consulta
 */
function modulosJefeCarrera(opc, filter) {
  try {
    if (typeof $ === "undefined") {
      console.error("jQuery no está cargado");
      alert("Error: jQuery no está disponible");
      return;
    }

    let mainContent = $("#mainContent"); // Usamos jQuery para manipulación más fácil
    if (!mainContent.length) {
      console.error("Elemento mainContent no encontrado");
      return;
    }

    let url = "";
    switch (opc) {
      case "myAccount":
        url = "../modules/InformacionCuenta/main.php";
        break;
      case "carrera":
        url = "../modules/carrera/main.php";
        break;
      case "materia":
        url = "../modules/materia/main.php";
        break;
      case "oferta":
        url = "../modules/oferta/main.php";
        break;
      case "student":
        url = "../modules/alumno/main.php";
        break;
      case "horario":
        url = "../modules/horario/main.php";
        break;
      case "baja":
        url = "../modules/baja/main.php";
        break;
      case "captura":
        url = "../modules/mostrarCalJefe/CapturaJefe.php";
        break;
      case "bajaTemporal":
        url = "../modules/baja/bajaTemporal.html";
        break;
      
      case "cierreAjustes":
        aplicarCierreAjustes();
        return;
      default:
        mainContent.html(
          '<div class="alert alert-warning">Opción no válida</div>'
        );
        return;
    }

    let data = { filter: filter || "" };
    let json = JSON.stringify(data);
    //console.log(`Cargando ${opc} con filtro: ${json}`);

    // Animación: desvanecer el contenido actual antes de limpiarlo
    mainContent.fadeOut(300, function () {
      mainContent
        .html(
          '<div class="text-center"><i class="fas fa-spinner fa-spin fa-3x"></i><p class="mt-2">Cargando...</p></div>'
        )
        .fadeIn(200);

      $.ajax({
        url: url,
        type: "POST",
        data: json,
        headers: {
          "X-Requested-With": "XMLHttpRequest",
        },
        contentType: "application/json",
        timeout: 10000, // 10 segundos de timeout
        success: function (responseText) {
          // Animación: desvanecer el spinner antes de mostrar el nuevo contenido
          mainContent.fadeOut(300, function () {
            mainContent.html(responseText).fadeIn(300);

            // Llamar a obtenerPeriodo después de que el contenido se ha cargado
            obtenerPeriodo();

            // Inicializar DataTables después de la animación
            if ($.fn.DataTable) {
              try {
                const commonConfig = {
                  responsive: true,
                  pageLength: 25,
                  order: [[0, "desc"]],
                  pagingType: "simple_numbers",
                  lengthMenu: [
                    [25, 50, 100, -1],
                    [25, 50, 100, "Todos"],
                  ],
                  language: {
                    url: "../library/dataTables/es-ES.json",
                    paginate: {
                      previous: "Anterior",
                      next: "Siguiente",
                    },
                  },
                };
                if (opc === "student" && $("#tableAlumnos").length) {
                  $("#tableAlumnos").DataTable({
                    ...commonConfig,
                    columnDefs: [
                      { searchable: true, targets: [0, 1] },
                      { searchable: false, targets: "_all" },
                    ],
                  });
                }
                if (opc === "docente" && $("#tableDocente").length) {
                  $("#tableDocente").DataTable({
                    ...commonConfig,
                    language: {
                      url: "../library/dataTables/es-ES.json",
                      emptyTable:
                        "No hay registros por el momento de Docentes para Mostrar",
                    },
                    columnDefs: [
                      { searchable: true, targets: [0, 1] },
                      { searchable: false, targets: "_all" },
                    ],
                  });
                }
                if (
                  opc === "career-manager" &&
                  $("#tableCareerManager").length
                ) {
                  $("#tableCareerManager").DataTable({
                    ...commonConfig,
                    language: {
                      url: "../library/dataTables/es-ES.json",
                      emptyTable:
                        "No hay registros por el momento de Jefe de Carrera para Mostrar",
                    },
                    columnDefs: [
                      { searchable: true, targets: [1] },
                      { searchable: false, targets: "_all" },
                    ],
                  });
                }
                if (opc === "period" && $("#tablePeriod").length) {
                  $("#tablePeriod").DataTable({
                    ...commonConfig,
                    language: {
                      url: "../library/dataTables/es-ES.json",
                      emptyTable:
                        "No hay registros por el momento de Periodos para Mostrar",
                    },
                    columnDefs: [
                      { searchable: true, targets: [1] },
                      { searchable: false, targets: "_all" },
                    ],
                  });
                }

                if (opc === "carrera" && $("#tableCarrera").length) {
                  $("#tableCarrera").DataTable({
                    ...commonConfig,
                    language: {
                      url: "../library/dataTables/es-ES.json",
                      emptyTable:
                        "No hay registros por el momento de Carreras para Mostrar",
                    },
                    columnDefs: [
                      { searchable: true, targets: [0, 1] },
                      { searchable: false, targets: "_all" },
                    ],
                  });
                }

                if (opc === "materia" && $("#tableMateria").length) {
                  $("#tableMateria").DataTable({
                    ...commonConfig,
                    language: {
                      url: "../library/dataTables/es-ES.json",
                      emptyTable:
                        "No hay registros por el momento de Materias para Mostrar",
                    },
                    columnDefs: [
                      { searchable: true, targets: [0, 1] },
                      { searchable: false, targets: "_all" },
                    ],
                  });
                }

                if (opc === "oferta" && $("#tableOferta").length) {
                  $("#tableOferta").DataTable({
                    ...commonConfig,
                    language: {
                      url: "../library/dataTables/es-ES.json",
                      emptyTable:
                        "No hay registros por el momento de ofertas para mostrar",
                    },
                    columnDefs: [
                      { searchable: true, targets: [0, 1, 2, 3, 5, 7] },
                      { searchable: false, targets: "_all" },
                    ],
                  });
                }
                if (opc === "horario" && $("#tableHorario").length) {
                  $("#tableHorario").DataTable({
                    ...commonConfig,
                    language: {
                      url: "../library/dataTables/es-ES.json",
                      emptyTable:
                        "No hay registros por el momento de Horarios para Mostrar",
                    },
                    columnDefs: [
                      { searchable: true, targets: [0, 1, 2, 3, 4] },
                      { searchable: false, targets: "_all" },
                    ],
                  });
                }
                if (
                  opc === "horario" &&
                  document.querySelector(".carrera-section")
                ) {
                  setTimeout(() => {
                    if (typeof window.HorarioCarreraManager !== "undefined") {
                      // Destruir instancia anterior si existe
                      if (
                        window.horarioManagerInstance &&
                        typeof window.horarioManagerInstance.destroy ===
                          "function"
                      ) {
                        window.horarioManagerInstance.destroy();
                      }
                      // Crear nueva instancia
                      window.horarioManagerInstance =
                        new window.HorarioCarreraManager();
                      console.log(
                        "HorarioCarreraManager inicializado correctamente"
                      );
                    } else {
                      console.warn("HorarioCarreraManager no está disponible");
                    }
                  }, 200); // Pequeño delay para asegurar que todo esté cargado
                }
                if (opc === "parcial" && $("#tableParcial").length) {
                  $("#tableParcial").DataTable({
                    ...commonConfig,
                    language: {
                      url: "../library/dataTables/es-ES.json",
                      emptyTable:
                        "No hay registros por el momento de Parciales para Mostrar",
                    },
                    columnDefs: [
                      { searchable: true, targets: [1] },
                      { searchable: false, targets: "_all" },
                    ],
                  });
                }

                if (opc === "bajaTemporal" && $("#bajaTemporal").length) {
                  // Primero cargar los datos
                  if (typeof cargarPeriodoActivoBaja === "function") {
                    cargarPeriodoActivoBaja();
                  }

                  // Luego inicializar DataTable
                  $("#bajaTemporal").DataTable({
                    ...commonConfig,
                    language: {
                      url: "../library/dataTables/es-ES.json",
                      emptyTable:
                        "No hay registros por el momento de Baja Temporal para Mostrar",
                    },
                  });
                }

                if (opc === "captura") {
                  inicializarDataTableCapturaJefe();
                }
                if (opc === "baja" && $("#tablaBajas").length) {
                  $("#tablaBajas").DataTable({
                    ...commonConfig,
                    language: {
                      url: "../library/dataTables/es-ES.json",
                      emptyTable:
                        "No hay registros por el momento de Bajas para Mostrar",
                    },
                    columnDefs: [
                      { searchable: true, targets: [1] },
                      { searchable: false, targets: "_all" },
                    ],
                  });
                }
                $("table.dataTable")
                  .not("#tableCareer, #tableCareerManager, #tablePeriod")
                  .each(function () {
                    if (!$.fn.DataTable.isDataTable(this)) {
                      $(this).DataTable(commonConfig);
                    }
                  });
              } catch (tableError) {
                console.error("Error al inicializar DataTable:", tableError);
              }
            }
          });
        },
        error: function (xhr, status, error) {
          // SESIÓN INVÁLIDA O USUARIO INACTIVO
          if (xhr.status === 401) {
            try {
              const data = JSON.parse(xhr.responseText);
              window.location.href =
                "../login.php?estado=" + encodeURIComponent(data.reason);
              return;
            } catch (e) {
              window.location.href = "../login.php?estado=session_error";
              return;
            }
          }

          // ROL INVÁLIDO (USUARIO AUTENTICADO, PERO SIN PERMISOS)
          if (xhr.status === 403) {
            mainContent.fadeOut(200, function () {
              mainContent.html(""); // <-- LIMPIAR VISTA COMPLETAMENTE

              mainContent
                .html(
                  `
            <div class="alert alert-warning mt-4">
                <h4>No tienes permisos para acceder a este módulo.</h4>
                <p>Contacta al administrador si crees que esto es un error.</p>
            </div>
        `
                )
                .fadeIn(200);
            });
            return;
          }

          // OTROS ERRORES
          mainContent.fadeOut(300, function () {
            mainContent
              .html(
                `
            <div class="alert alert-danger">
                <h4>Error al cargar el contenido</h4>
                <p>Estado: ${status}</p>
                <p>Error: ${error}</p>
            </div>
        `
              )
              .fadeIn(300);
          });
        },
      });
    });
  } catch (e) {
    console.error("Error general:", e);
    alert("Ocurrió un error: " + e.message);
  }
}

document.addEventListener("DOMContentLoaded", function () {
  const menuToggle = document.getElementById("menuToggle");
  const sidebar = document.getElementById("sidebar");

  if (menuToggle && sidebar) {
    menuToggle.addEventListener("click", function () {
      sidebar.classList.toggle("show");
    });

    // Cerrar menú al hacer clic en un enlace (en dispositivos móviles)
    const navLinks = sidebar.querySelectorAll(".nav-link");
    navLinks.forEach(function (link) {
      link.addEventListener("click", function () {
        if (window.innerWidth < 992) {
          sidebar.classList.remove("show");
        }
      });
    });

    // Cerrar menú al hacer clic fuera del mismo
    document.addEventListener("click", function (event) {
      const isClickInsideMenu = sidebar.contains(event.target);
      const isClickOnToggle = menuToggle.contains(event.target);

      if (
        !isClickInsideMenu &&
        !isClickOnToggle &&
        sidebar.classList.contains("show")
      ) {
        sidebar.classList.remove("show");
      }
    });
  }

  // Ajustar diseño cuando cambia el tamaño de la ventana
  window.addEventListener("resize", function () {
    if (window.innerWidth >= 992 && sidebar.classList.contains("show")) {
      sidebar.classList.remove("show");
    }
  });
});

function clearArea(myArea) {
  document.getElementById(myArea).innerHTML = "";
}

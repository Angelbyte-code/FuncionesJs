/**
 * Modales que se utilizan en la aplicación
 */
/**
 * Función para mostrar ventana modal de confirmación
 * @param {string} mensaje - Mensaje de confirmación a mostrar
 * @param {Function} onConfirm - Función a ejecutar al confirmar
 * @param {Function} onCancel - Función a ejecutar al cancelar (opcional)
 */
function mostrarConfirmacion(mensaje, onConfirm, onCancel) {
    // Crear el contenido del modal
    let modalHTML = `
    <div class="modal fade" id="confirmacionModal" tabindex="-1" aria-labelledby="confirmacionModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-warning text-dark">
                    <h5 class="modal-title" id="confirmacionModalLabel">
                        <i class="fas fa-exclamation-triangle me-2"></i>Confirmar Acción
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-3">
                        <i class="fas fa-question-circle text-warning fa-4x"></i>
                    </div>
                    <p class="text-center">${mensaje || '¿Está seguro que desea continuar?'}</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" id="btnCancelarConfirmacion" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-warning" id="btnConfirmarAccion">Sí, continuar</button>
                </div>
            </div>
        </div>
    </div>`;

    // Remover modal anterior si existe
    let modalAnterior = document.getElementById("confirmacionModal");
    if (modalAnterior) {
        modalAnterior.remove();
    }

    // Agregar el modal al documento
    document.body.insertAdjacentHTML("beforeend", modalHTML);

    // Mostrar el modal
    let modalElement = document.getElementById("confirmacionModal");
    let modal = new bootstrap.Modal(modalElement);
    modal.show();

    // Configurar callback de confirmación
    if (typeof onConfirm === "function") {
        document.getElementById("btnConfirmarAccion").addEventListener("click", function () {
            modal.hide();
            onConfirm();
        });
    }

    // Configurar callback de cancelación
    if (typeof onCancel === "function") {
        document.getElementById("btnCancelarConfirmacion").addEventListener("click", function () {
            onCancel();
        });
    }

    // Eliminar el modal del DOM cuando se cierre
    modalElement.addEventListener("hidden.bs.modal", function () {
        modalElement.remove();
    });
}

/**
 * Función para mostrar ventana modal de error de captura
 * @param {string} mensaje - Mensaje de error a mostrar
 */
function mostrarErrorCaptura(mensaje) {
    // Crear el contenido del modal
    let modalHTML = `
    <div class="modal fade" id="errorCapturaModal" tabindex="-1" aria-labelledby="errorCapturaModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="errorCapturaModalLabel">
                        <i class="fas fa-exclamation-triangle me-2"></i>Error de Captura
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-3">
                        <i class="fas fa-times-circle text-danger fa-4x"></i>
                    </div>
                    <p class="text-center">${
        mensaje ||
        "Se ha producido un error durante la captura de datos."
    }</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>`;

    // Remover modal anterior si existe
    let modalAnterior = document.getElementById("errorCapturaModal");
    if (modalAnterior) {
        modalAnterior.remove();
    }

    // Agregar el modal al documento
    document.body.insertAdjacentHTML("beforeend", modalHTML);

    // Mostrar el modal
    let modalElement = document.getElementById("errorCapturaModal");
    let modal = new bootstrap.Modal(modalElement);
    modal.show();

    // Eliminar el modal del DOM cuando se cierre
    modalElement.addEventListener("hidden.bs.modal", function () {
        modalElement.remove();
    });
}

/**
 * Función para mostrar ventana de alerta por falta de datos
 * @param {string} mensaje - Mensaje específico sobre los datos faltantes
 * @param {Function} callback - Función a ejecutar al confirmar (opcional)
 */
function mostrarFaltaDatos(mensaje, callback) {
    // Crear el contenido del modal
    let modalHTML = `
    <div class="modal fade" id="faltaDatosModal" tabindex="-1" aria-labelledby="faltaDatosModalLabel" >
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-warning text-dark">
                    <h5 class="modal-title" id="faltaDatosModalLabel">
                        <i class="fas fa-exclamation-circle me-2"></i>Datos Incompletos
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-3 me-3">
                        <i class="fas fa-clipboard-list text-warning fa-4x"></i>
                    </div>
                    <p class="text-center">${
        mensaje ||
        "Hay campos obligatorios sin completar. Por favor, revise el formulario."
    }</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" id="btnEntendido" data-bs-dismiss="modal">Entendido</button>
                </div>
            </div>
        </div>
    </div>`;

    // Remover modal anterior si existe
    let modalAnterior = document.getElementById("faltaDatosModal");
    if (modalAnterior) {
        modalAnterior.remove();
    }

    // Agregar el modal al documento
    document.body.insertAdjacentHTML("beforeend", modalHTML);

    // Mostrar el modal
    let modalElement = document.getElementById("faltaDatosModal");
    let modal = new bootstrap.Modal(modalElement);
    modal.show();

    // Configurar callback si se proporciona
    if (typeof callback === "function") {
        document.getElementById("btnEntendido").addEventListener("click", callback);
    }

    // Eliminar el modal del DOM cuando se cierre
    modalElement.addEventListener("hidden.bs.modal", function () {
        modalElement.remove();
    });
}

/**
 * Función para mostrar ventana de éxito cuando se guardan datos
 * @param {string} mensaje - Mensaje de éxito a mostrar
 * @param {Function} callback - Función a ejecutar al confirmar (opcional)
 */
function mostrarDatosGuardados(mensaje, callback) {
    // Crear el contenido del modal
    let modalHTML = `
    <div class="modal fade" id="datosGuardadosModal" tabindex="-1" aria-labelledby="datosGuardadosModalLabel">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title" id="datosGuardadosModalLabel">
                        <i class="fas fa-check-circle me-2"></i>Operación Exitosa
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-3 me-4">
                        <i class="fas fa-save text-success fa-4x"></i>
                    </div>
                    <p class="text-center">${
        mensaje || "Los datos se han guardado correctamente."
    }</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" id="btnAceptar" data-bs-dismiss="modal">Aceptar</button>
                </div>
            </div>
        </div>
    </div>`;

    // Remover modal anterior si existe
    let modalAnterior = document.getElementById("datosGuardadosModal");
    if (modalAnterior) {
        modalAnterior.remove();
    }

    // Agregar el modal al documento
    document.body.insertAdjacentHTML("beforeend", modalHTML);

    // Mostrar el modal
    let modalElement = document.getElementById("datosGuardadosModal");
    let modal = new bootstrap.Modal(modalElement);
    modal.show();

    // Configurar callback si se proporciona
    if (typeof callback === "function") {
        document.getElementById("btnAceptar").addEventListener("click", callback);
    }

    // Eliminar el modal del DOM cuando se cierre
    modalElement.addEventListener("hidden.bs.modal", function () {
        modalElement.remove();
    });
}

function errorActualizacion(mensaje) {
    // Crear el contenido del modal
    let modalHTML = ` 
    <div class="modal fade" id="errorActualizacionModal" tabindex="-1" aria-labelledby="errorActualizacionModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="errorActualizacionModalLabel">
                        <i class="fas fa-exclamation-triangle me-2"></i>STATUS NO PERMITIDO
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-2 me-5">
                        <i class="fas fa-times-circle text-danger fa-4x"></i>
                    </div>
                    <p class="text-center text-danger">${mensaje}</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>`;

    // Remover modal anterior si existe
    let modalAnterior = document.getElementById("errorActualizacionModal");
    if (modalAnterior) {
        modalAnterior.remove();
    }

    // Agregar el modal al documento
    document.body.insertAdjacentHTML("beforeend", modalHTML);

    // Mostrar el modal
    let modalElement = document.getElementById("errorActualizacionModal");
    let modal = new bootstrap.Modal(modalElement);
    modal.show();

    // Eliminar el modal del DOM cuando se cierre
    modalElement.addEventListener("hidden.bs.modal", function () {
        modalElement.remove();
    });
}

$(document).on("click", ".btnEditar", function () {
    let id = $(this).data("id");
    console.log("Click en editar. ID del periodo:", id);

    if (!$("#modPeriodo").length) {
        console.warn("⚠️ El modal #modPeriodo no existe en el DOM.");
    } else {
        console.log("✅ El modal #modPeriodo sí existe.");
    }

    $("#txtId").val(id);
    buscarPeriodo();

    // Probar manualmente si se puede abrir el modal
    $("#modPeriodo").modal("show");
});

/**
 * Función para mostrar ventana modal cuando un módulo no está disponible
 * @param {string} mensaje - Mensaje a mostrar sobre el módulo no disponible
 */
function mostrarNoDisponible(mensaje) {
    // Crear el contenido del modal
    let modalHTML = `
    <div class="modal fade" id="noDisponibleModal" tabindex="-1" aria-labelledby="noDisponibleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-info text-white">
                    <h5 class="modal-title" id="noDisponibleModalLabel">
                        <i class="fas fa-info-circle me-2"></i>Módulo No Disponible
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-3">
                        <i class="fas fa-tools text-info fa-4x"></i>
                    </div>
                    <p class="text-center">${
        mensaje ||
        "Esta funcionalidad no está disponible por el momento."
    }</p>
                    <p class="text-center text-muted"><small>Estamos trabajando para habilitarla pronto.</small></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Entendido</button>
                </div>
            </div>
        </div>
    </div>`;

    // Remover modal anterior si existe
    let modalAnterior = document.getElementById("noDisponibleModal");
    if (modalAnterior) {
        modalAnterior.remove();
    }

    // Agregar el modal al documento
    document.body.insertAdjacentHTML("beforeend", modalHTML);

    // Mostrar el modal
    let modalElement = document.getElementById("noDisponibleModal");
    let modal = new bootstrap.Modal(modalElement);
    modal.show();

    // Eliminar el modal del DOM cuando se cierre
    modalElement.addEventListener("hidden.bs.modal", function () {
        modalElement.remove();
    });
}
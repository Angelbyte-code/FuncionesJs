//Autor Miguel Angel Lara H.

//descripcion de funcionamiento
/**
 * Este archivo se encarga de validar los datos del formulario de usuarios
 * antes de permitir que se guarden o modifiquen en el sistema.
 * También maneja la carga dinámica de los formularios de usuario.
 *
 * 1. Verifica que los campos obligatorios no estén vacíos.
 * 2. Revisa que cada dato cumpla con su formato correcto (ID, nombre y apellidos).
 * 3. Marca visualmente los campos con errores y muestra mensajes al usuario.
 * 4. Construye el nombre completo a partir de nombre y apellidos.
 * 5. Si todo está bien, envía los datos al servidor mediante fetch de forma asíncrona.
 * 6. Recibe la respuesta del backend y muestra un modal indicando si la operación fue exitosa o ocurrió algún error.
 *
 * En resumen, este archivo asegura que la información del usuario esté correcta
 * y completa antes de ser enviada y procesada por el sistema.
 * !Importante: no modificar las funciones, solo las URL de los endpoints.
 *
 */
// Funcion que permite cargar los formularios de usuario de forma dinamica
/**
 *
 * @param {*} opc  es la opcion para cargar el formulario ya sea de agregar o modificar
 * @param {*} id  es el id del usuario que se va a modificar
 */
function loadFormUser(opc, id = "") {
  let url = "";
  if (opc === "frmUser") {
    url = "../modules/usuario/frmUsuario.php";
  } else if (opc === "modUser") {
    url = "../modules/usuario/modUsuario.php";
  }

  let datas = { id: id };
  let container = $("#frmArea");

  container.fadeOut(300, function () {
    clearArea("frmArea");

    $.ajax({
      url: url,
      method: "POST",
      data: JSON.stringify(datas),
      contentType: "application/json; charset=utf-8",
      headers: {
        "X-Requested-With": "XMLHttpRequest",
      },

      success: function (responseText, status, xhr) {
        // --- ANTI-HTML (detecta sesión expirada o error del backend) ---
        if (
          typeof responseText === "string" &&
          (responseText.startsWith("<!DOCTYPE") ||
            responseText.startsWith("<html"))
        ) {
          console.warn("HTML detectado — posible sesión inválida.");
          window.location.href = "../login.php?estado=session_error";
          return;
        }

        container
          .html(responseText)
          .hide()
          .fadeIn(500)
          .css("transform", "translateY(-10px)")
          .animate(
            {
              opacity: 1,
              transform: "translateY(0px)",
            },
            300
          );

        // === Cargar datos si es modificación ===
        if (opc === "modUser" && id !== "") {
          obtenerDatosUsuario(id);
        }
      },

      error: function (xhr, status, error) {
        // --- 401 SESIÓN INVALIDADA ---
        if (xhr.status === 401) {
          let data;
          try {
            data = JSON.parse(xhr.responseText);
            window.location.href =
              "../login.php?estado=" + encodeURIComponent(data.reason);
          } catch (e) {
            window.location.href = "../login.php?estado=session_error";
          }
          return;
        }

        // --- 403 SIN PERMISOS ---
        if (xhr.status === 403) {
          container
            .html(
              `
      <div class="alert alert-warning mt-3">
        <h4>No tienes permisos para acceder a este formulario.</h4>
        <p>Contacta al administrador.</p>
      </div>
    `
            )
            .hide()
            .fadeIn(300);

          return;
        }

        // --- OTROS ERRORES ---
        mostrarErrorCaptura("Error de conexión: " + status + " - " + error);
      },
    });
  });
}

//funcion para validar antes de guardar que los datos sean los nesesarios.
function validarFormulariosUsuario(opc) {
  // Obtenemos los valores que el usuario ingreso por medio de las etiquetas
  const IDUser = document.querySelector("#UserID");
  const nombreUser = document.querySelector("#nombreuser");
  const apellidop = document.querySelector("#apellidopUser");
  const apellidom = document.querySelector("#apellidomUser");
  const password = document.querySelector("#passwordUser");
  const rolUsuario = document.querySelector("#RolUsuario");
  const statusUser = document.querySelector("#statusUser");

  //se limpian los valores
  const IDUserValue = IDUser.value.trim();
  const nombreUserValue = nombreUser.value.trim();
  const apellidopValue = apellidop.value.trim();
  const apellidomValue = apellidom.value.trim();
  const passwordValue = password.value.trim();
  const rolUsuarioValue = rolUsuario.value.trim();
  const statusUserValue = statusUser.value.trim();
  //se crea un arreglo con los campos a validar

  const camposGuardar = [
    [IDUser, IDUserValue],
    [nombreUser, nombreUserValue],
    [apellidop, apellidopValue],
    [password, passwordValue],
    [rolUsuario, rolUsuarioValue],
    [statusUser, statusUserValue],
  ];

  const camposModificar = [
    [IDUser, IDUserValue],
    [nombreUser, nombreUserValue],
    [apellidop, apellidopValue],
    [rolUsuario, rolUsuarioValue],
    [statusUser, statusUserValue],
  ];

  // campos con formato estblecidos
  const camposConFormato = [
    [IDUser, IDUserValue, /^[A-Za-z]{3}-\d{4}$/],
    [nombreUser, nombreUserValue, /^[A-Za-zÁÉÍÓÚáéíóúÑñ ]+$/],
    [apellidop, apellidopValue, /^[A-Za-zÁÉÍÓÚáéíóúÑñ ]+$/],
    [apellidom, apellidomValue, /^$|^[A-Za-zÁÉÍÓÚáéíóúÑñ ]+$/],
  ];
  const nombresCampos = {
    UserID: "ID de usuario",
    nombreuser: "Nombre",
    apellidopUser: "Apellido paterno",
    apellidomUser: "Apellido materno",
  };

  switch (opc) {
    case "guardar":
      // Usar la validación específica para guardado
      //Verificar que no ahiga nada vacio
      const nadaVacio = camposGuardar.every(
        ([_, valor]) => valor.trim() !== ""
      );

      if (!nadaVacio) {
        camposGuardar.forEach(([elemento, valor]) => {
          marcarError(elemento, valor);
        });
        mostrarFaltaDatos(
          "No se pueden dejar campos vacíos. Verifique e intente de nuevo."
        );
        btnGuardarJ.disabled = true;
        return;
      }
      //validar que los campos tengan el formato correcto
      const erroresFormato = [];

      camposConFormato.forEach(([elemento, valor, regex]) => {
        // limpiar clases primero
        elemento.classList.remove("entrada-error", "is-invalid");

        // validar
        if (!regex.test(valor)) {
          elemento.classList.add("entrada-error", "is-invalid");
          erroresFormato.push(nombresCampos[elemento.id]);
        }
      });

      // Si hay errores
      if (erroresFormato.length > 0) {
        mostrarFaltaDatos(
          "Los siguientes campos no cumplen el formato requerido: " +
            erroresFormato.join(", ")
        );
        btnGuardarJ.disabled = true;
        return;
      }
      //si todo esta bien se procede a guardar
      btnGuardarJ.disabled = true;
      guardarUsuario();
      //fin
      break;
    case "modificar":
      // Usar la validación específica para modificación

      //Verificar que no ahiga nada vacio
      const sinvacios = camposModificar.every(
        ([_, valor]) => valor.trim() !== ""
      );

      if (!sinvacios) {
        camposModificar.forEach(([elemento, valor]) => {
          marcarError(elemento, valor);
        });
        mostrarFaltaDatos(
          "No se pueden dejar campos vacíos. Verifique e intente de nuevo."
        );
        btnGuardarJ.disabled = true;
        return;
      }
      //validar que los campos tengan el formato correcto
      const erroresFormatoMod = [];

      camposConFormato.forEach(([elemento, valor, regex]) => {
        // limpiar clases primero
        elemento.classList.remove("entrada-error", "is-invalid");

        // validar
        if (!regex.test(valor)) {
          elemento.classList.add("entrada-error", "is-invalid");
          erroresFormatoMod.push(nombresCampos[elemento.id]);
        }
      });

      // Si hay errores
      if (erroresFormatoMod.length > 0) {
        mostrarFaltaDatos(
          "Los siguientes campos no cumplen el formato requerido: " +
            erroresFormatoMod.join(", ")
        );
        btnGuardarJ.disabled = true;
        return;
      }
      //si todo esta bien se procede a modificar
      btnGuardarJ.disabled = true;
      modificarUsuario();
      //fin
      break;
  }
}

// Funcion para validar campos y restricciones en formularios de Usuarios
function validaCamposDeUsuarios(idInput, cont, opc) {
  const input = document.getElementById(idInput);
  const valor = input.value.trim();
  const contenedor = input.closest("." + cont);
  //esta variable se utiliza para abilitar el boton cuando sea el formulario modUsuario.php
  //@param opc

  // Limpiar errores previos
  const errorPrevio = contenedor.querySelector(".errorscaracter");
  if (errorPrevio) errorPrevio.remove();

  input.classList.remove("entrada-error", "is-invalid");

  // Regex requeridos
  const regexUserID = /^[A-Za-z]{3}-\d{4}$/;
  const regexNombre = /^[A-Za-zÁÉÍÓÚáéíóúÑñ ]+$/;
  const regexNombreOpcional = /^$|^[A-Za-zÁÉÍÓÚáéíóúÑñ ]+$/;

  switch (idInput) {
    // 1️ Usuario ID → formato XXX-0000
    case "UserID":
      if (valor === "") {
        mostrarErrorUsuario(input, "Este campo no puede estar vacío.", cont);
        input.classList.add("entrada-error", "is-invalid");
        return evaluarEstadoFormularioUsuario();
      }

      if (!regexUserID.test(valor)) {
        mostrarErrorUsuario(input, "Formato inválido. Ejemplo: ABC-0001", cont);
        input.classList.add("entrada-error", "is-invalid");
        return evaluarEstadoFormularioUsuario();
      }
      break;

    // 2️ Nombre usuario
    case "nombreuser":
      if (valor === "") {
        mostrarErrorUsuario(input, "Ingrese un nombre.", cont);
        input.classList.add("entrada-error", "is-invalid");
        return evaluarEstadoFormularioUsuario();
      }

      if (!regexNombre.test(valor)) {
        mostrarErrorUsuario(input, "Solo se permiten letras y espacios.", cont);
        input.classList.add("entrada-error", "is-invalid");
        return evaluarEstadoFormularioUsuario();
      }
      break;

    // 3️ Apellido Paterno
    case "apellidopUser":
      if (valor === "") {
        mostrarErrorUsuario(input, "Ingrese el apellido paterno.", cont);
        input.classList.add("entrada-error", "is-invalid");
        return evaluarEstadoFormularioUsuario();
      }

      if (!regexNombre.test(valor)) {
        mostrarErrorUsuario(input, "Solo se permiten letras y espacios.", cont);
        input.classList.add("entrada-error", "is-invalid");
        return evaluarEstadoFormularioUsuario();
      }
      break;

    // 4️ Apellido Materno
    case "apellidomUser":
      /*if (valor === "") {
         mostrarErrorUsuario(input, "Ingrese el apellido materno.", cont);
        input.classList.add("entrada-error", "is-invalid");
        return evaluarEstadoFormularioUsuario();
      }*/

      if (!regexNombreOpcional.test(valor)) {
        mostrarErrorUsuario(input, "Solo se permiten letras y espacios.", cont);
        input.classList.add("entrada-error", "is-invalid");
        return evaluarEstadoFormularioUsuario();
      }
      break;
    case "passwordUser":
      if (valor === "") {
        mostrarErrorUsuario(input, "La contraseña no puede estar vacía.", cont);
        input.classList.add("entrada-error", "is-invalid");
        return evaluarEstadoFormularioUsuario();
      }
      break;
    case "RolUsuario":
      if (valor === "") {
        mostrarErrorUsuario(input, "Seleccione un rol para el usuario.", cont);
        input.classList.add("entrada-error", "is-invalid");
        return evaluarEstadoFormularioUsuario();
      }
      break;
  }

  // Si todo OK
  evaluarEstadoFormularioUsuario(opc);
}

//funcion para mostrar el error de escritura
function mostrarErrorUsuario(input, mensaje, cont) {
  const contenedorCampo = input.closest("." + cont);
  // Eliminamos mensaje anterior si ya existe
  const errorPrevio = contenedorCampo.querySelector(".errorscaracter");
  if (errorPrevio) errorPrevio.remove();
  const alerta = document.createElement("p");
  alerta.textContent = mensaje;
  alerta.classList.add("errorscaracter");
  contenedorCampo.appendChild(alerta); // Insertamos debajo del input group
}

//Funcion que permite Valdar si esta todo correctamente para Habilitar el boton de guardar
function evaluarEstadoFormularioUsuario(opc) {
  const userId = document.getElementById("UserID");
  const nombreUser = document.getElementById("nombreuser");
  const appellidoP = document.getElementById("apellidopUser");
  const appellidoM = document.getElementById("apellidomUser");
  const password = document.getElementById("passwordUser");
  const rolUsuario = document.getElementById("RolUsuario");
  const status = document.getElementById("statusUser");
  const idbtnGuardarJ = document.querySelector("#btnGuardarJ");

  // Regex requeridos
  const regexUserID = /^[A-Za-z]{3}-\d{4}$/;
  const regexNombre = /^[A-Za-zÁÉÍÓÚáéíóúÑñ ]+$/;
  const regexNombreOpcional = /^$|^[A-Za-zÁÉÍÓÚáéíóúÑñ ]+$/;

  let hayErrores = false;

  // Verificar clases
  const inputs = [
    nombreUser,
    appellidoP,
    appellidoM,
    password,
    rolUsuario,
    status,
  ];
  if (
    inputs.some(
      (input) =>
        input &&
        (input.classList.contains("entrada-error") ||
          input.classList.contains("is-invalid"))
    )
  ) {
    hayErrores = true;
  }

  // Verificar que las entradas nombre y userId no contengan caracteres no permitidos
  if (
    !regexNombre.test(nombreUser.value.trim()) ||
    !regexNombre.test(appellidoP.value.trim()) ||
    !regexNombreOpcional.test(appellidoM.value.trim()) ||
    !regexUserID.test(userId.value.trim())
  ) {
    hayErrores = true;
  }

  let passwordAG = false;

  if (opc === "add" && password.value.trim() === "") {
    passwordAG = true;
  }

  let camposVacios = [
    userId.value.trim() === "",
    nombreUser.value.trim() === "",
    appellidoP.value.trim() === "",
    rolUsuario.value.trim() === "",
    status.value.trim() === "",
  ].some(Boolean);

  // Habilitar o deshabilitar el botón de guardar
  idbtnGuardarJ.disabled = hayErrores || camposVacios || passwordAG;
}

//Funcion que genera una contraseña para el usuario
function generarPasswordUsuario() {
  const nombre = document.getElementById("nombreuser").value.trim();
  const apellidoP = document.getElementById("apellidopUser").value.trim();

  if (nombre === "" || apellidoP === "") {
    mostrarFaltaDatos(
      "Debes llenar Nombre y Apellido Paterno antes de generar la contraseña."
    );
    return;
  }

  // Primera letra del nombre
  const inicial = nombre.charAt(0).toLowerCase();

  // Apellido paterno sin espacios
  const apPaterno = apellidoP.replace(/\s+/g, "");

  // Opcional: añadir 2 números aleatorios
  //onst numeros = Math.floor(10 + Math.random() * 90); // 10–99

  // Contraseña final
  const password = inicial + apPaterno;

  document.getElementById("passwordUser").value = password;

  validaCamposDeUsuarios("passwordUser", "mb-4", "");
}

//Funcion para enviar datos al servidor por medio de fetch
//Se encarga de guardar un nuevo usuario
async function guardarUsuario() {
  // Obtenemos los valores
  const IDUser = document.querySelector("#UserID");
  const nombreUser = document.querySelector("#nombreuser");
  const apellidop = document.querySelector("#apellidopUser");
  const apellidom = document.querySelector("#apellidomUser");
  const password = document.querySelector("#passwordUser");
  const rolUsuario = document.querySelector("#RolUsuario");
  const statusUser = document.querySelector("#statusUser");
  //! Importante Cambiar la URL
  const url = "../../Controlador/Intermediarios/captura/Captura.php";

  try {
    // mostrar loader anter de enviar
    mostrarLoader();

    // Objeto de datos
    const data = {
      id_usuario: IDUser.value.trim(),
      nombre_usuario: nombreUser.value.trim(),
      apellido_paterno: apellidop.value.trim(),
      apellido_materno: apellidom.value.trim(),
      password: password.value.trim(),
      rol: rolUsuario.value.trim(),
      status: statusUser.value.trim(),
    };

    // Petición fetch
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    // Verificar si respondió el servidor
    if (!response.ok) {
      mostrarErrorCaptura(
        "Error de conexión con el servidor. Código: " + response.status
      );
      return;
    }

    const resultado = await response.json();

    // Si el backend envía un OK
    if (resultado.success) {
      mostrarDatosGuardados(
        resultado.message || "Usuario guardado correctamente.",
        () => goTo("user", "")
      );
    } else {
      mostrarErrorCaptura(resultado.message || "Error al guardar usuario.");
    }
  } catch (error) {
    mostrarErrorCaptura("Error inesperado: " + error.message);
  } finally {
    ocultarLoader();
  }
}

// Implementación de funcion para actualizar los datos del usuario
// Se encarga de modificar un usuario existente
async function modificarUsuario() {
  // Obtenemos los valores que el usuario ingreso por medio de las etiquetas
  const IDUser = document.querySelector("#UserID");
  const nombreUser = document.querySelector("#nombreuser");
  const apellidop = document.querySelector("#apellidopUser");
  const apellidom = document.querySelector("#apellidomUser");
  const password = document.querySelector("#passwordUser");
  const rolUsuario = document.querySelector("#RolUsuario");
  //! Importante Cambiar la URL
  const url = "../../Controlador/Intermediarios/captura/captura.php";

  try {
    //Mostrar el Loader anter de hacer la Petición
    mostrarLoader();

    //Objeto de datos
    const data = {
      id_usuario: IDUser.value.trim(),
      nombre_usuario: nombreUser.value.trim(),
      apellido_paterno: apellidop.value.trim(),
      apellido_materno: apellidom.value.trim(),
      password: password.value.trim(),
      rol: rolUsuario.value.trim(),
    };

    // Petición fetch
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });

    // Verificar si el servidor respondió correctamente
    if (!response.ok) {
      mostrarErrorCaptura(
        "Error de conexión con el servidor. Código: " + response.status
      );
      return;
    }

    const resultado = await response.json();
    // Si el backend envía un true
    if (resultado.success) {
      mostrarDatosGuardados(
        resultado.message || "Datos de usuario actualizados correctamente.",
        () => option("user", "")
      );
    } else {
      mostrarErrorCaptura(
        resultado.message || "Error al actualizar los datos del usuario."
      );
    }
  } catch (error) {
    mostrarErrorCaptura("Error inesperado: " + error.message);
  } finally {
    ocultarLoader();
  }
}

// funcion para obtener los datos del usuario de la BD y mostrarlos en el formulario de modificacion
// Se encarga de obtener los datos de un usuario existente
async function obtenerDatosUsuario(idUsuario) {
  //! Importante Cambiar la URL
  const url = "../../Controlador/Intermediarios/captura/captura.php";

  try {
    //Mostrar loader antes de hacer peticion
    mostrarLoader();
    //Prepara Objeto de datos
    const data = { id_usuario: idUsuario };

    //Enviar peticion
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      ocultarLoader();
      mostrarErrorCaptura(
        "Error de conexión con el servidor. Código: " + response.status
      );
      return;
    }
    //si todo ok
    const resultado = await response.json();

    if (!resultado.success) {
      mostrarErrorCaptura(resultado.message || "Error al obtener datos.");
      return;
    }

    if (!resultado.data) {
      mostrarErrorCaptura("No se encontraron datos del usuario.");
      return;
    }
    //Envio datos datos obtenidos para mostrarlos
    llenarFormularioUsuario(resultado.data);
  } catch (error) {
    mostrarErrorCaptura("Error inesperado: " + error.message);
  } finally {
    ocultarLoader();
  }
}

// Se encarga de llenar el formulario con los datos del usuario obtenidos
function llenarFormularioUsuario(data) {
  document.querySelector("#UserID").value = data.id_usuario;
  document.querySelector("#nombreuser").value = data.nombre_usuario;
  document.querySelector("#apellidopUser").value = data.apellido_paterno;
  document.querySelector("#apellidomUser").value = data.apellido_materno ?? "";
  document.querySelector("#RolUsuario").value = data.rol;
  document.querySelector("#statusUser").value = data.status;
}

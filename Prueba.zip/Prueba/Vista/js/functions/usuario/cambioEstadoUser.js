//Autor Miguel Angel Lara H.
//Autor
//descripcion de funcionamiento
/**
 * En este archivo se realiza el cambio de estado de un elemento de la tabla
 * al cambiar de estado significa que se realizaran diferentes comportamientos con la informacion en el sistema
 * dependidendo del estado 
 */
/**
 * Cambia el estado de un usuario mostrando primero un modal de confirmación.
 * Si el usuario cancela o se cierra el modal, el select vuelve al estado original.
 *
 * @param {string} name - Nombre completo del usuario mostrado en el mensaje del modal.
 * @param {string} id - ID único del usuario (ej: TED-9632).
 * @param {string} status - Nuevo estado seleccionado por el usuario desde el <select>.
 * @param {string} currentStatus - Estado original; sirve para restablecer el select si se cancela la acción.
 * @param {string} selectElementId - ID del <select> que disparó el cambio. Necesario para manipular ese elemento específico.
 */
function changeStatusUsuario(name, id, status, currentStatus, selectElementId) {

  
  const selectElement = document.getElementById(selectElementId);

    // Si selecciona "Cambiar estado" o algo inválido → NO HACER NADA
    if (!status || status === "Cambiar estado") {
        selectElement.value = currentStatus;
        return;
    }

    
    // Crear modal dinámico
    const modalHTML = `
    <div class="modal fade" id="confirmStatusModal" tabindex="-1" aria-labelledby="confirmStatusModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">

                <div class="modal-header bg-warning text-dark">
                    <h5 class="modal-title" id="confirmStatusModalLabel">
                        <i class="fas fa-exclamation-triangle me-2"></i> Confirmar cambio de estado
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <div class="text-center mb-3">
                        <i class="fas fa-sync-alt text-warning fa-4x"></i>
                    </div>
                    <p class="text-center">¿Está seguro de cambiar el estado del Usuario <strong>${name}</strong> con ID <strong>${id}</strong> a <strong>${status}</strong>?</p>
                    <p class="text-center text-danger">Esta acción puede afectar el sistema uso del sistema.</p>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" id="btnCancelar">Cancelar</button>
                    <button type="button" class="btn btn-primary" id="btnConfirmar">Confirmar</button>
                </div>

            </div>
        </div>
    </div>`;

    // Eliminar modal previo
    const oldModal = document.getElementById("confirmStatusModal");
    if (oldModal) oldModal.remove();

    // Insertar modal
    document.body.insertAdjacentHTML("beforeend", modalHTML);

    const modalElement = document.getElementById("confirmStatusModal");
    const modal = new bootstrap.Modal(modalElement);
    modal.show();

    // Cancelar → restaurar opción original
    document.getElementById("btnCancelar").addEventListener("click", () => {
        selectElement.value = currentStatus;
        modal.hide();
    });

    // Cerrar modal con X o fuera → restaurar opción original
    modalElement.addEventListener("hidden.bs.modal", () => {
        selectElement.value = currentStatus;
        modalElement.remove();
    });

    // Confirmar acción
    document.getElementById("btnConfirmar").addEventListener("click", async () => {

        const data = {
            id_usuario: id,
            nuevo_estado: status
        };

        modal.hide();
        

        try {
          // !Importante Colocar la URL
          const url = "";
            mostrarLoader("Actualizando estado...");

            const response = await fetch(url, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(data)
            });

            if (!response.ok) {
                mostrarErrorCaptura("Error del servidor. Código: " + response.status);
                return;
            }

            const result = await response.json();

            if (result.success) {
                mostrarDatosGuardados(
                    `El estado del usuario ${name} se actualizó a "${status}" correctamente.`,
                    () => goTo("user", "")
                );
            } else {
                mostrarErrorCaptura(result.message || "Error al actualizar el estado.");
            }

        } catch (error) {
            mostrarErrorCaptura("Error inesperado: " + error.message);
        } finally {
            ocultarLoader();
        }
    });
}

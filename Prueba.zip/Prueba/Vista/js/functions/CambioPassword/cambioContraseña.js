//Autor Miguel Angel Lara Hermosillo
/**
 * Funciones para manejo de contraseñas:
 * togglePassword() muestra u oculta el texto del input.
 * verificarFortaleza() evalúa la contraseña ingresada y actualiza un indicador visual
 * mostrando si es débil, media o fuerte según su composición.
 * la funcion enviarCambioPassword() envia los datos al servidor para cambiar la contraseña.
 * !No modificar las funciones, solo la URL en enviarCambioPassword().
 */

function togglePassword(inputId, btn) {
  const input = document.getElementById(inputId);
  const icon = btn.querySelector("i");

  if (input.type === "password") {
    input.type = "text";
    icon.classList.remove("fa-eye");
    icon.classList.add("fa-eye-slash");
  } else {
    input.type = "password";
    icon.classList.remove("fa-eye-slash");
    icon.classList.add("fa-eye");
  }
}

//Funcion que permite saber que tan fuerte o devil es una contraceña Dependiendo de lo que el usuario
//coloque
function verificarFortaleza() {
  const pass = document.getElementById("nuevaPass").value;
  const barra = document.getElementById("barraFortaleza");
  const texto = document.getElementById("textoFortaleza");

  let puntos = 0;

  if (pass.length >= 6) puntos++;
  if (pass.length >= 10) puntos++;
  if (/[A-Z]/.test(pass)) puntos++;
  if (/[a-z]/.test(pass)) puntos++;
  if (/[0-9]/.test(pass)) puntos++;
  if (/[^A-Za-z0-9]/.test(pass)) puntos++; // símbolos

  // Evaluación
  if (puntos <= 2) {
    barra.style.background = "#e74c3c"; // rojo
    texto.textContent = "Contraseña débil";
    texto.style.color = "#e74c3c";
  } else if (puntos <= 4) {
    barra.style.background = "#f1c40f"; // amarillo
    texto.textContent = "Contraseña media";
    texto.style.color = "#f1c40f";
  } else {
    barra.style.background = "#2ecc71"; // verde
    texto.textContent = "Contraseña fuerte";
    texto.style.color = "#2ecc71";
  }
  activarBTN();
}

function activarBTN() {
  const passnueva = document.querySelector("#nuevaPass");
  const passconfirm = document.querySelector("#confirmarPass");
  const boton = document.querySelector("#btnCambiarPass");

   let camposVacios = [
    passnueva.value.trim() === "",
    passconfirm.value.trim() === ""
  ].some(Boolean);

  let conincinden = false;
  
  if(passnueva.value.trim() !== passconfirm.value.trim()){
     conincinden = true;
  }

  boton.disabled = camposVacios || conincinden;
}
 
//Funcion para enviar los datos al servidor por medio de fetch

async function enviarCambioPassword() {
    const pass1 = document.getElementById("nuevaPass").value.trim();
    const pass2 = document.getElementById("confirmarPass").value.trim();
    const idUsuario = document.getElementById("idUsuario").value;
    
    console.log("ID Usuario:", idUsuario);
    //! Importante Cambiar la URL
    const url = "../../Controlador/Intermediarios/captura/cambiopass.php";
    try {
        const response = await fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            credentials: "same-origin", // evita fugas de cookies
            body: JSON.stringify({
                nuevaPass: pass1,
                confirmarPass: pass2,
                idUsuario: idUsuario
            })
        });

        const data = await response.json();

        if (data.status === "ok") {
            mostrarDatosGuardados(
                data.message, () => {
                  goTo("myAccount", "");
                  
        });
        } 
        if (data.status === "falta" || data.status === "error"){
          mostrarFaltaDatos(data.message);
           return;
        }

    } catch (error) {
        console.error("Error:", error);
        mostrarErrorCaptura("Error de comunicación con el servidor.");
    }
}



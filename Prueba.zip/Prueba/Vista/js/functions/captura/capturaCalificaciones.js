/**
 * Módulo para Captura de Calificaciones
 * Autor: Alex Martinez Gonzalez
 * Descripción: Permite capturar calificaciones por unidad, parcial y horario
 *
 * Restricciones:
 * - Solo parciales con estatus "Abierto"
 * - Calificaciones en rango 0.00-100.00
 * - Validación de duplicados en backend
 * - Errores inline, no en modales (excepto éxito)
 */

let CapturaCalificaciones = (function () {
    'use strict';

    // Variables de estado
    let parcialSeleccionado = null;
    let horarioSeleccionado = null;
    let unidadSeleccionada = null;
    let alumnosCargados = [];
    let datosModificados = false;
    let parcialesDisponibles = [];
    let horariosDisponibles = [];

    // Referencias DOM
    let elementos = {};

    /**
     * Inicializa el módulo
     */
    function inicializar() {
        console.log('Inicializando módulo de captura de calificaciones...');

        // Cachear referencias DOM
        cachearElementos();

        // Configurar event listeners
        configurarEventListeners();

        // Cargar datos iniciales
        cargarParcialesAbiertos();

        console.log('Módulo inicializado correctamente');
    }

    /**
     * Cachea las referencias a elementos DOM
     */
    function cachearElementos() {
        elementos = {
            // Selectores
            parcialSelect: document.getElementById('parcialSelect'),
            horarioSelect: document.getElementById('horarioSelect'),
            unidadSelect: document.getElementById('unidadSelect'),

            // Botones
            btnGuardarCalificaciones: document.getElementById('btnGuardarCalificaciones'),
            btnCancelar: document.getElementById('btnCancelar'),
            btnConfirmarCambio: document.getElementById('btnConfirmarCambio'),

            // Tablas y contenedores
            cuerpoAlumnos: document.getElementById('cuerpoAlumnos'),
            contadorAlumnos: document.getElementById('contadorAlumnos'),
            promedioCalificaciones: document.getElementById('promedioCalificaciones'),
            tablaAlumnos: document.getElementById('tablaAlumnos'),

            // Secciones
            seccionTabla: document.getElementById('seccionTabla'),
            alertaParcial: document.getElementById('alertaParcial'),
            mensajeParcial: document.getElementById('mensajeParcial'),
            infoHorario: document.getElementById('infoHorario'),
            mensajeSinAlumnos: document.getElementById('mensajeSinAlumnos'),

            // Info del horario
            infoMateria: document.getElementById('infoMateria'),
            infoDocente: document.getElementById('infoDocente'),
            infoGrupo: document.getElementById('infoGrupo'),

            // Errores
            errorParcial: document.getElementById('errorParcial'),
            errorHorario: document.getElementById('errorHorario'),
            errorUnidad: document.getElementById('errorUnidad')
        };
    }

    /**
     * Configura todos los event listeners
     */
    function configurarEventListeners() {
        // Selector de parcial
        elementos.parcialSelect.addEventListener('change', handleParcialChange);

        // Selector de horario
        elementos.horarioSelect.addEventListener('change', handleHorarioChange);

        // Selector de unidad
        elementos.unidadSelect.addEventListener('change', handleUnidadChange);

        // Botón guardar
        elementos.btnGuardarCalificaciones.addEventListener('click', guardarCalificaciones);

        // Botón cancelar
        elementos.btnCancelar.addEventListener('click', handleCancelar);

        // Modificar numero de unidades
        elementos.horarioSelect.addEventListener("change", actualizarUnidades);
    }

    /**
     * Carga los parciales con estatus "Abierto"
     */
    async function cargarParcialesAbiertos() {
        try {

            let url = "../../Controlador/Intermediarios/Parcial/ObtenerParcialPorEstado.php";
            let estado = "Abierto"
            let json = JSON.stringify(estado);

            const response = await fetch(url, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: json,
            });

            if (!response.ok) {
                throw new Error("Error en la petición: " + response.statusText);
            }

            const resultado = await response.json();

            if (resultado.estado === "OK") {

                // Limpiar select
                elementos.parcialSelect.innerHTML = '<option value="">Seleccione un parcial...</option>';

                const parcial = resultado.datos ? resultado.datos : null;

                if (!parcial) {
                    mostrarErrorCaptura("No se encontró ningún parcial en estado Abierto.");
                    return;
                }

                parcialesDisponibles = [parcial];

                // Agregar opción
                parcialesDisponibles.forEach(p => {
                    const option = document.createElement('option');
                    option.value = p.clave_parcial;
                    option.textContent = `${p.nombre_parcial} (${p.estado})`;
                    option.dataset.estado = p.estado;
                    option.dataset.idPeriodo = p.clave_periodo;
                    elementos.parcialSelect.appendChild(option);
                });

                console.log(`${parcialesDisponibles.length} parcial(es) abierto(s) cargado(s)`);

                // Si solo hay un parcial abierto, seleccionarlo automáticamente y deshabilitar el selector
                if (parcialesDisponibles.length === 1) {
                    const parcialUnico = parcialesDisponibles[0];
                    elementos.parcialSelect.value = parcialUnico.clave_parcial;
                    elementos.parcialSelect.disabled = true;

                    // Aplicar el cambio automáticamente
                    aplicarCambioParcial(parcialUnico.clave_parcial);

                    console.log(`Parcial único seleccionado automáticamente: ${parcialUnico.nombre_parcial}`);
                } else {
                    // Si hay más de un parcial, habilitar el selector
                    elementos.parcialSelect.disabled = false;
                }

            } else {
                mostrarErrorCaptura(resultado.mensaje);
            }

        } catch (error) {
            console.error('Error al cargar parciales:', + error.message);
            mostrarError(elementos.errorParcial, 'Error al cargar los parciales disponibles');
        }
    }

    /**
     * Maneja el cambio de parcial
     */
    function handleParcialChange(e) {
        const idParcial = e.target.value;

        // Limpiar error previo
        ocultarError(elementos.errorParcial);
        elementos.parcialSelect.classList.remove('input-error');

        // Verificar si hay datos sin guardar
        if (datosModificados && parcialSeleccionado) {
            // Guardar temporalmente la selección
            const nuevoValor = e.target.value;
            e.target.value = parcialSeleccionado.idParcial;

            // Mostrar modal con opciones
            mostrarModalCambioConGuardado(
                'Hay datos sin guardar. ¿Qué desea hacer?',
                function () {
                    // Opción 1: Guardar y continuar
                    guardarCalificacionesYContinuar(() => aplicarCambioParcial(nuevoValor));
                },
                function () {
                    // Opción 2: Continuar sin guardar
                    aplicarCambioParcial(nuevoValor);
                }
            );
            return;
        }

        aplicarCambioParcial(idParcial);
    }

    /**
     * Aplica el cambio de parcial
     */
    function aplicarCambioParcial(idParcial) {
        // Actualizar el select con el nuevo valor
        elementos.parcialSelect.value = idParcial;

        if (!idParcial) {
            parcialSeleccionado = null;
            elementos.horarioSelect.disabled = true;
            elementos.alertaParcial.style.display = 'none';
            limpiarFormulario(false);
            return;
        }

        // Buscar información del parcial
        const parcial = parcialesDisponibles.find(p => p.clave_parcial == idParcial);

        if (!parcial) {
            mostrarError(elementos.errorParcial, 'Parcial no encontrado');
            return;
        }

        parcialSeleccionado = parcial;

        // Verificar estado del parcial
        if (parcial.estado !== 'Abierto') {
            elementos.alertaParcial.style.display = 'block';
            elementos.mensajeParcial.textContent = 'El parcial seleccionado no está abierto. No se puede capturar calificaciones.';
            elementos.horarioSelect.disabled = true;
            elementos.unidadSelect.disabled = true;
            limpiarFormulario(false);
            return;
        }

        elementos.alertaParcial.style.display = 'none';

        // Habilitar selector de horario
        elementos.horarioSelect.disabled = false;

        // Cargar horarios
        cargarHorarios();
    }

    /**
     * Carga los horarios disponibles
     */
    async function cargarHorarios() {
        try {
            // 1. Obtener periodo abierto
            const url1 = "../../Controlador/Intermediarios/Periodo/ObtenerPeriodosPorEstado.php";

            const datosEnvio = { estadoP: "Abierto" };
            const json1 = JSON.stringify(datosEnvio);

            const response1 = await fetch(url1, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: json1,
            });

            if (!response1.ok) {
                throw new Error("Error en la petición: " + response1.statusText);
            }

            const resultado1 = await response1.json();

            if (resultado1.estado === "OK") {

                const periodo = resultado1.datos[0];

                // 2. Buscar ofertas por periodo
                const url2 = "../../Controlador/Intermediarios/Oferta/BuscarOfertasAsignadasPorPeriodo.php";

                const json2 = JSON.stringify(periodo.clave_periodo);

                const response2 = await fetch(url2, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: json2,
                });

                if (!response2.ok) {
                    throw new Error("Error en la petición: " + response2.statusText);
                }

                const resultado2 = await response2.json();

                if (resultado2.estado === "OK") {

                    horariosDisponibles = resultado2.datos ?? null;

                    // Limpiar select
                    elementos.horarioSelect.innerHTML = '<option value="">Seleccione una oferta...</option>';

                    // Agregar opciones
                    horariosDisponibles.forEach(horario => {
                        const option = document.createElement('option');
                        option.value = horario.clave_de_oferta;
                        option.textContent = `${horario.clave_de_materia} - ${horario.nombre_de_materia} - ${horario.semestre}${horario.grupo} - ${horario.turno}`;

                        option.dataset.claveMateria = horario.clave_de_materia;
                        option.dataset.nombreMateria = horario.nombre_de_materia;
                        option.dataset.nombreDocente = horario.docente;
                        option.dataset.semestre = horario.semestre;
                        option.dataset.grupo = horario.grupo;
                        option.dataset.turno = horario.turno;
                        option.dataset.unidades = horario.unidades;

                        elementos.horarioSelect.appendChild(option);
                    });

                    console.log(`${horariosDisponibles.length} ofertas cargadas`);

                } else {
                    mostrarErrorCaptura(resultado2.mensaje);
                }

            } else {
                mostrarErrorCaptura(resultado1.mensaje);
            }

        } catch (error) {
            console.error('Error al cargar ofertas:', error.message);
            mostrarError(elementos.errorParcial, 'Error al cargar las ofertas disponibles');
        }
    }

    function actualizarUnidades() {
        const select = elementos.horarioSelect;
        const seleccionada = select.options[select.selectedIndex];

        // Si no se seleccionó nada
        if (!seleccionada || !seleccionada.dataset.unidades) {
            elementos.unidadSelect.innerHTML = '<option value="">Seleccione una unidad...</option>';
            elementos.unidadSelect.disabled = true;
            return;
        }

        const totalUnidades = parseInt(seleccionada.dataset.unidades, 10);

        // Limpiar select
        elementos.unidadSelect.innerHTML = '<option value="">Seleccione una unidad...</option>';

        // Agregar unidades dinámicas
        for (let i = 1; i <= totalUnidades; i++) {
            const option = document.createElement("option");
            option.value = i;
            option.textContent = `Unidad ${i}`;
            elementos.unidadSelect.appendChild(option);
        }

        // Habilitar el select
        elementos.unidadSelect.disabled = false;
    }

    /**
     * Maneja el cambio de horario
     */
    function handleHorarioChange(e) {
        // Verificar si hay datos sin guardar
        if (datosModificados) {
            // Guardar temporalmente la selección
            const nuevoValor = e.target.value;
            e.target.value = horarioSeleccionado ? horarioSeleccionado.idHorario : '';

            // Mostrar modal con opciones
            mostrarModalCambioConGuardado(
                'Hay datos sin guardar. ¿Qué desea hacer?',
                function () {
                    // Opción 1: Guardar y continuar
                    guardarCalificacionesYContinuar(() => aplicarCambioHorario(nuevoValor));
                },
                function () {
                    // Opción 2: Continuar sin guardar
                    aplicarCambioHorario(nuevoValor);
                }
            );
            return;
        }

        aplicarCambioHorario(e.target.value);
    }

    /**
     * Aplica el cambio de horario
     */
    function aplicarCambioHorario(idHorario) {
        // Actualizar el select con el nuevo valor
        elementos.horarioSelect.value = idHorario;

        // Limpiar error previo
        ocultarError(elementos.errorHorario);
        elementos.horarioSelect.classList.remove('input-error');

        if (!idHorario) {
            horarioSeleccionado = null;
            elementos.unidadSelect.disabled = true;
            elementos.infoHorario.style.display = 'none';
            limpiarFormulario(false);
            return;
        }

        // Buscar información del horario
        const horario = horariosDisponibles.find(h => h.clave_de_oferta == idHorario);

        if (!horario) {
            mostrarError(elementos.errorHorario, 'Horario no encontrado');
            return;
        }

        horarioSeleccionado = horario;

        // Mostrar información del horario
        elementos.infoMateria.textContent = `${horario.clave_de_materia} - ${horario.nombre_de_materia}`;
        elementos.infoDocente.textContent = horario.docente;
        elementos.infoGrupo.textContent = `${horario.semestre}° ${horario.grupo} - ${horario.turno}`;
        elementos.infoHorario.style.display = 'block';

        // Habilitar selector de unidad
        elementos.unidadSelect.disabled = false;

        // Limpiar tabla
        limpiarFormulario(false);

        // Verificar si se deben cargar los alumnos automáticamente
        verificarYCargarAlumnos();
    }

    /**
     * Maneja el cambio de unidad
     */
    function handleUnidadChange(e) {
        // Verificar si hay datos sin guardar
        if (datosModificados) {
            const nuevoValor = e.target.value;
            e.target.value = unidadSeleccionada || '';

            // Mostrar modal con opciones
            mostrarModalCambioConGuardado(
                'Hay datos sin guardar. ¿Qué desea hacer?',
                function () {
                    // Opción 1: Guardar y continuar
                    guardarCalificacionesYContinuar(() => aplicarCambioUnidad(nuevoValor));
                },
                function () {
                    // Opción 2: Continuar sin guardar
                    aplicarCambioUnidad(nuevoValor);
                }
            );
            return;
        }

        aplicarCambioUnidad(e.target.value);
    }

    /**
     * Aplica el cambio de unidad
     */
    function aplicarCambioUnidad(unidad) {
        // Actualizar el select con el nuevo valor
        elementos.unidadSelect.value = unidad || '';

        // Limpiar error previo
        ocultarError(elementos.errorUnidad);
        elementos.unidadSelect.classList.remove('input-error');

        unidadSeleccionada = unidad || null;

        // Limpiar tabla
        limpiarFormulario(false);

        // Verificar si se deben cargar los alumnos automáticamente
        verificarYCargarAlumnos();
    }

    /**
     * Verifica si están seleccionados los 3 campos y carga los alumnos automáticamente
     */
    function verificarYCargarAlumnos() {
        const todosSeleccionados = parcialSeleccionado &&
            horarioSeleccionado &&
            unidadSeleccionada &&
            parcialSeleccionado.estado === 'Abierto';

        if (todosSeleccionados) {
            // Cargar alumnos automáticamente
            cargarAlumnos();
        }
    }

    /**
     * Carga los alumnos del horario seleccionado
     */
    async function cargarAlumnos() {
        if (!parcialSeleccionado || !horarioSeleccionado || !unidadSeleccionada) {
            mostrarError(elementos.errorParcial, 'Debe seleccionar parcial, horario y unidad');
            return;
        }

        try {
            // Mostrar loading
            elementos.cuerpoAlumnos.innerHTML = `
                <tr>
                    <td colspan="5" class="text-center">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Cargando...</span>
                        </div>
                        <p class="mt-2 mb-0">Cargando alumnos...</p>
                    </td>
                </tr>
            `;
            elementos.seccionTabla.style.display = 'block';

            const optionHorario = elementos.horarioSelect.options[elementos.horarioSelect.selectedIndex];
            const optionUnidad = elementos.unidadSelect.options[elementos.unidadSelect.selectedIndex];

            const datosEnvio = {
                pidOferta: optionHorario.value,
                punidad: parseInt(optionUnidad.value),
            };

            console.log(datosEnvio);

            const url = "../../Controlador/Intermediarios/Calificaciones/ObtenerCalificacionesPorOfertaUnidad.php";

            const response = await fetch(url, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(datosEnvio),
            });

            if (!response.ok) {
                throw new Error("Error en la petición: " + response.statusText);
            }

            const resultado = await response.json();

            console.log("Resultado backend:", resultado);

            if (resultado.estado === "OK") {
                alumnosCargados = resultado.datos;
                console.log("Alumnos cargados:", alumnosCargados);
            } else {
                mostrarErrorCaptura(resultado.mensaje);
            }

            if (alumnosCargados.length === 0) {
                mostrarSinAlumnos();
                return;
            }

            renderizarTablaAlumnos();

        } catch (error) {
            console.error('Error al cargar alumnos:', error);
            elementos.cuerpoAlumnos.innerHTML = `
                <tr>
                    <td colspan="5" class="text-center text-danger">
                        <i class="fas fa-exclamation-triangle fa-2x mb-2"></i>
                        <p class="mb-0">Error al cargar los alumnos</p>
                    </td>
                </tr>
            `;
        }
    }

    /**
     * Muestra mensaje cuando no hay alumnos
     */
    function mostrarSinAlumnos() {
        elementos.cuerpoAlumnos.innerHTML = `
            <tr>
                <td colspan="5" class="text-center text-muted">
                    <i class="fas fa-users-slash fa-2x mb-2"></i>
                    <p class="mb-0">No hay alumnos inscritos en este horario</p>
                </td>
            </tr>
        `;
        elementos.contadorAlumnos.textContent = '0';
        elementos.mensajeSinAlumnos.style.display = 'block';
        elementos.btnGuardarCalificaciones.style.display = 'none';
        elementos.btnGuardarCalificaciones.disabled = true;
    }

    /**
     * Renderiza la tabla de alumnos
     */
    function renderizarTablaAlumnos() {
        elementos.cuerpoAlumnos.innerHTML = '';
        elementos.mensajeSinAlumnos.style.display = 'none';

        alumnosCargados.forEach((alumno, index) => {
            const tr = document.createElement('tr');

            // Número de control
            const tdControl = document.createElement('td');
            tdControl.textContent = alumno.numero_de_control;
            tr.appendChild(tdControl);

            // Nombre completo
            const tdNombre = document.createElement('td');
            tdNombre.textContent = alumno.nombre_de_alumno;
            tr.appendChild(tdNombre);

            // Semestre
            const tdSemestre = document.createElement('td');
            tdSemestre.className = 'text-center';
            tdSemestre.textContent = `${alumno.semestre_del_alumno}°`;
            tr.appendChild(tdSemestre);

            // Estado
            const tdEstado = document.createElement('td');
            tdEstado.className = 'text-center';
            const spanEstado = document.createElement('span');
            spanEstado.className = `badge ${alumno.estado_del_alumno === 'Activo' ? 'bg-success' : 'bg-secondary'}`;
            spanEstado.textContent = alumno.estado_del_alumno;
            tdEstado.appendChild(spanEstado);
            tr.appendChild(tdEstado);

            // Calificación
            const tdCalificacion = document.createElement('td');
            const divCalificacion = document.createElement('div');
            divCalificacion.className = 'd-flex flex-column';

            const input = document.createElement('input');
            input.type = 'number';
            input.className = 'form-control form-control-sm calificacion-input';
            input.min = '0';
            input.max = '100';
            input.step = '0.01';
            input.placeholder = 'NC';
            input.dataset.index = index;
            input.dataset.numeroControl = alumno.numero_de_control;

            // Si ya tiene calificación, mostrarla y deshabilitar
            if (alumno.calificacion !== null && alumno.calificacion >= 0) {
                const calificacion = parseFloat(alumno.calificacion);

                // -1 significa "No Capturado" (NC)
                if (calificacion === -1) {
                    input.type = 'text';  // Cambiar tipo ANTES de asignar valor
                    input.value = 'NC';
                }
                // 0 o valores entre 0 y 69.99 significa "No Acreditado" (NA)
                else if (calificacion >= 0 && calificacion < 70) {
                    input.type = 'text';  // Cambiar tipo ANTES de asignar valor
                    input.value = 'NA';
                }
                // 70 a 100 se muestra el número
                else if (calificacion >= 70 && calificacion <= 100) {
                    input.value = calificacion.toFixed(2);
                }
                // Valor fuera de rango (no debería ocurrir, pero por seguridad)
                else {
                    input.type = 'text';
                    input.value = 'ERROR';
                }
                input.disabled = true;
                input.className += ' bg-light';

                const small = document.createElement('small');
                small.className = 'text-muted mt-1';
                small.textContent = 'Calificación ya capturada';
                divCalificacion.appendChild(small);
            } else {
                // Event listener para mostrar NA o número al perder el foco
                input.addEventListener('blur', (e) => {
                    const valor = e.target.value.trim();
                    if (valor === '') {
                        actualizarPromedio();
                        return;
                    }

                    const numero = parseFloat(valor);
                    if (!isNaN(numero)) {
                        if (numero >= 0 && numero < 70) {
                            // Guardar el valor real en un atributo data
                            e.target.dataset.valorReal = numero.toFixed(2);
                            e.target.type = 'text';
                            e.target.value = 'NA';
                        } else if (numero >= 70 && numero <= 100) {
                            e.target.value = numero.toFixed(2);
                            e.target.dataset.valorReal = numero.toFixed(2);
                        }
                        // Forzar validación y actualizar promedio
                        validarCalificacion(e, index);
                    }
                });

                // Event listener para restaurar número al hacer foco si es NA
                input.addEventListener('focus', (e) => {
                    if (e.target.value === 'NA' && e.target.dataset.valorReal) {
                        e.target.type = 'number';
                        e.target.value = parseFloat(e.target.dataset.valorReal).toFixed(2);
                    }
                });

                // Event listener para prevenir entrada inválida
                input.addEventListener('keypress', (e) => {
                    const valor = e.target.value;
                    const char = e.key;

                    // Permitir teclas de control
                    if (e.ctrlKey || e.metaKey || char === 'Backspace' || char === 'Delete' ||
                        char === 'ArrowLeft' || char === 'ArrowRight' || char === 'Tab') {
                        return;
                    }

                    // Solo permitir números y punto decimal
                    if (!/^\d$/.test(char) && char !== '.') {
                        e.preventDefault();
                        return;
                    }

                    // Verificar si el valor actual ya es >= 100
                    const valorActual = parseFloat(valor);
                    if (!isNaN(valorActual) && valorActual >= 100) {
                        // No permitir escribir más números ni punto
                        e.preventDefault();
                        return;
                    }

                    // Verificar si al agregar el nuevo carácter se excedería 100
                    const valorPotencial = valor + char;
                    const numeroPotencial = parseFloat(valorPotencial);
                    if (!isNaN(numeroPotencial) && numeroPotencial > 100 && char !== '.') {
                        e.preventDefault();
                        return;
                    }

                    // Permitir solo un punto decimal
                    if (char === '.' && valor.includes('.')) {
                        e.preventDefault();
                        return;
                    }

                    // Si ya escribió "100", no permitir punto decimal
                    if (char === '.' && valorActual === 100) {
                        e.preventDefault();
                        return;
                    }

                    // Limitar enteros a 3 dígitos
                    const partes = valor.split('.');
                    if (partes[0].length >= 3 && char !== '.' && !valor.includes('.')) {
                        e.preventDefault();
                        return;
                    }

                    // Limitar decimales a 2 dígitos
                    if (valor.includes('.') && partes[1] && partes[1].length >= 2 && char !== '.') {
                        e.preventDefault();
                        return;
                    }
                });

                // Event listener para validación
                input.addEventListener('input', (e) => validarCalificacion(e, index));
                input.addEventListener('change', (e) => validarCalificacion(e, index));
            }

            divCalificacion.appendChild(input);

            // Contenedor de error
            const divError = document.createElement('div');
            divError.id = `errorCalificacion${index}`;
            divError.className = 'error-message mt-1';
            divError.style.display = 'none';
            divCalificacion.appendChild(divError);

            tdCalificacion.appendChild(divCalificacion);
            tr.appendChild(tdCalificacion);

            elementos.cuerpoAlumnos.appendChild(tr);
        });

        // Actualizar contador
        const alumnosSinCalificar = alumnosCargados.filter(a => a.calificacion === null || a.calificacion === -1).length;
        elementos.contadorAlumnos.textContent = alumnosCargados.length;

        // Actualizar promedio
        actualizarPromedio();

        // Mostrar botón de guardar si hay alumnos sin calificar
        if (alumnosSinCalificar > 0) {
            elementos.btnGuardarCalificaciones.style.display = 'inline-block';
            elementos.btnGuardarCalificaciones.disabled = false;
        } else {
            elementos.btnGuardarCalificaciones.style.display = 'inline-block';
            elementos.btnGuardarCalificaciones.disabled = true;
        }

        datosModificados = false;
    }

    /**
     * Valida una calificación ingresada
     */
    function validarCalificacion(e, index) {
        const input = e.target;
        const valor = input.value.trim();
        const divError = document.getElementById(`errorCalificacion${index}`);

        // Si está vacío, es válido (no es obligatorio)
        if (valor === '') {
            ocultarError(divError);
            input.classList.remove('input-error');
            datosModificados = true;
            actualizarPromedio();
            return true;
        }

        // Si el valor es "NA" (No Acreditado), es válido
        if (valor === 'NA') {
            ocultarError(divError);
            input.classList.remove('input-error');
            datosModificados = true;
            actualizarPromedio();
            return true;
        }

        // Validar formato numérico
        const numero = parseFloat(valor);

        if (isNaN(numero)) {
            mostrarError(divError, 'Debe ser un número válido');
            input.classList.add('input-error');
            return false;
        }

        // Validar formato: máximo 3 enteros y 2 decimales (999.99)
        const regexFormato = /^\d{1,3}(\.\d{0,2})?$/;
        if (!regexFormato.test(valor)) {
            mostrarError(divError, 'Formato inválido. Máximo 3 enteros y 2 decimales (ej: 100.00)');
            input.classList.add('input-error');
            return false;
        }

        // Validar rango
        if (numero < 0 || numero > 100) {
            mostrarError(divError, 'Debe estar entre 0.00 y 100.00');
            input.classList.add('input-error');
            return false;
        }

        // Validar decimales (máximo 2)
        const decimales = valor.split('.')[1];
        if (decimales && decimales.length > 2) {
            mostrarError(divError, 'Máximo 2 decimales');
            input.classList.add('input-error');
            return false;
        }

        // Válido
        ocultarError(divError);
        input.classList.remove('input-error');

        datosModificados = true;

        // Actualizar promedio
        actualizarPromedio();

        return true;
    }

    /**
     * Calcula y actualiza el promedio de las calificaciones
     * Considera calificaciones existentes y las que se están capturando
     */
    function actualizarPromedio() {
        if (!elementos.promedioCalificaciones || alumnosCargados.length === 0) {
            return;
        }

        let suma = 0;
        let contador = 0;

        alumnosCargados.forEach((alumno, index) => {
            let calificacion = null;

            // Si ya tiene calificación existente, usarla
            if (alumno.calificacion !== null) {
                calificacion = parseFloat(alumno.calificacion);
            } else {
                // Si no tiene calificación existente, buscar en el input
                const input = document.querySelector(`input[data-index="${index}"]`);
                if (input && input.value.trim() !== '' && input.value !== 'NC') {
                    if (input.value === 'NA') {
                        // Si es NA, usar el valorReal si existe, sino 0
                        calificacion = input.dataset.valorReal ? parseFloat(input.dataset.valorReal) : 0;
                    } else {
                        const numero = parseFloat(input.dataset.valorReal || input.value);
                        if (!isNaN(numero)) {
                            calificacion = numero;
                        }
                    }
                }
            }

            // Solo contar calificaciones válidas (no NC que es -1 y no null)
            if (calificacion !== null && calificacion >= 0) {
                suma += calificacion;
                contador++;
            }
        });

        if (contador === 0) {
            elementos.promedioCalificaciones.innerHTML = '<i class="fas fa-chart-line me-1"></i>Promedio grupal: NC';
            elementos.promedioCalificaciones.className = 'badge bg-secondary me-2';
            elementos.promedioCalificaciones.style.fontSize = '0.95rem';
            return;
        }

        const promedio = suma / contador;
        const promedioFormateado = promedio.toFixed(2);

        // Determinar color del badge según el promedio
        let badgeClass = 'badge me-2';
        if (promedio >= 70) {
            badgeClass += ' bg-success'; // Aprobado
        } else if (promedio >= 60) {
            badgeClass += ' bg-warning'; // En riesgo
        } else {
            badgeClass += ' bg-danger'; // Reprobado
        }

        elementos.promedioCalificaciones.innerHTML = `<i class="fas fa-chart-line me-1"></i>Promedio grupal: ${promedioFormateado}`;
        elementos.promedioCalificaciones.className = badgeClass;
        elementos.promedioCalificaciones.style.fontSize = '0.95rem';
    }

    /**
     * Guarda las calificaciones
     */
    async function guardarCalificaciones() {
        // Recolectar calificaciones
        const calificaciones = [];
        let hayErrores = false;

        alumnosCargados.forEach((alumno, index) => {

            // Solo procesar alumnos realmente sin calificación
            if (alumno.calificacion !== null && alumno.calificacion !== -1) {
                return;
            }

            const input = document.querySelector(`input[data-index="${index}"]`);
            const valor = input.value.trim();
            let calificacionAEnviar;

            // Determinar qué valor enviar según la lógica requerida
            if (valor === '' || valor === 'NC') {
                // No se capturó nada → Enviar -1
                calificacionAEnviar = -1;
            } else if (valor === 'NA') {
                // No acreditado → Enviar 0
                calificacionAEnviar = 0;
            } else {
                // Validar el valor numérico
                const numero = parseFloat(input.dataset.valorReal || valor);

                if (isNaN(numero)) {
                    const divError = document.getElementById(`errorCalificacion${index}`);
                    mostrarError(divError, 'Debe ser un número válido');
                    input.classList.add('input-error');
                    hayErrores = true;
                    return;
                }

                // Si es >= 0 y < 70 → Enviar 0 (No Acreditado)
                if (numero >= 0 && numero < 70) {
                    calificacionAEnviar = 0;
                }
                // Si es >= 70 y <= 100 → Enviar el número
                else if (numero >= 70 && numero <= 100) {
                    calificacionAEnviar = numero;
                } else {
                    const divError = document.getElementById(`errorCalificacion${index}`);
                    mostrarError(divError, 'La calificación debe estar entre 0 y 100');
                    input.classList.add('input-error');
                    hayErrores = true;
                    return;
                }
            }

            // Agregar a la lista de calificaciones a enviar
            calificaciones.push({
                pidCalif: alumno.clave_calificacion,
                punidad: unidadSeleccionada,
                pcalificacion: calificacionAEnviar,
                pidParcial: parcialSeleccionado.clave_parcial,  // o alumno.clave_parcial
                pidHorario: alumno.clave_horario    // o horarioSeleccionado.idHorario
            });
        });

        if (hayErrores) {
            console.log('Hay errores en las calificaciones');
            return;
        }

        if (calificaciones.length === 0) {
            mostrarError(elementos.errorParcial, 'No hay calificaciones para guardar');
            return;
        }

        try {
            // Deshabilitar botón
            elementos.btnGuardarCalificaciones.disabled = true;
            elementos.btnGuardarCalificaciones.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Guardando...';

            const url = "../../Controlador/Intermediarios/Calificaciones/CapturarCalificacionesManual.php";

            console.log("Datos a Enviar desde front:", calificaciones);

            const response = await fetch(url, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ calificaciones }),
            });

            if (!response.ok) {
                throw new Error("Error en la petición: " + response.statusText);
            }

            const resultado = await response.json();

            console.log("Resultado backend:", resultado);

            if (resultado.estado === "OK") {
                // Usar función global para mostrar éxito
                mostrarDatosGuardados(resultado.mensaje,  () => {
                    goTo("captura", "");
                    // Limpiar datos modificados
                    datosModificados = false;
                    // Recargar alumnos para actualizar la tabla
                    cargarAlumnos();
                });

            } else {
                // Manejar errores del backend
                if (resultado.errores && resultado.errores.length > 0) {
                    resultado.errores.forEach(error => {
                        // Buscar el alumno con error
                        const index = alumnosCargados.findIndex(a => a.numeroControl === error.numeroControl);
                        if (index !== -1) {
                            const divError = document.getElementById(`errorCalificacion${index}`);
                            const input = document.querySelector(`input[data-index="${index}"]`);
                            mostrarError(divError, error.mensaje || 'Ya existe una calificación para este alumno');
                            input.classList.add('input-error');
                        }
                    });
                } else {
                    mostrarErrorCaptura(resultado.mensaje || 'Error al guardar las calificaciones');
                }
            }

        } catch (error) {
            console.error('Error al guardar calificaciones:', error);
            mostrarErrorCaptura('Error de conexión al guardar las calificaciones');

        } finally {
            // Restaurar botón
            elementos.btnGuardarCalificaciones.disabled = false;
            elementos.btnGuardarCalificaciones.innerHTML = '<i class="fas fa-save me-2"></i>Guardar Calificaciones';
        }
    }

    /**
     * Maneja el evento de cancelar
     */
    function handleCancelar() {
        // Si hay datos modificados, preguntar confirmación
        if (datosModificados) {
            mostrarConfirmacion(
                'Hay datos sin guardar. ¿Está seguro que desea cancelar?',
                function () {
                    // Limpiar el formulario completamente
                    limpiarFormulario(true);
                    // Redirigir
                    option('captura', '');
                }
            );
        } else {
            // Limpiar el formulario completamente
            limpiarFormulario(true);
            // Redirigir
            option('captura', '');
        }
    }

    /**
     * Muestra un modal con opciones para guardar o continuar sin guardar
     */
    function mostrarModalCambioConGuardado(mensaje, callbackGuardar, callbackContinuar) {
        // Crear el modal
        const modalHtml = `
            <div class="modal fade" id="modalCambioConGuardado" tabindex="-1" aria-hidden="true" data-bs-backdrop="static">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header bg-warning text-dark">
                            <h5 class="modal-title">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                Datos sin guardar
                            </h5>
                        </div>
                        <div class="modal-body">
                            <p class="mb-0">${mensaje}</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                <i class="fas fa-times me-2"></i>Cancelar
                            </button>
                            <button type="button" class="btn btn-danger" id="btnContinuarSinGuardar">
                                <i class="fas fa-arrow-right me-2"></i>Continuar sin guardar
                            </button>
                            <button type="button" class="btn btn-success" id="btnGuardarYContinuar">
                                <i class="fas fa-save me-2"></i>Guardar y continuar
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Eliminar modal anterior si existe
        const modalAnterior = document.getElementById('modalCambioConGuardado');
        if (modalAnterior) {
            modalAnterior.remove();
        }

        // Agregar modal al DOM
        document.body.insertAdjacentHTML('beforeend', modalHtml);

        // Obtener referencias
        const modal = new bootstrap.Modal(document.getElementById('modalCambioConGuardado'));
        const btnGuardarYContinuar = document.getElementById('btnGuardarYContinuar');
        const btnContinuarSinGuardar = document.getElementById('btnContinuarSinGuardar');

        // Event listeners
        btnGuardarYContinuar.addEventListener('click', function () {
            modal.hide();
            callbackGuardar();
        });

        btnContinuarSinGuardar.addEventListener('click', function () {
            modal.hide();
            callbackContinuar();
        });

        // Limpiar modal del DOM cuando se cierre
        document.getElementById('modalCambioConGuardado').addEventListener('hidden.bs.modal', function () {
            this.remove();
        });

        // Mostrar modal
        modal.show();
    }

    /**
     * Guarda las calificaciones y luego ejecuta un callback
     */
    async function guardarCalificacionesYContinuar(callback) {
        // Recolectar calificaciones
        const calificaciones = [];
        let hayErrores = false;

        alumnosCargados.forEach((alumno, index) => {
            // Solo ignorar calificaciones de alumnos que ya tengan valor real (>=0)
            if (alumno.calificacion !== null && alumno.calificacion >= 0) {
                return;
            }

            const input = document.querySelector(`input[data-index="${index}"]`);
            const valor = input.value.trim();
            let calificacionAEnviar;

            // Determinar qué valor enviar según la lógica requerida
            if (valor === '' || valor === 'NC') {
                // No se capturó nada → Enviar -1
                calificacionAEnviar = -1;
            } else if (valor === 'NA') {
                // No acreditado → Enviar 0
                calificacionAEnviar = 0;
            } else {
                // Validar el valor numérico
                const numero = parseFloat(input.dataset.valorReal || valor);

                if (isNaN(numero)) {
                    const divError = document.getElementById(`errorCalificacion${index}`);
                    mostrarError(divError, 'Debe ser un número válido');
                    input.classList.add('input-error');
                    hayErrores = true;
                    return;
                }

                // Si es >= 0 y < 70 → Enviar 0 (No Acreditado)
                if (numero >= 0 && numero < 70) {
                    calificacionAEnviar = 0;
                }
                // Si es >= 70 y <= 100 → Enviar el número
                else if (numero >= 70 && numero <= 100) {
                    calificacionAEnviar = numero;
                } else {
                    const divError = document.getElementById(`errorCalificacion${index}`);
                    mostrarError(divError, 'La calificación debe estar entre 0 y 100');
                    input.classList.add('input-error');
                    hayErrores = true;
                    return;
                }
            }

            // Agregar a la lista de calificaciones a enviar
            calificaciones.push({
                numeroControl: alumno.numeroControl,
                nombreCompleto: alumno.nombreCompleto,
                idParcial: parcialSeleccionado.idParcial,
                idHorario: horarioSeleccionado.idHorario,
                unidad: unidadSeleccionada,
                calificacion: calificacionAEnviar
            });
        });

        if (hayErrores) {
            mostrarError(elementos.errorParcial, 'Corrija los errores antes de continuar');
            console.log('❌ Hay errores en las calificaciones');
            return;
        }

        if (calificaciones.length === 0) {
            mostrarError(elementos.errorParcial, 'No hay calificaciones para guardar');
            return;
        }

        // Imprimir en consola los datos que se enviarán
        console.log('📤 ===== DATOS A ENVIAR AL BACKEND (Guardar y Continuar) =====');
        console.log('📋 Total de calificaciones a guardar:', calificaciones.length);
        console.log('📊 Parcial:', parcialSeleccionado.nombreParcial);
        console.log('📚 Horario:', horarioSeleccionado.nombreMateria);
        console.log('📖 Unidad:', unidadSeleccionada);
        console.log('');
        console.log('👥 Detalle de calificaciones:');
        console.table(calificaciones);
        console.log('');
        console.log('📦 Objeto JSON completo a enviar:');
        console.log(JSON.stringify({ calificaciones }, null, 2));
        console.log('=============================================================');

        try {
            // Mostrar loading en el botón
            elementos.btnGuardarCalificaciones.disabled = true;
            elementos.btnGuardarCalificaciones.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Guardando...';

            // TODO: Reemplazar con la ruta real del backend
            // const response = await fetch('../../Controlador/Intermediarios/Calificacion/GuardarCalificaciones.php', {
            //     method: 'POST',
            //     headers: { 'Content-Type': 'application/json' },
            //     body: JSON.stringify({ calificaciones })
            // });
            //
            // const resultado = await response.json();

            // Simulación de respuesta del backend
            await new Promise(resolve => setTimeout(resolve, 1000));

            const resultado = {
                success: true,
                mensaje: `${calificaciones.length} calificación(es) guardada(s) correctamente`,
                errores: []
            };

            if (resultado.success) {
                // Limpiar datos modificados
                datosModificados = false;

                // Mostrar mensaje de éxito
                mostrarMensajeExito(resultado.mensaje);

                // Ejecutar callback (cambiar selección)
                if (callback) {
                    callback();
                }

            } else {
                // Manejar errores del backend
                if (resultado.errores && resultado.errores.length > 0) {
                    resultado.errores.forEach(error => {
                        const index = alumnosCargados.findIndex(a => a.numeroControl === error.numeroControl);
                        if (index !== -1) {
                            const divError = document.getElementById(`errorCalificacion${index}`);
                            const input = document.querySelector(`input[data-index="${index}"]`);
                            mostrarError(divError, error.mensaje || 'Error al guardar esta calificación');
                            input.classList.add('input-error');
                        }
                    });
                } else {
                    mostrarError(elementos.errorParcial, resultado.mensaje || 'Error al guardar las calificaciones');
                }
            }

        } catch (error) {
            console.error('Error al guardar calificaciones:', error);
            mostrarError(elementos.errorParcial, 'Error de conexión al guardar las calificaciones');

        } finally {
            // Restaurar botón
            elementos.btnGuardarCalificaciones.disabled = false;
            elementos.btnGuardarCalificaciones.innerHTML = '<i class="fas fa-save me-2"></i>Guardar Calificaciones';
        }
    }

    /**
     * Muestra un mensaje de éxito temporal
     */
    function mostrarMensajeExito(mensaje) {
        // Crear alerta
        const alertaHtml = `
            <div class="alert alert-success alert-dismissible fade show" role="alert" id="alertaExitoTemporal">
                <i class="fas fa-check-circle me-2"></i>
                <strong>¡Éxito!</strong> ${mensaje}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        `;

        // Insertar alerta después del título
        const cardBody = elementos.parcialSelect.closest('.card-body');
        cardBody.insertAdjacentHTML('afterbegin', alertaHtml);

        // Auto-cerrar después de 5 segundos
        setTimeout(() => {
            const alerta = document.getElementById('alertaExitoTemporal');
            if (alerta) {
                alerta.remove();
            }
        }, 5000);
    }

    /**
     * Limpia el formulario
     */
    function limpiarFormulario(completo = true) {
        if (completo) {
            // Verificar si hay un parcial único para mantenerlo seleccionado
            const hayParcialUnico = parcialesDisponibles.length === 1;

            if (hayParcialUnico) {
                // Mantener el parcial único seleccionado y deshabilitado
                elementos.parcialSelect.value = parcialesDisponibles[0].idParcial;
                elementos.parcialSelect.disabled = true;
                parcialSeleccionado = parcialesDisponibles[0];
            } else {
                // Si hay múltiples parciales, resetear normalmente
                elementos.parcialSelect.value = '';
                elementos.parcialSelect.disabled = false;
                parcialSeleccionado = null;
            }

            elementos.horarioSelect.value = '';
            elementos.horarioSelect.disabled = true;
            elementos.unidadSelect.value = '';
            elementos.unidadSelect.disabled = true;

            horarioSeleccionado = null;
            unidadSeleccionada = null;

            elementos.alertaParcial.style.display = 'none';
            elementos.infoHorario.style.display = 'none';
        }

        // Limpiar tabla
        elementos.cuerpoAlumnos.innerHTML = `
            <tr>
                <td colspan="5" class="text-center text-muted">
                    <i class="fas fa-info-circle fa-2x mb-2"></i>
                    <p class="mb-0">Seleccione parcial, horario y unidad para cargar los alumnos automáticamente</p>
                </td>
            </tr>
        `;
        elementos.contadorAlumnos.textContent = '0';
        elementos.seccionTabla.style.display = 'none';
        elementos.btnGuardarCalificaciones.style.display = 'none';
        elementos.mensajeSinAlumnos.style.display = 'none';

        alumnosCargados = [];
        datosModificados = false;
    }

    /**
     * Muestra un mensaje de error inline
     */
    function mostrarError(elemento, mensaje) {
        if (!elemento) return;
        elemento.textContent = mensaje;
        elemento.style.display = 'block';
    }

    /**
     * Oculta un mensaje de error
     */
    function ocultarError(elemento) {
        if (!elemento) return;
        elemento.textContent = '';
        elemento.style.display = 'none';
    }

    // API pública
    return {
        inicializar,
        limpiarFormulario
    };
})();

// Hacer disponible globalmente
window.CapturaCalificaciones = CapturaCalificaciones;

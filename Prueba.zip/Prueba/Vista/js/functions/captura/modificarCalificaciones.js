/**
 * Módulo para Modificar Calificaciones
 * Autor: Alex Martinez Gonzalez
 * Descripción: Permite modificar calificaciones previamente capturadas por unidad, parcial y horario
 *
 * Restricciones:
 * - Solo parciales con estatus "Abierto"
 * - Solo se puede modificar el valor de la calificación
 * - Calificaciones en rango 0.00-100.00
 * - Errores inline, no en modales (excepto éxito)
 */

let ModificarCalificaciones = (function () {
    'use strict';

    // Variables de estado
    let parcialSeleccionado = null;
    let horarioSeleccionado = null;
    let unidadSeleccionada = null;
    let calificacionesCargadas = [];
    let calificacionesOriginales = []; // Para detectar cambios
    let cambiosSinGuardar = false;
    let parcialesDisponibles = [];
    let horariosDisponibles = [];
    let idCapturaInicial = null; // ID de la captura a editar
    let modoEdicion = false; // Indica si se cargó desde un registro específico

    // Referencias DOM
    let elementos = {};

    /**
     * Inicializa el módulo
     * @param {string|number} idCaptura - ID de la captura a editar (opcional)
     */
    function inicializar(idCaptura = null) {
        console.log('Inicializando módulo de modificar calificaciones...');

        // Guardar el ID si se proporciona
        if (idCaptura) {
            idCapturaInicial = idCaptura;
            modoEdicion = true;
            console.log('Modo edición activado para ID:', idCaptura);
        }

        // Cachear referencias DOM
        cachearElementos();

        // Configurar event listeners
        configurarEventListeners();

        // Cargar datos iniciales
        if (modoEdicion) {
            // Si hay un ID, cargar los datos de ese registro específico
            cargarDatosRegistro(idCapturaInicial);
        } else {
            // Si no hay ID, solo cargar parciales disponibles
            cargarParcialesAbiertos();
        }

        console.log('Módulo inicializado correctamente');
    }

    /**
     * Cachea las referencias a elementos DOM
     */
    function cachearElementos() {
        elementos = {
            // Selectores
            parcialSelect: document.getElementById('parcialSelectMod'),
            horarioSelect: document.getElementById('horarioSelectMod'),
            unidadSelect: document.getElementById('unidadSelectMod'),

            // Botones
            btnGuardarCambios: document.getElementById('btnGuardarCambios'),
            btnCancelarMod: document.getElementById('btnCancelarMod'),

            // Tablas y contenedores
            cuerpoCalificaciones: document.getElementById('cuerpoCalificacionesMod'),
            contadorCalificaciones: document.getElementById('contadorCalificaciones'),
            contadorModificados: document.getElementById('contadorModificados'),
            promedioCalificaciones: document.getElementById('promedioCalificaciones'),

            // Secciones
            seccionTablaMod: document.getElementById('seccionTablaMod'),
            seccionBotonesMod: document.getElementById('seccionBotonesMod'),
            alertaParcialMod: document.getElementById('alertaParcialMod'),
            mensajeParcialMod: document.getElementById('mensajeParcialMod'),
            infoHorarioMod: document.getElementById('infoHorarioMod'),
            mensajeSinCalificaciones: document.getElementById('mensajeSinCalificaciones'),
            alertaCambiosSinGuardar: document.getElementById('alertaCambiosSinGuardar'),
            alertaSinCambios: document.getElementById('alertaSinCambios'),

            // Info del horario
            infoMateriaMod: document.getElementById('infoMateriaMod'),
            infoDocenteMod: document.getElementById('infoDocenteMod'),
            infoGrupoMod: document.getElementById('infoGrupoMod'),

            // Errores
            errorParcialMod: document.getElementById('errorParcialMod'),
            errorHorarioMod: document.getElementById('errorHorarioMod'),
            errorUnidadMod: document.getElementById('errorUnidadMod')
        };
    }

    /**
     * Configura todos los event listeners
     */
    function configurarEventListeners() {
        // Validar que los elementos existan antes de agregar listeners
        if (!elementos.parcialSelect || !elementos.horarioSelect || !elementos.unidadSelect) {
            console.error('Error: Elementos del formulario no encontrados en el DOM');
            console.log('Elementos faltantes:', {
                parcialSelect: elementos.parcialSelect ? 'OK' : 'FALTA',
                horarioSelect: elementos.horarioSelect ? 'OK' : 'FALTA',
                unidadSelect: elementos.unidadSelect ? 'OK' : 'FALTA'
            });
            return;
        }

        // Selector de parcial
        elementos.parcialSelect.addEventListener('change', handleParcialChange);

        // Selector de horario
        elementos.horarioSelect.addEventListener('change', handleHorarioChange);

        // Selector de unidad - Al cambiar, carga automáticamente las calificaciones
        elementos.unidadSelect.addEventListener('change', handleUnidadChange);

        // Validar botones
        if (elementos.btnGuardarCambios) {
            elementos.btnGuardarCambios.addEventListener('click', guardarCambios);
        }

        if (elementos.btnCancelarMod) {
            elementos.btnCancelarMod.addEventListener('click', handleCancelar);
        }
    }

    /**
     * Carga los datos de un registro específico de captura
     * @param {string|number} idCaptura - ID del registro a editar
     */
    async function cargarDatosRegistro(idCaptura) {
        try {
            console.log('Cargando datos del registro:', idCaptura);

            // TODO: Reemplazar con la ruta real del backend
            // const response = await fetch(`../../Controlador/Intermediarios/Captura/ObtenerDatosCaptura.php?id=${idCaptura}`);
            // const datos = await response.json();

            // Simulación de datos del backend
            const datosMock = {
                exito: true,
                datos: {
                    idParcial: 1,
                    nombreParcial: 'Primer Parcial',
                    estadoParcial: 'Abierto',
                    idPeriodo: 1,
                    idHorario: 1,
                    claveMateria: 'MAT101',
                    nombreMateria: 'Cálculo Diferencial',
                    nombreDocente: 'Ing. Juan Pérez',
                    semestre: 1,
                    grupo: 'A',
                    turno: 'Matutino',
                    unidad: 1
                }
            };

            if (!datosMock.exito) {
                mostrarError(elementos.errorParcialMod, 'Error al cargar los datos del registro');
                return;
            }

            const datos = datosMock.datos;

            // Cargar parciales abiertos primero
            await cargarParcialesAbiertos();

            // Pre-seleccionar el parcial y deshabilitarlo
            elementos.parcialSelect.value = datos.idParcial;
            elementos.parcialSelect.disabled = true;
            parcialSeleccionado = {
                idParcial: datos.idParcial,
                nombreParcial: datos.nombreParcial,
                estado: datos.estadoParcial,
                idPeriodo: datos.idPeriodo
            };

            // Cargar horarios del periodo
            await cargarHorariosPorParcial(datos.idPeriodo);

            // Pre-seleccionar el horario y deshabilitarlo
            elementos.horarioSelect.value = datos.idHorario;
            elementos.horarioSelect.disabled = true;
            elementos.horarioSelect.classList.add('bg-light');
            horarioSeleccionado = {
                idHorario: datos.idHorario,
                claveMateria: datos.claveMateria,
                nombreMateria: datos.nombreMateria,
                nombreDocente: datos.nombreDocente,
                semestre: datos.semestre,
                grupo: datos.grupo,
                turno: datos.turno
            };

            // Mostrar información del horario
            elementos.infoMateriaMod.textContent = `${datos.claveMateria} - ${datos.nombreMateria}`;
            elementos.infoDocenteMod.textContent = datos.nombreDocente;
            elementos.infoGrupoMod.textContent = `${datos.semestre}° ${datos.grupo} - ${datos.turno}`;
            elementos.infoHorarioMod.style.display = 'block';

            // Habilitar y pre-seleccionar la unidad, luego deshabilitarla
            elementos.unidadSelect.disabled = false;
            elementos.unidadSelect.value = datos.unidad;
            elementos.unidadSelect.disabled = true;
            elementos.unidadSelect.classList.add('bg-light');
            unidadSeleccionada = datos.unidad;

            // Deshabilitar también el parcial visualmente
            elementos.parcialSelect.classList.add('bg-light');

            // Cargar automáticamente las calificaciones
            await buscarCalificaciones();

            console.log('Datos cargados y formulario bloqueado para edición');

        } catch (error) {
            console.error('Error al cargar datos del registro:', error);
            mostrarError(elementos.errorParcialMod, 'Error al cargar los datos. Intente nuevamente.');
        }
    }

    /**
     * Carga los parciales con estatus "Abierto"
     */
    async function cargarParcialesAbiertos() {
        try {
            // TODO: Reemplazar con la ruta real del backend
            // const response = await fetch('../../Controlador/Intermediarios/Parcial/ObtenerParcialesAbiertos.php');

            // Simulación de datos mientras se implementa el backend
            const parcialesMock = [
                {idParcial: 1, nombreParcial: 'Primer Parcial', estado: 'Abierto', idPeriodo: 1},
                {idParcial: 3, nombreParcial: 'Tercer Parcial', estado: 'Abierto', idPeriodo: 1}
            ];

            parcialesDisponibles = parcialesMock;

            // Limpiar select
            elementos.parcialSelect.innerHTML = '<option value="">Seleccione un parcial...</option>';

            // Agregar opciones
            parcialesDisponibles.forEach(parcial => {
                const option = document.createElement('option');
                option.value = parcial.idParcial;
                option.textContent = `${parcial.nombreParcial} (${parcial.estado})`;
                option.dataset.estado = parcial.estado;
                option.dataset.idPeriodo = parcial.idPeriodo;
                elementos.parcialSelect.appendChild(option);
            });

            console.log(`${parcialesDisponibles.length} parciales abiertos cargados`);

        } catch (error) {
            console.error('Error al cargar parciales:', error);
            mostrarError(elementos.errorParcialMod, 'Error al cargar los parciales disponibles');
        }
    }

    /**
     * Maneja el cambio de parcial
     */
    function handleParcialChange(e) {
        // Si está en modo edición, no permitir cambios
        if (modoEdicion) {
            e.preventDefault();
            return;
        }

        const idParcial = e.target.value;

        // Verificar si hay cambios sin guardar
        if (cambiosSinGuardar) {
            const valorAnterior = parcialSeleccionado ? parcialSeleccionado.idParcial : '';
            e.target.value = valorAnterior;

            // Mostrar modal de confirmación usando función global
            mostrarConfirmacion(
                'Hay cambios sin guardar. Si cambia los criterios de búsqueda, perderá todos los cambios. ¿Desea continuar?',
                function () {
                    // Usuario confirmó el cambio
                    cambiosSinGuardar = false;
                    limpiarFormulario();
                    e.target.value = idParcial;
                    aplicarCambioParcial(idParcial);
                },
                function () {
                    // Usuario canceló
                    e.target.value = valorAnterior;
                }
            );
            return;
        }

        aplicarCambioParcial(idParcial);
    }

    /**
     * Aplica el cambio de parcial
     */
    function aplicarCambioParcial(idParcial) {
        // Limpiar error previo
        ocultarError(elementos.errorParcialMod);
        elementos.parcialSelect.classList.remove('input-error');

        if (!idParcial) {
            parcialSeleccionado = null;
            elementos.horarioSelect.disabled = true;
            elementos.unidadSelect.disabled = true;
            elementos.alertaParcialMod.style.display = 'none';
            limpiarFormulario();
            return;
        }

        // Buscar información del parcial
        const parcial = parcialesDisponibles.find(p => p.idParcial == idParcial);

        if (!parcial) {
            mostrarError(elementos.errorParcialMod, 'Parcial no encontrado');
            return;
        }

        parcialSeleccionado = parcial;

        // Verificar que el parcial esté abierto
        if (parcial.estado !== 'Abierto') {
            elementos.mensajeParcialMod.textContent = 'El parcial seleccionado no está abierto. No se pueden modificar calificaciones.';
            elementos.alertaParcialMod.style.display = 'block';
            elementos.horarioSelect.disabled = true;
            elementos.unidadSelect.disabled = true;
            limpiarFormulario();
            return;
        }

        elementos.alertaParcialMod.style.display = 'none';

        // Cargar horarios del parcial
        cargarHorariosPorParcial(parcial.idPeriodo);

        // Habilitar selector de horario
        elementos.horarioSelect.disabled = false;

        // Limpiar formulario
        limpiarFormulario();
    }

    /**
     * Carga los horarios disponibles para el periodo del parcial
     */
    async function cargarHorariosPorParcial(idPeriodo) {
        try {
            // TODO: Reemplazar con la ruta real del backend
            // const response = await fetch(`../../Controlador/Intermediarios/Horario/ObtenerHorariosPorPeriodo.php?idPeriodo=${idPeriodo}`);

            // Simulación de datos
            const horariosMock = [
                {
                    idHorario: 1,
                    claveMateria: 'MAT101',
                    nombreMateria: 'Cálculo Diferencial',
                    nombreDocente: 'Ing. Juan Pérez',
                    semestre: 1,
                    grupo: 'A',
                    turno: 'Matutino'
                },
                {
                    idHorario: 2,
                    claveMateria: 'FIS102',
                    nombreMateria: 'Física I',
                    nombreDocente: 'Dr. María González',
                    semestre: 1,
                    grupo: 'B',
                    turno: 'Vespertino'
                }
            ];

            horariosDisponibles = horariosMock;

            // Limpiar select
            elementos.horarioSelect.innerHTML = '<option value="">Seleccione un horario...</option>';

            // Agregar opciones
            horariosDisponibles.forEach(horario => {
                const option = document.createElement('option');
                option.value = horario.idHorario;
                option.textContent = `${horario.claveMateria} - ${horario.nombreMateria} | ${horario.semestre}° ${horario.grupo}`;
                elementos.horarioSelect.appendChild(option);
            });

            console.log(`${horariosDisponibles.length} horarios cargados`);

        } catch (error) {
            console.error('Error al cargar horarios:', error);
            mostrarError(elementos.errorHorarioMod, 'Error al cargar los horarios disponibles');
        }
    }

    /**
     * Maneja el cambio de horario
     */
    function handleHorarioChange(e) {
        // Si está en modo edición, no permitir cambios
        if (modoEdicion) {
            e.preventDefault();
            return;
        }

        const idHorario = e.target.value;

        // Verificar si hay cambios sin guardar
        if (cambiosSinGuardar) {
            const valorAnterior = horarioSeleccionado ? horarioSeleccionado.idHorario : '';
            e.target.value = valorAnterior;

            // Mostrar modal de confirmación usando función global
            mostrarConfirmacion(
                'Hay cambios sin guardar. Si cambia los criterios de búsqueda, perderá todos los cambios. ¿Desea continuar?',
                function () {
                    // Usuario confirmó el cambio
                    cambiosSinGuardar = false;
                    limpiarFormulario();
                    e.target.value = idHorario;
                    aplicarCambioHorario(idHorario);
                },
                function () {
                    // Usuario canceló
                    e.target.value = valorAnterior;
                }
            );
            return;
        }

        aplicarCambioHorario(idHorario);
    }

    /**
     * Aplica el cambio de horario
     */
    function aplicarCambioHorario(idHorario) {
        // Limpiar error previo
        ocultarError(elementos.errorHorarioMod);
        elementos.horarioSelect.classList.remove('input-error');

        if (!idHorario) {
            horarioSeleccionado = null;
            elementos.unidadSelect.disabled = true;
            elementos.infoHorarioMod.style.display = 'none';
            limpiarFormulario();
            return;
        }

        // Buscar información del horario
        const horario = horariosDisponibles.find(h => h.idHorario == idHorario);

        if (!horario) {
            mostrarError(elementos.errorHorarioMod, 'Horario no encontrado');
            return;
        }

        horarioSeleccionado = horario;

        // Mostrar información del horario
        elementos.infoMateriaMod.textContent = `${horario.claveMateria} - ${horario.nombreMateria}`;
        elementos.infoDocenteMod.textContent = horario.nombreDocente;
        elementos.infoGrupoMod.textContent = `${horario.semestre}° ${horario.grupo} - ${horario.turno}`;
        elementos.infoHorarioMod.style.display = 'block';

        // Habilitar selector de unidad
        elementos.unidadSelect.disabled = false;

        // Limpiar tabla
        limpiarFormulario();
    }

    /**
     * Maneja el cambio de unidad
     */
    function handleUnidadChange(e) {
        // Si está en modo edición, no permitir cambios
        if (modoEdicion) {
            e.preventDefault();
            return;
        }

        const unidad = e.target.value;

        // Verificar si hay cambios sin guardar
        if (cambiosSinGuardar) {
            const valorAnterior = unidadSeleccionada || '';
            e.target.value = valorAnterior;

            // Mostrar modal de confirmación usando función global
            mostrarConfirmacion(
                'Hay cambios sin guardar. Si cambia los criterios de búsqueda, perderá todos los cambios. ¿Desea continuar?',
                function () {
                    // Usuario confirmó el cambio
                    cambiosSinGuardar = false;
                    limpiarFormulario();
                    e.target.value = unidad;
                    aplicarCambioUnidad(unidad);
                },
                function () {
                    // Usuario canceló
                    e.target.value = valorAnterior;
                }
            );
            return;
        }

        aplicarCambioUnidad(unidad);
    }

    /**
     * Aplica el cambio de unidad
     */
    function aplicarCambioUnidad(unidad) {
        // Limpiar error previo
        ocultarError(elementos.errorUnidadMod);
        elementos.unidadSelect.classList.remove('input-error');

        unidadSeleccionada = unidad || null;

        // Limpiar tabla
        limpiarFormulario();

        // Si se seleccionó una unidad y hay parcial y horario, cargar automáticamente
        if (unidadSeleccionada && parcialSeleccionado && horarioSeleccionado && parcialSeleccionado.estado === 'Abierto') {
            buscarCalificaciones();
        }
    }

    /**
     * Busca las calificaciones existentes para la combinación seleccionada
     */
    async function buscarCalificaciones() {
        if (!parcialSeleccionado || !horarioSeleccionado || !unidadSeleccionada) {
            mostrarError(elementos.errorParcialMod, 'Debe seleccionar parcial, horario y unidad');
            return;
        }

        try {
            // Ocultar alertas
            elementos.mensajeSinCalificaciones.style.display = 'none';
            elementos.alertaSinCambios.style.display = 'none';

            // Mostrar loading
            elementos.cuerpoCalificaciones.innerHTML = `
                <tr>
                    <td colspan="6" class="text-center">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Cargando...</span>
                        </div>
                        <p class="mt-2 mb-0">Buscando calificaciones...</p>
                    </td>
                </tr>
            `;
            elementos.seccionTablaMod.style.display = 'block';

            // TODO: Reemplazar con la ruta real del backend
            // const response = await fetch('../../Controlador/Intermediarios/Captura/ObtenerCalificaciones.php', {
            //     method: 'POST',
            //     headers: { 'Content-Type': 'application/json' },
            //     body: JSON.stringify({
            //         idHorario: horarioSeleccionado.idHorario,
            //         idParcial: parcialSeleccionado.idParcial,
            //         unidad: unidadSeleccionada
            //     })
            // });

            // Simulación de datos
            const calificacionesMock = [
                {
                    idCaptura: 1,
                    numeroControl: '20240001',
                    nombreCompleto: 'Juan Pérez García',
                    semestre: 1,
                    calificacion: 85.50,
                    idHorario: 1,
                    idParcial: 1,
                    unidad: 1
                },
                {
                    idCaptura: 2,
                    numeroControl: '20240002',
                    nombreCompleto: 'María López Hernández',
                    semestre: 1,
                    calificacion: 92.00,
                    idHorario: 1,
                    idParcial: 1,
                    unidad: 1
                },
                {
                    idCaptura: 3,
                    numeroControl: '20240003',
                    nombreCompleto: 'Carlos Ramírez Sánchez',
                    semestre: 1,
                    calificacion: 78.75,
                    idHorario: 1,
                    idParcial: 1,
                    unidad: 1
                },
                {
                    idCaptura: 4,
                    numeroControl: '20240004',
                    nombreCompleto: 'Ana Martínez Torres',
                    semestre: 1,
                    calificacion: 30.50,
                    idHorario: 1,
                    idParcial: 1,
                    unidad: 1
                },
                {
                    idCaptura: 5,
                    numeroControl: '20240005',
                    nombreCompleto: 'Pedro González Ruiz',
                    semestre: 1,
                    calificacion: 0,
                    idHorario: 1,
                    idParcial: 1,
                    unidad: 1
                },
                {
                    idCaptura: 6,
                    numeroControl: '20240006',
                    nombreCompleto: 'Laura Sánchez Díaz',
                    semestre: 1,
                    calificacion: -1,
                    idHorario: 1,
                    idParcial: 1,
                    unidad: 1
                },
                {
                    idCaptura: 7,
                    numeroControl: '20240007',
                    nombreCompleto: 'Roberto Fernández López',
                    semestre: 1,
                    calificacion: 69.99,
                    idHorario: 1,
                    idParcial: 1,
                    unidad: 1
                }
            ];

            calificacionesCargadas = calificacionesMock;

            // Guardar copia de calificaciones originales para detectar cambios
            calificacionesOriginales = JSON.parse(JSON.stringify(calificacionesMock));

            if (calificacionesCargadas.length === 0) {
                // No hay calificaciones
                elementos.mensajeSinCalificaciones.style.display = 'block';
                elementos.cuerpoCalificaciones.innerHTML = `
                    <tr>
                        <td colspan="6" class="text-center text-muted">
                            <i class="fas fa-clipboard-list fa-2x mb-2"></i>
                            <p class="mb-0">No hay calificaciones registradas para esta combinación</p>
                        </td>
                    </tr>
                `;
                elementos.seccionBotonesMod.style.display = 'none';
            } else {
                // Renderizar tabla
                renderizarTablaCalificaciones();
                elementos.seccionBotonesMod.style.display = 'block';
                elementos.btnGuardarCambios.disabled = true; // Inicialmente deshabilitado hasta que haya cambios
            }

            cambiosSinGuardar = false;
            actualizarContadorModificados();

        } catch (error) {
            console.error('Error al buscar calificaciones:', error);
            elementos.cuerpoCalificaciones.innerHTML = `
                <tr>
                    <td colspan="6" class="text-center text-danger">
                        <i class="fas fa-exclamation-triangle fa-2x mb-2"></i>
                        <p class="mb-0">Error al cargar las calificaciones. Intente nuevamente.</p>
                    </td>
                </tr>
            `;
        }
    }

    /**
     * Renderiza la tabla de calificaciones
     */
    function renderizarTablaCalificaciones() {
        elementos.cuerpoCalificaciones.innerHTML = '';

        calificacionesCargadas.forEach((calificacion, index) => {
            const tr = document.createElement('tr');

            // Número de Control
            const tdNC = document.createElement('td');
            tdNC.textContent = calificacion.numeroControl;
            tr.appendChild(tdNC);

            // Nombre Completo
            const tdNombre = document.createElement('td');
            tdNombre.textContent = calificacion.nombreCompleto;
            tr.appendChild(tdNombre);

            // Semestre
            const tdSemestre = document.createElement('td');
            tdSemestre.className = 'text-center';
            tdSemestre.textContent = `${calificacion.semestre}°`;
            tr.appendChild(tdSemestre);

            // Calificación Actual
            const tdCalActual = document.createElement('td');
            tdCalActual.className = 'text-center';
            const spanActual = document.createElement('span');
            spanActual.className = 'badge bg-info';

            // Mostrar la calificación actual según su valor
            const calActual = parseFloat(calificacion.calificacion);
            if (calActual === -1) {
                spanActual.textContent = 'NC';
            } else if (calActual >= 0 && calActual < 70) {
                spanActual.textContent = 'NA';
            } else if (calActual >= 70 && calActual <= 100) {
                spanActual.textContent = calActual.toFixed(2);
            } else {
                spanActual.textContent = 'ERROR';
            }

            tdCalActual.appendChild(spanActual);
            tr.appendChild(tdCalActual);

            // Nueva Calificación (editable)
            const tdCalNueva = document.createElement('td');
            const divCalificacion = document.createElement('div');
            divCalificacion.className = 'd-flex flex-column';

            const input = document.createElement('input');
            input.className = 'form-control form-control-sm calificacion-input';
            input.min = '0';
            input.max = '100';
            input.step = '0.01';
            input.dataset.index = index;
            input.dataset.idCaptura = calificacion.idCaptura;
            input.dataset.valorOriginal = calificacion.calificacion.toFixed(2);

            // Configurar el valor inicial del input según el valor de la calificación
            const calVal = parseFloat(calificacion.calificacion);
            if (calVal === -1) {
                input.type = 'text';
                input.value = 'NC';
            } else if (calVal >= 0 && calVal < 70) {
                input.type = 'text';
                input.value = 'NA';
                input.dataset.valorReal = calVal;
            } else if (calVal >= 70 && calVal <= 100) {
                input.type = 'number';
                input.value = calVal.toFixed(2);
                input.dataset.valorReal = calVal;
            } else {
                input.type = 'text';
                input.value = 'ERROR';
            }

            // Event listener para mostrar NA o número al perder el foco
            input.addEventListener('blur', (e) => {
                const valor = e.target.value.trim();
                if (valor === '') return;
                if (valor === 'NC' || valor === 'NA') return;

                const numero = parseFloat(valor);
                if (!isNaN(numero)) {
                    if (numero >= 0 && numero < 70) {
                        // Guardar el valor real en un atributo data
                        e.target.dataset.valorReal = numero.toFixed(2);
                        e.target.type = 'text';
                        e.target.value = 'NA';
                    } else if (numero >= 70 && numero <= 100) {
                        e.target.value = numero.toFixed(2);
                        e.target.dataset.valorReal = numero.toFixed(2);
                    }
                    // Forzar validación después de formatear
                    validarCalificacion(e, index);
                }
            });

            // Event listener para restaurar número al hacer foco si es NA
            input.addEventListener('focus', (e) => {
                if (e.target.value === 'NA' && e.target.dataset.valorReal) {
                    e.target.type = 'number';
                    e.target.value = parseFloat(e.target.dataset.valorReal).toFixed(2);
                }
            });

            // Event listeners para validación
            input.addEventListener('keypress', (e) => validarTeclaCalificacion(e));
            input.addEventListener('input', (e) => validarCalificacion(e, index));
            input.addEventListener('change', (e) => validarCalificacion(e, index));

            divCalificacion.appendChild(input);

            // Contenedor de error
            const divError = document.createElement('div');
            divError.id = `errorCalificacionMod${index}`;
            divError.className = 'error-message mt-1';
            divError.style.display = 'none';
            divCalificacion.appendChild(divError);

            tdCalNueva.appendChild(divCalificacion);
            tr.appendChild(tdCalNueva);

            // Estado
            const tdEstado = document.createElement('td');
            tdEstado.className = 'text-center';
            const spanEstado = document.createElement('span');
            spanEstado.id = `estadoCalificacion${index}`;
            spanEstado.className = 'badge bg-secondary';
            spanEstado.innerHTML = '<i class="fas fa-check me-1"></i>Sin cambios';
            tdEstado.appendChild(spanEstado);
            tr.appendChild(tdEstado);

            elementos.cuerpoCalificaciones.appendChild(tr);
        });

        // Actualizar contador y promedio
        elementos.contadorCalificaciones.textContent = calificacionesCargadas.length;
        actualizarPromedio();
    }

    /**
     * Valida las teclas presionadas en el campo de calificación
     */
    function validarTeclaCalificacion(e) {
        const valor = e.target.value;
        const char = e.key;

        // Permitir teclas de control
        if (e.ctrlKey || e.metaKey || char === 'Backspace' || char === 'Delete' ||
            char === 'ArrowLeft' || char === 'ArrowRight' || char === 'Tab') {
            return;
        }

        // Solo permitir números y punto decimal
        if (!/^\d$/.test(char) && char !== '.') {
            e.preventDefault();
            return;
        }

        // Verificar si el valor actual ya es >= 100
        const valorActual = parseFloat(valor);
        if (!isNaN(valorActual) && valorActual >= 100) {
            e.preventDefault();
            return;
        }

        // Verificar si al agregar el nuevo carácter se excedería 100
        const valorPotencial = valor + char;
        const numeroPotencial = parseFloat(valorPotencial);
        if (!isNaN(numeroPotencial) && numeroPotencial > 100 && char !== '.') {
            e.preventDefault();
            return;
        }

        // Permitir solo un punto decimal
        if (char === '.' && valor.includes('.')) {
            e.preventDefault();
            return;
        }

        // Si ya escribió "100", no permitir punto decimal
        if (char === '.' && valorActual === 100) {
            e.preventDefault();
            return;
        }

        // Limitar enteros a 3 dígitos
        const partes = valor.split('.');
        if (partes[0].length >= 3 && char !== '.' && !valor.includes('.')) {
            e.preventDefault();
            return;
        }

        // Limitar decimales a 2 dígitos
        if (valor.includes('.') && partes[1] && partes[1].length >= 2 && char !== '.') {
            e.preventDefault();
            return;
        }
    }

    /**
     * Valida una calificación modificada
     */
    function validarCalificacion(e, index) {
        const input = e.target;
        const valor = input.value.trim();
        const divError = document.getElementById(`errorCalificacionMod${index}`);
        const spanEstado = document.getElementById(`estadoCalificacion${index}`);
        const valorOriginal = parseFloat(input.dataset.valorOriginal);

        // Si está vacío, mostrar error (es obligatorio)
        if (valor === '') {
            mostrarError(divError, 'La calificación es obligatoria');
            input.classList.add('input-error');
            spanEstado.className = 'badge bg-danger';
            spanEstado.innerHTML = '<i class="fas fa-times me-1"></i>Error';
            actualizarPromedio();
            return false;
        }

        // Si es NC, procesar
        if (valor === 'NC') {
            ocultarError(divError);
            input.classList.remove('input-error');

            const valorNumerico = -1;
            const numeroFormateado = parseFloat(valorNumerico.toFixed(2));
            const originalFormateado = parseFloat(valorOriginal.toFixed(2));

            if (Math.abs(numeroFormateado - originalFormateado) > 0.001) {
                spanEstado.className = 'badge bg-warning';
                spanEstado.innerHTML = '<i class="fas fa-edit me-1"></i>Modificado';
                calificacionesCargadas[index].calificacionNueva = numeroFormateado;
                cambiosSinGuardar = true;
            } else {
                spanEstado.className = 'badge bg-secondary';
                spanEstado.innerHTML = '<i class="fas fa-check me-1"></i>Sin cambios';
                delete calificacionesCargadas[index].calificacionNueva;
            }

            actualizarEstadoBotones();
            actualizarContadorModificados();
            actualizarPromedio();
            return true;
        }

        // Si es NA (No Acreditado), es válido
        if (valor === 'NA') {
            ocultarError(divError);
            input.classList.remove('input-error');

            // Si tiene valorReal, usar ese, sino usar 0
            const valorNumerico = input.dataset.valorReal ? parseFloat(input.dataset.valorReal) : 0;
            const numeroFormateado = parseFloat(valorNumerico.toFixed(2));
            const originalFormateado = parseFloat(valorOriginal.toFixed(2));

            if (Math.abs(numeroFormateado - originalFormateado) > 0.001) {
                spanEstado.className = 'badge bg-warning';
                spanEstado.innerHTML = '<i class="fas fa-edit me-1"></i>Modificado';
                calificacionesCargadas[index].calificacionNueva = numeroFormateado;
                cambiosSinGuardar = true;
            } else {
                spanEstado.className = 'badge bg-secondary';
                spanEstado.innerHTML = '<i class="fas fa-check me-1"></i>Sin cambios';
                delete calificacionesCargadas[index].calificacionNueva;
            }

            actualizarEstadoBotones();
            actualizarContadorModificados();
            actualizarPromedio();
            return true;
        }

        // Validar formato numérico
        const numero = parseFloat(input.dataset.valorReal || valor);

        if (isNaN(numero)) {
            mostrarError(divError, 'Debe ser un número válido');
            input.classList.add('input-error');
            spanEstado.className = 'badge bg-danger';
            spanEstado.innerHTML = '<i class="fas fa-times me-1"></i>Error';
            return false;
        }

        // Validar formato: máximo 3 enteros y 2 decimales
        const valorAValidar = input.dataset.valorReal || valor;
        const regexFormato = /^\d{1,3}(\.\d{0,2})?$/;
        if (!regexFormato.test(valorAValidar)) {
            mostrarError(divError, 'Formato inválido. Máximo 3 enteros y 2 decimales (ej: 100.00)');
            input.classList.add('input-error');
            spanEstado.className = 'badge bg-danger';
            spanEstado.innerHTML = '<i class="fas fa-times me-1"></i>Error';
            return false;
        }

        // Validar rango
        if (numero < 0 || numero > 100) {
            mostrarError(divError, 'Debe estar entre 0.00 y 100.00');
            input.classList.add('input-error');
            spanEstado.className = 'badge bg-danger';
            spanEstado.innerHTML = '<i class="fas fa-times me-1"></i>Error';
            return false;
        }

        // Validar decimales (máximo 2)
        const decimales = valorAValidar.split('.')[1];
        if (decimales && decimales.length > 2) {
            mostrarError(divError, 'Máximo 2 decimales');
            input.classList.add('input-error');
            spanEstado.className = 'badge bg-danger';
            spanEstado.innerHTML = '<i class="fas fa-times me-1"></i>Error';
            return false;
        }

        // Válido
        ocultarError(divError);
        input.classList.remove('input-error');

        // Verificar si cambió respecto al valor original
        // Comparar directamente el número con el valor original
        const numeroFormateado = parseFloat(numero.toFixed(2));
        const originalFormateado = parseFloat(valorOriginal.toFixed(2));

        if (Math.abs(numeroFormateado - originalFormateado) > 0.001) {
            spanEstado.className = 'badge bg-warning';
            spanEstado.innerHTML = '<i class="fas fa-edit me-1"></i>Modificado';
            calificacionesCargadas[index].calificacionNueva = numeroFormateado;
            cambiosSinGuardar = true;
        } else {
            spanEstado.className = 'badge bg-secondary';
            spanEstado.innerHTML = '<i class="fas fa-check me-1"></i>Sin cambios';
            delete calificacionesCargadas[index].calificacionNueva;
        }

        // Actualizar estado de botones y contadores
        actualizarEstadoBotones();
        actualizarContadorModificados();
        actualizarPromedio();

        return true;
    }

    /**
     * Actualiza el estado de los botones según haya cambios válidos
     */
    function actualizarEstadoBotones() {
        // Contar cuántos tienen cambios válidos
        const cambiosValidos = calificacionesCargadas.filter(cal => {
            return cal.hasOwnProperty('calificacionNueva');
        }).length;

        // Verificar si hay errores
        const hayErrores = document.querySelectorAll('.calificacion-input.input-error').length > 0;

        // Habilitar/deshabilitar botón guardar
        elementos.btnGuardarCambios.disabled = cambiosValidos === 0 || hayErrores;

        // Ocultar alerta de sin cambios
        elementos.alertaSinCambios.style.display = 'none';
    }

    /**
     * Actualiza el contador de modificados
     */
    function actualizarContadorModificados() {
        const cantidad = calificacionesCargadas.filter(cal => cal.hasOwnProperty('calificacionNueva')).length;
        elementos.contadorModificados.innerHTML = `<i class="fas fa-edit me-1"></i>Modificados: ${cantidad}`;

        if (cantidad > 0) {
            elementos.contadorModificados.className = 'badge bg-warning me-2';
        } else {
            elementos.contadorModificados.className = 'badge bg-success me-2';
        }

        // Actualizar el promedio
        actualizarPromedio();
    }

    /**
     * Calcula y actualiza el promedio de las calificaciones
     * Considera las calificaciones modificadas si existen
     */
    function actualizarPromedio() {
        if (!elementos.promedioCalificaciones || calificacionesCargadas.length === 0) {
            return;
        }

        let suma = 0;
        let contador = 0;

        calificacionesCargadas.forEach(cal => {
            // Usar la calificación nueva si existe, sino la original
            const calificacion = cal.hasOwnProperty('calificacionNueva')
                ? cal.calificacionNueva
                : cal.calificacion;

            // Solo contar calificaciones válidas (no NC que es -1)
            if (calificacion >= 0) {
                suma += parseFloat(calificacion);
                contador++;
            }
        });

        if (contador === 0) {
            elementos.promedioCalificaciones.innerHTML = '<i class="fas fa-chart-line me-1"></i>Promedio grupal: NC';
            elementos.promedioCalificaciones.className = 'badge bg-secondary me-2';
            return;
        }

        const promedio = suma / contador;
        const promedioFormateado = promedio.toFixed(2);

        // Determinar color del badge según el promedio
        let badgeClass = 'badge me-2';
        if (promedio >= 70) {
            badgeClass += ' bg-success'; // Aprobado
        } else if (promedio >= 60) {
            badgeClass += ' bg-warning'; // En riesgo
        } else {
            badgeClass += ' bg-danger'; // Reprobado
        }

        elementos.promedioCalificaciones.innerHTML = `<i class="fas fa-chart-line me-1"></i>Promedio grupal: ${promedioFormateado}`;
        elementos.promedioCalificaciones.className = badgeClass;
        elementos.promedioCalificaciones.style.fontSize = '0.95rem';
    }

    /**
     * Guarda los cambios realizados
     */
    async function guardarCambios() {
        // Verificar que el parcial siga abierto
        if (!parcialSeleccionado || parcialSeleccionado.estado !== 'Abierto') {
            mostrarError(elementos.errorParcialMod, 'El parcial ya no está abierto. No se pueden guardar cambios.');
            return;
        }

        // Obtener solo las calificaciones modificadas con lógica de conversión
        const calificacionesModificadas = [];
        let hayErrores = false;

        calificacionesCargadas.forEach((cal, index) => {
            if (!cal.hasOwnProperty('calificacionNueva')) {
                return; // No hay cambios en esta calificación
            }

            const input = document.querySelector(`input[data-index="${index}"]`);
            const valor = input.value.trim();
            let calificacionAEnviar;

            // Determinar qué valor enviar según la lógica requerida
            if (valor === '' || valor === 'NC') {
                // No se capturó nada → Enviar -1
                calificacionAEnviar = -1;
            } else if (valor === 'NA') {
                // No acreditado → Enviar 0 o el valorReal si existe
                if (input.dataset.valorReal) {
                    const valorReal = parseFloat(input.dataset.valorReal);
                    // Si el valorReal es < 70, enviar 0
                    calificacionAEnviar = valorReal >= 0 && valorReal < 70 ? 0 : valorReal;
                } else {
                    calificacionAEnviar = 0;
                }
            } else {
                // Validar el valor numérico
                const numero = parseFloat(input.dataset.valorReal || valor);

                if (isNaN(numero)) {
                    const divError = document.getElementById(`errorCalificacionMod${index}`);
                    mostrarError(divError, 'Debe ser un número válido');
                    input.classList.add('input-error');
                    hayErrores = true;
                    return;
                }

                // Si es >= 0 y < 70 → Enviar 0 (No Acreditado)
                if (numero >= 0 && numero < 70) {
                    calificacionAEnviar = 0;
                }
                // Si es >= 70 y <= 100 → Enviar el número
                else if (numero >= 70 && numero <= 100) {
                    calificacionAEnviar = numero;
                } else {
                    const divError = document.getElementById(`errorCalificacionMod${index}`);
                    mostrarError(divError, 'La calificación debe estar entre 0 y 100');
                    input.classList.add('input-error');
                    hayErrores = true;
                    return;
                }
            }

            calificacionesModificadas.push({
                idCaptura: cal.idCaptura,
                calificacion: calificacionAEnviar,
                numeroControl: cal.numeroControl,
                nombreCompleto: cal.nombreCompleto
            });
        });

        if (hayErrores) {
            console.log('❌ Hay errores en las calificaciones modificadas');
            mostrarError(elementos.errorParcialMod, 'Corrija los errores antes de guardar');
            return;
        }

        if (calificacionesModificadas.length === 0) {
            elementos.alertaSinCambios.style.display = 'block';
            setTimeout(() => {
                elementos.alertaSinCambios.style.display = 'none';
            }, 5000);
            return;
        }

        // Imprimir en consola los datos que se enviarán
        console.log('📤 ===== DATOS A ENVIAR AL BACKEND (MODIFICAR) =====');
        console.log('📋 Total de calificaciones a modificar:', calificacionesModificadas.length);
        console.log('📊 Parcial:', parcialSeleccionado.nombreParcial);
        console.log('📚 Horario:', horarioSeleccionado.nombreMateria);
        console.log('📖 Unidad:', unidadSeleccionada);
        console.log('');
        console.log('👥 Detalle de calificaciones modificadas:');
        console.table(calificacionesModificadas);
        console.log('');
        console.log('📦 Objeto JSON completo a enviar:');
        console.log(JSON.stringify({
            calificaciones: calificacionesModificadas,
            idParcial: parcialSeleccionado.idParcial
        }, null, 2));
        console.log('======================================');

        try {
            // Deshabilitar botón mientras se guarda
            elementos.btnGuardarCambios.disabled = true;
            elementos.btnGuardarCambios.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Guardando...';

            // TODO: Reemplazar con la ruta real del backend
            // const response = await fetch('../../Controlador/Intermediarios/Captura/ModificarCalificaciones.php', {
            //     method: 'POST',
            //     headers: { 'Content-Type': 'application/json' },
            //     body: JSON.stringify({
            //         calificaciones: calificacionesModificadas,
            //         idParcial: parcialSeleccionado.idParcial
            //     })
            // });

            // Simulación de guardado exitoso
            await new Promise(resolve => setTimeout(resolve, 1000));

            // Simular respuesta exitosa
            const resultado = {
                exito: true,
                mensaje: `Se modificaron ${calificacionesModificadas.length} calificacion(es) correctamente`
            };

            if (resultado.exito) {
                // Actualizar calificaciones originales
                calificacionesCargadas.forEach((cal, index) => {
                    if (cal.hasOwnProperty('calificacionNueva')) {
                        calificacionesCargadas[index].calificacion = cal.calificacionNueva;
                        delete calificacionesCargadas[index].calificacionNueva;
                    }
                });

                calificacionesOriginales = JSON.parse(JSON.stringify(calificacionesCargadas));
                cambiosSinGuardar = false;

                // Mostrar mensaje de éxito usando función global
                mostrarDatosGuardados(resultado.mensaje, function () {
                    // Callback después de cerrar el modal
                    // Recargar tabla
                    renderizarTablaCalificaciones();
                    actualizarContadorModificados();
                });

            } else {
                // Mostrar error inline
                mostrarError(elementos.errorParcialMod, resultado.mensaje || 'Error al guardar las modificaciones');
            }

        } catch (error) {
            console.error('Error al guardar cambios:', error);
            mostrarError(elementos.errorParcialMod, 'Error al guardar las modificaciones. Intente nuevamente.');
        } finally {
            elementos.btnGuardarCambios.innerHTML = '<i class="fas fa-save me-2"></i>Guardar Cambios';
            actualizarEstadoBotones();
        }
    }

    /**
     * Maneja el clic en el botón cancelar
     */
    function handleCancelar() {
        if (cambiosSinGuardar) {
            // Mostrar modal de confirmación usando función global
            mostrarConfirmacion(
                'Hay cambios sin guardar. ¿Está seguro que desea cancelar?',
                function () {
                    // Usuario confirmó cancelar
                    confirmarCancelar();
                }
            );
        } else {
            confirmarCancelar();
        }
    }

    /**
     * Confirma la cancelación y cierra la vista
     */
    function confirmarCancelar() {
        limpiarTodo();
        // Redirigir a la vista principal de captura
        if (typeof option === 'function') {
            option('captura', '');
        }
    }


    /**
     * Limpia el formulario de edición
     */
    function limpiarFormulario() {
        calificacionesCargadas = [];
        calificacionesOriginales = [];
        cambiosSinGuardar = false;

        elementos.cuerpoCalificaciones.innerHTML = `
            <tr>
                <td colspan="6" class="text-center text-muted">
                    <i class="fas fa-info-circle fa-2x mb-2"></i>
                    <p class="mb-0">Seleccione parcial, horario y unidad, luego presione "Buscar Calificaciones"</p>
                </td>
            </tr>
        `;

        elementos.seccionTablaMod.style.display = 'none';
        elementos.seccionBotonesMod.style.display = 'none';
        elementos.mensajeSinCalificaciones.style.display = 'none';
        elementos.alertaSinCambios.style.display = 'none';
        elementos.alertaCambiosSinGuardar.style.display = 'none';

        elementos.contadorCalificaciones.textContent = '0';
        actualizarContadorModificados();
    }

    /**
     * Limpia todo el formulario incluyendo selectores
     */
    function limpiarTodo() {
        parcialSeleccionado = null;
        horarioSeleccionado = null;
        unidadSeleccionada = null;

        elementos.parcialSelect.value = '';
        elementos.horarioSelect.value = '';
        elementos.horarioSelect.disabled = true;
        elementos.unidadSelect.value = '';
        elementos.unidadSelect.disabled = true;

        elementos.infoHorarioMod.style.display = 'none';
        elementos.alertaParcialMod.style.display = 'none';

        limpiarFormulario();
    }

    /**
     * Muestra un mensaje de error inline
     */
    function mostrarError(elemento, mensaje) {
        if (elemento) {
            elemento.textContent = mensaje;
            elemento.style.display = 'block';
        }
    }

    /**
     * Oculta un mensaje de error inline
     */
    function ocultarError(elemento) {
        if (elemento) {
            elemento.textContent = '';
            elemento.style.display = 'none';
        }
    }

    // Exponer la función de inicialización
    return {
        inicializar: inicializar
    };

})();

// NO auto-inicializar - debe ser llamado manualmente cuando el HTML esté cargado
// Si necesitas inicialización automática, descomenta las siguientes líneas:
// if (document.readyState === 'loading') {
//     document.addEventListener('DOMContentLoaded', ModificarCalificaciones.inicializar);
// } else {
//     ModificarCalificaciones.inicializar();
// }

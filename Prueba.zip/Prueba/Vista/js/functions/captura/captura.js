//Autor Miguel Angel Lara H.
//Autor
//descripcion de funcionamiento
/**
 * desde este archivo se madan a vizualizar los ditintos sub modulos del camptura como la lista de parciales,
 * modificar calificacion
 * y capturar calificacion
 * ademas de funciones para mostrar informacion en la tabla de camptura dependiendo de los filtros que se establescan
 * parametros a utilizar
 * @param {*} opc
 * @param {*} id
 *
 */

function loadFormJcaptura(opc, id = "") {
  let url = "";
  if (opc === "cambioEstado") {
    url = "../modules/captura/LitsaParciales.php";
  }
  if (opc === "frmCaptura") {
    url = "../modules/CapturaYModificacion/frmCaptura.html";
  }
  if (opc === "modCaptura") {
    url = "../modules/CapturaYModificacion/modCaptura.html";
  }
  if (opc === "") {
    url = "";
  }

  let datas = { id: id };
  let container = $("#frmArea");

  container.fadeOut(300, function () {
    clearArea("frmArea");

    $.ajax({
      url: url,
      method: "POST",
      data: JSON.stringify(datas),
      contentType: "application/json; charset=utf-8",
      headers: {
        "X-Requested-With": "XMLHttpRequest",
      },

      success: function (responseText, status, xhr) {
        // --- PROTECCIÓN ANTI HTML ---
        if (
          typeof responseText === "string" &&
          (responseText.startsWith("<!DOCTYPE") ||
            responseText.startsWith("<html"))
        ) {
          console.warn("HTML detectado — posible sesión inválida.");
          window.location.href = "../login.php?estado=session_error";
          return;
        }

        container
          .html(responseText)
          .hide()
          .fadeIn(500, function () {
            // === Inicializar módulo Captura ===
            if (
              opc === "frmCaptura" &&
              typeof CapturaCalificaciones !== "undefined"
            ) {
              CapturaCalificaciones.inicializar();
            }

            // === Inicializar módulo Modificar ===
            if (
              opc === "modCaptura" &&
              typeof ModificarCalificaciones !== "undefined"
            ) {
              ModificarCalificaciones.inicializar(id);
            }
          })
          .css("transform", "translateY(-10px)")
          .animate(
            {
              opacity: 1,
              transform: "translateY(0px)",
            },
            300
          );
      },

      error: function (xhr, status, error) {
        // --- 401 SESIÓN INVÁLIDA ---
        if (xhr.status === 401) {
          let data;
          try {
            data = JSON.parse(xhr.responseText);
            window.location.href =
              "../login.php?estado=" + encodeURIComponent(data.reason);
          } catch (e) {
            window.location.href = "../login.php?estado=session_error";
          }
          return;
        }

        // --- 403 SIN PERMISOS ---
        if (xhr.status === 403) {
          container
            .html(
              `
      <div class="alert alert-warning mt-3">
        <h4>No tienes permisos para acceder a este formulario.</h4>
        <p>Contacta al administrador.</p>
      </div>
    `
            )
            .hide()
            .fadeIn(300);

          return;
        }

        // --- OTROS ERRORES ---
        mostrarErrorCaptura("Error de conexión: " + status + " - " + error);
      },
    });
  });
}

//Funcion para Obtener los valores del modal y manda a llamar a buscarCaptura(filtros = {})
async function tomarFiltros() {
  const filtros = {
    noControl: document.getElementById("filtroNoControl").value.trim(),
    nombre: document.getElementById("filtroNombre").value.trim(),
    parcial: document.getElementById("filtroParcial").value.trim(),
    carrera: document.getElementById("filtroCarrera").value.trim(),
    grupo: document.getElementById("filtroGrupo").value.trim(),
    grado: document.getElementById("filtroGrado").value.trim(),
  };

  console.log("Filtros tomados:", filtros);

  buscarCaptura(filtros);
}

// === FUNCIÓN PARA OBTENER Y CARGAR DATOS EN LA TABLA POR FILTROS ===
/***
 * Por medio de peticion fetch Se obtienen los datos para colocarlos los nuevos datos en la tabla
 */
async function buscarCaptura(filtros = {}) {
  const url =
    "../../Controlador/Intermediarios/Calificaciones/FiltrarCalificaciones.php";
  const modalError = new bootstrap.Modal(document.getElementById("modalError"));
  const mensajeError = document.getElementById("mensajeError");

  try {
    const modalFiltros = bootstrap.Modal.getInstance(
      document.getElementById("modalFiltros")
    );
    if (modalFiltros) modalFiltros.hide();

    mostrarLoader();

    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(filtros),
    });

    if (!response.ok) throw new Error("Error en la respuesta del servidor");

    const data = await response.json();

    if (!Array.isArray(data)) throw new Error("Formato de datos inválido");

    const dataNormalizada = data.map((item) => ({
      idCalificacion: item.clave_calificacion ?? "",
      noControl: item.numero_de_control,
      nombre: item.nombre_de_alumno,
      parcial: item.nombre_parcial ?? "",
      semestre: item.semestre,
      claveMateria: item.clave_de_materia,
      nombreMateria: item.nombre_de_materia,
      grupo: item.grupo,
      //!Remplazar el numero de control en la funcion mostrarDetalles por item.noControl una vez que el backend este listo y borrar este comentario
      opciones: `
    <div class="d-flex gap-2 justify-content-center">

        <button
            class="btn btn-primary btn-sm d-flex align-items-center px-3"
            onclick="loadFormJcaptura('modCaptura', '${item.clave_calificacion}')"
            title="Editar registro">
            <i class="fas fa-edit me-1"></i>
            Editar
        </button>

        <button
            class="btn btn-success btn-sm d-flex align-items-center px-3"
            
            onclick="mostrarDetalles('200112332')"
            title="Ver más información">
            <i class="fas fa-info-circle me-1"></i>
            Detalles
        </button>

    </div>
  `,
    }));

    const table = $("#tableCaptura").DataTable();
    table.clear();
    table.rows.add(dataNormalizada);
    table.draw();
  } catch (error) {
    console.error("Error al cargar datos:", error);
    mensajeError.textContent =
      error.message || "Ocurrió un error al cargar los datos.";
    modalError.show();
  } finally {
    ocultarLoader();
  }
}
// === FUNCIÓN PARA MOSTRAR DETALLES EN MODAL Unidades  ===
async function mostrarDetalles(noControl) {
  //! Remaplazar la url una vez que el backend este listo y borrar este comentario
  const url = "../../Controlador/Intermediarios/captura/Captura.php";
  try {
    mostrarLoader();

    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ noControl }),
    });

    const data = await response.json();

    if (!data || data.length === 0) {
      alert("No se encontraron detalles de calificaciones.");
      ocultarLoader();
      return;
    }

    // =============================
    //  LLENAR DATOS DEL MODAL
    // =============================
    document.getElementById("detalleNombreAlumno").textContent =
      data[0].nombreAlumno;

    document.getElementById("detalleNombreMateria").textContent =
      data[0].nombreMateria;

    let headerHTML = "";
    let valoresHTML = "";

    data.forEach((det) => {
      headerHTML += `<th>UND${det.unidad}</th>`;
      valoresHTML += `<td>${
        det.calificacion != null ? det.calificacion : "--"
      }</td>`;
    });

    // Agregar columna de calificación final
    headerHTML += `<th>Calificación Final</th>`;
    valoresHTML += `<td class="fw-bold">${data[0].calFinal ?? "--"}</td>`;

    document.getElementById("detalleHeaderUnidades").innerHTML = headerHTML;
    document.getElementById("detalleValoresUnidades").innerHTML = valoresHTML;

    new bootstrap.Modal(document.getElementById("modalDetalles")).show();
  } catch (error) {
    console.error("Error cargando detalles:", error);
  } finally {
    ocultarLoader();
  }
}

// funcion para subir archivo con fetch
async function subirArchivoConFetch(file, idUnico) {
  const item = document.querySelector(`.file-item[data-id="${idUnico}"]`);
  const status = item.querySelector(".file-status");
  const bar = item.querySelector(".progress-bar-custom");
  //*Colocar URl correcta
  const url = "../../Controlador/Intermediarios/captura/Captura.php";

  status.textContent = "Subiendo...";
  status.classList.add("text-warning");

  const formData = new FormData();
  formData.append("archivo", file);

  try {
    const response = await fetch(url, {
      method: "POST",
      body: formData,
    });

    const resultado = await response.json();

    // Validar error del backend
    if (!response.ok || !resultado.ok) {
      throw new Error(resultado.mensaje || "Error al subir archivo");
    }

    console.log(resultado);
    for (let p = 0; p <= 95; p += 8) {
      bar.style.width = p + "%";
      await new Promise((res) => setTimeout(res, 50));
    }

    // Empuje final exacto al 100%
    bar.style.width = "100%";

    status.textContent = "Completado ✓";
    status.classList.remove("text-warning");
    status.classList.add("text-success");
    btnUploadAll.disabled = true;
  } catch (error) {
    console.error("Error al subir archivo:", error);

    status.textContent = "Error al subir";
    status.classList.remove("text-warning");
    status.classList.add("text-danger");

    bar.style.width = "0%";
  }
}

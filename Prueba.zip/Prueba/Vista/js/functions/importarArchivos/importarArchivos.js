//Autor Miguel Angel Lara H.
// funcion de este archivo
/**
 * Funciones para importar archivos Excel con calificaciones
 * y mostrar una vista previa de los datos contenidos en el archivo
 * ademas de subir el archivo al servidor para su procesamiento
 */

/**
 * Funciones para Abrir el modal de Importacion de archivo
 * Solo cambiar las URL en los fetch Por las URL a utilizar
 * autor: Miguel Angel Lara Hermosillo
 */

(() => {
  let archivosSeleccionados = [];
  // ...
})();
/* ===============================================
   ABRIR MODAL Y PREPARAR TODO
================================================ */
function buscarArchivoImportado() {
  // Detectar si NO hay internet
  if (!navigator.onLine) {
    mostrarErrorInternet('No hay conexión a Internet. Verifique su conexión e inténtelo nuevamente.');
    return; //Detener ejecución
  }

  if (/Android|iPhone|iPad/i.test(navigator.userAgent)) {
    zonaCarga.style.display = "none";
  }

  const modalElement = document.getElementById("modalImportar");
  const modal = new bootstrap.Modal(modalElement);
  modal.show();

  inicializarImportador();
}
function mostrarErrorModal(mensajeError) {
  const mensaje = document.getElementById("mensajeError");
  mensaje.textContent =
    mensajeError || "Ocurrió un error, intente recargar la pagina.";

  const modalError = new bootstrap.Modal(document.getElementById("modalError"));
  modalError.show();
}

/* ===============================================
   INICIALIZAR TODO — LISTENERS DENTRO DEL MODAL
================================================ */
function inicializarImportador() {
  const dropZone = document.getElementById("dropZone");
  const fileInput = document.getElementById("fileInput");
  const fileList = document.getElementById("fileList");
  const btnUploadAll = document.getElementById("btnUploadAll");

  const modal = document.getElementById("modalImportar");

  modal.addEventListener("hidden.bs.modal", () => {
    archivosSeleccionados = [];
    fileList.innerHTML = "";
    fileInput.value = "";
  });

  archivosSeleccionados = [];
  fileList.innerHTML = "";
  btnUploadAll.disabled = true; // Bloquea al inicio

  dropZone.addEventListener("dragover", (e) => {
    e.preventDefault();
    dropZone.classList.add("active");
  });

  dropZone.addEventListener("dragleave", () =>
    dropZone.classList.remove("active")
  );

  dropZone.addEventListener("drop", (e) => {
    e.preventDefault();
    dropZone.classList.remove("active");
    manejarArchivos(e.dataTransfer.files);
    btnUploadAll.disabled = false; // Activar botón
  });

  fileInput.addEventListener("change", (e) => {
    manejarArchivos(e.target.files);
    btnUploadAll.disabled = false; // Activar botón
  });

  btnUploadAll.addEventListener("click", subirArchivoManual);
}

/* ===============================================
   MANEJAR ARCHIVOS 
================================================ */
function manejarArchivos(files) {
  // VALIDAR QUE EXISTA UN ARCHIVO
  if (!files || files.length === 0) {
    if (fileInput.value !== "") {
      console.warn("No se seleccionó archivo");
    }
    return;
  }

  const file = files[0]; // Solo tomar 1 archivo aunque arrastre varios

  // Validar tipo Excel
  if (!file.name.toLowerCase().match(/\.(xls|xlsx)$/)) {
    fileInput.value = "";
    mostrarErrorArchivo();
    return;
  }

  //Si ya existe un archivo, reemplazarlo
  if (archivosSeleccionados.length >= 1) {
    const anterior = archivosSeleccionados[0];
    eliminarArchivo(anterior.id); // eliminar del DOM y del arreglo
  }

  const id =
    self.crypto.randomUUID?.() ??
    "id-" + Math.random().toString(36).substring(2, 12);

  // Guardar nuevo archivo
  archivosSeleccionados = [{ file, id }];

  // Mostrar en lista
  mostrarArchivoEnLista(file, id);

  fileInput.value = ""; //Permite Seleccinar archivos nuevos
}
/* ===============================================
   sUBIR EL ARCHIVO AL PRECIONAR SOBRE EL BOTON
================================================ */
function subirArchivoManual() {
  // SI NO HAY ARCHIVO → ERROR
  if (archivosSeleccionados.length === 0) {
    mostrarErrorArchivo();

    return; // Detener todo
  }

  // AQUÍ SÍ EXISTE ARCHIVO SE SUBE
  const { file, id } = archivosSeleccionados[0];

  if (!window.USER_ROLE || !window.USER_ROLE.trim()) {
    mostrarErrorModal("USER_ROLE no definido. Intente recargar la página.");
    return;
  }

  const rol = USER_ROLE.trim();

  if (rol.trim() === "Administrador") {
    importarCalificacionesAdmin(file, id);
    return;
  } else if (rol.trim() === "JefeDeCarrera") {
    importarCalificacionesJefeCarrera(file, id);
    return;
  }
}

/* ===============================================
   MOSTRAR ARCHIVO EN LA LISTA + BOTÓN X
================================================ */
function mostrarArchivoEnLista(file, id) {
  const fileList = document.getElementById("fileList");
  fileList.style.color = "black";
  fileList.style.fontWeight = "bold";

  const item = document.createElement("div");
  item.classList.add("file-item");
  item.dataset.id = id;

  item.innerHTML = `
        <div class="file-info archivo-click">
            <i class="fas fa-file-excel text-primary fs-4"></i>
            <div>
                <div class="file-name fw-bold">${file.name}</div>
                <div class="file-size text-muted">${(file.size / 1024).toFixed(
                  2
                )} KB</div>
            </div>
        </div>

        <button class="btn btn-sm btn-outline-danger file-remove" data-id="${id}" id="removerArchivo">
            <i class="">Remover</i>
        </button>

        <div class="file-status text-muted mt-2">Pendiente</div>

        <div class="progress-container">
            <div class="progress-bar-custom"></div>
        </div>
    `;

  fileList.innerHTML = "";
  fileList.appendChild(item);

  // Botón X para eliminar archivo
  item.querySelector("#removerArchivo").addEventListener("click", () => {
    eliminarArchivo(id);
    archivosSeleccionados = [];
    fileList.innerHTML = "";
    btnUploadAll.disabled = true;
  });

  // Al hacer clic en el archivo abrir vista previa
  item.querySelector(".file-info").addEventListener("click", () => {
    mostrarVistaPrevia(file);
  });
}

/* ===============================================
   vista previa del documento 
================================================ */
function mostrarVistaPrevia(file) {
  const previewModal = new bootstrap.Modal(
    document.getElementById("modalPreview")
  );

  const tabla = document.getElementById("tablaVistaPrevia");
  tabla.innerHTML = `<tr><td class="text-muted">Cargando información...</td></tr>`;

  // Inputs
  const campoCalendario = document.getElementById("campoCalendario");
  const campoPlan = document.getElementById("campoPlan");
  const campoPrograma = document.getElementById("campoPrograma");
  const campoAsignatura = document.getElementById("campoAsignatura");
  const campoDocente = document.getElementById("campoDocente");
  const campoGrupo = document.getElementById("campoGrupo");

  // Limpiar
  campoCalendario.value =
    campoPlan.value =
    campoPrograma.value =
    campoAsignatura.value =
    campoDocente.value =
    campoGrupo.value =
      "";

  // Título del acta
  let tituloActa = document.getElementById("tituloActa");
  tituloActa.style.display = "none";

  const lector = new FileReader();

  lector.onload = function (e) {
    const datos = new Uint8Array(e.target.result);
    const workbook = XLSX.read(datos, { type: "array" });

    const hoja = workbook.Sheets[workbook.SheetNames[0]];
    const data = XLSX.utils.sheet_to_json(hoja, { header: 1 });

    data.forEach((fila) => {
      // NO destruir los espacios útiles
      let textoFila = fila.join(" ").trim();

      // TITULO
      if (textoFila.toUpperCase().includes("ACTA DE CALIFICACIONES")) {
        tituloActa.style.display = "block";
      }

      // CALENDARIO
      if (textoFila.toUpperCase().includes("CALENDARIO:")) {
        campoCalendario.value = textoFila
          .replace(/.*CALENDARIO:\s*/i, "")
          .trim();
      }

      // ASIGNATURA + GRUPO
      let asigMatch = textoFila.match(/ASIGNATURA[:\s]*\s*(.*?)\s*GRUPO[:\s]/i);
      if (asigMatch) campoAsignatura.value = asigMatch[1].trim();

      let grupoMatch = textoFila.match(/GRUPO[:\s]*([A-Z0-9]+)/i);
      if (grupoMatch) campoGrupo.value = grupoMatch[1].trim();

      // PROGRAMA + PLAN
      if (textoFila.toUpperCase().includes("PROGRAMA")) {
        let programa = textoFila.match(/PROGRAMA:\s*([^P]+)/i);
        if (programa) campoPrograma.value = programa[1].trim();

        let plan = textoFila.match(/PLAN:\s*([A-Z0-9-]+)/i);
        if (plan) campoPlan.value = plan[1].trim();
      }

      // DOCENTE
      if (textoFila.toUpperCase().includes("DOCENTE")) {
        campoDocente.value = textoFila.replace(/.*DOCENTE:\s*/i, "").trim();
      }
    });

    //ENCABEZADO DE TABLA

    const claves = ["MATRICULA", "ALUMNO", "UNIDAD", "PROM", "CALIF"];
    let filaEncabezado = -1;

    data.forEach((fila, i) => {
      if (fila.join(" ").toUpperCase().includes("MATRICULA")) {
        filaEncabezado = i;
      }
    });

    if (filaEncabezado === -1) {
      tabla.innerHTML = `<tr><td class="text-danger">No se detectó tabla válida</td></tr>`;
      return;
    }

    const encabezados = data[filaEncabezado];
    const registros = data.slice(filaEncabezado + 1);

    // CONSTRUIR TABLA

    let html = "<thead><tr>";
    encabezados.forEach((col) => (html += `<th>${col ?? ""}</th>`));
    html += "</tr></thead><tbody>";

    registros.forEach((fila) => {
      if (fila.every((c) => !c)) return;

      html += "<tr>";
      encabezados.forEach((_, i) => {
        html += `<td>${fila[i] ?? ""}</td>`;
      });
      html += "</tr>";
    });

    html += "</tbody>";
    tabla.innerHTML = html;
  };

  lector.readAsArrayBuffer(file);
  previewModal.show();
}

/* ===============================================
   ELIMINAR ARCHIVO
================================================ */
function eliminarArchivo(id) {
  const item = document.querySelector(`.file-item[data-id="${id}"]`);

  if (item) item.remove();

  archivosSeleccionados = archivosSeleccionados.filter((a) => a.id !== id);
}

/* ===============================================
   MOSTRAR ERROR DE ARCHIVOS NO PERMITIDOS---
================================================ */
function mostrarErrorArchivo() {
  const mensaje = document.getElementById("fileList");
  mensaje.textContent = "Solo se permiten archivos Excel (.xls o .xlsx).";
  mensaje.style.color = "red";
  mensaje.style.fontWeight = "bold";
}

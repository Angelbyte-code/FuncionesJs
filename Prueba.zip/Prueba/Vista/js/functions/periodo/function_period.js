let originalValues = {};

function loadFormPeriodo(id) {
    let container = $("#frmArea");
    let url =
        id === "none"
            ? "../modules/period/frmPeriod.php"
            : id === "mod"
                ? "../modules/period/modPeriodo.php?id="
                : "";

    if (!url) return;

    container.fadeOut(300, function () {
        clearArea("frmArea"); // Limpia el área antes de cargar contenido

        fetch(url, {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({id: id}),
        })
            .then((response) => response.text())
            .then((responseText) => {
                try {
                    container
                        .html(responseText)
                        .hide()
                        .fadeIn(500)
                        .css("transform", "translateY(-10px)")
                        .animate(
                            {
                                opacity: 1,
                                transform: "translateY(0px)",
                            },
                            300,
                            function () {

                                /*
                                // **Inicializar datepickers después de la animación**
                                $(".datepicker").datepicker({
                                    format: "yyyy-mm-dd",
                                    autoclose: true,
                                    language: "es",
                                });
                                */

                                // **Llamada al método para calcular el periodo**
                                obtenerPeriodo();

                                // Ahora agregamos el evento al campo txtPeriodo
                                const txtPeriodo = document.getElementById("txtPeriodo");

                                if (txtPeriodo) {
                                    txtPeriodo.addEventListener("input", function () {
                                        // En lugar de reemplazar automáticamente, llamamos a la función de validación
                                        validarCaracteres(this);
                                    });
                                }
                            }
                        );
                } catch (error) {
                    mostrarErrorCaptura("Error al cargar el formulario: " + error);
                }
            })
            .catch((error) => {
                mostrarErrorCaptura("Error de conexión: " + error);
            });
    });
}

/**
 * Función para cambiar el estado de un período con confirmación
 * @param {string} id - ID del período a modificar
 * @param {string} status - Nuevo estado seleccionado
 * @param {string} currentStatus - Estado actual del período
 */
function changeStatus(pid, pestado, currentStatus) {
    // Si no hay un estado seleccionado (opción por defecto), no hacer nada
    if (!pestado || pestado === "Cambiar estado") {
        return;
    }

    // Verificar si el estado actual es Cancelado o Cerrado
    if (currentStatus === "Cancelado" || currentStatus === "Cerrado") {
        // Mostrar mensaje de error
        mostrarErrorCaptura(
            `No se puede cambiar el estado del período ${pid} porque su estado actual es "${currentStatus}".`
        );

        // Resetear el select
        const selectElement = document.querySelector(
            `select[onchange="changeStatus('${pid}', this.value, '${currentStatus}')"]`
        );
        if (selectElement) {
            selectElement.selectedIndex = 0;
        }
        return;
    }

    // Crear el contenido del modal de confirmación
    let modalHTML = `
    <div class="modal fade" id="confirmStatusModal" tabindex="-1" aria-labelledby="confirmStatusModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-warning text-dark">
                    <h5 class="modal-title" id="confirmStatusModalLabel">
                        <i class="fas fa-exclamation-triangle me-2"></i>Confirmar cambio de estado
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="text-center mb-3">
                        <i class="fas fa-sync-alt text-warning fa-4x"></i>
                    </div>
                    <p class="text-center">¿Está seguro de cambiar el estado del período <strong>${pid}</strong> a <strong>${pestado}</strong>?</p>
                    <p class="text-center text-danger">Esta acción puede afectar a los procesos académicos en curso.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" id="btnCancelar">Cancelar</button>
                    <button type="button" class="btn btn-primary" id="btnConfirmar">Confirmar</button>
                </div>
            </div>
        </div>
    </div>`;

    // Remover modal anterior si existe
    let modalAnterior = document.getElementById("confirmStatusModal");
    if (modalAnterior) {
        modalAnterior.remove();
    }

    // Agregar el modal al documento
    document.body.insertAdjacentHTML("beforeend", modalHTML);

    // Mostrar el modal
    let modalElement = document.getElementById("confirmStatusModal");
    let modal = new bootstrap.Modal(modalElement);
    modal.show();

    // Configurar acción para el botón cancelar
    document.getElementById("btnCancelar").addEventListener("click", function () {
        // Resetear el select al cancelar
        const selectElement = document.querySelector(
            `select[onchange="changeStatus('${pid}', this.value, '${currentStatus}')"]`
        );
        if (selectElement) {
            selectElement.selectedIndex = 0;
        }
    });

    // También resetear al cerrar el modal con la X o haciendo clic fuera
    modalElement.addEventListener("hidden.bs.modal", function () {
        const selectElement = document.querySelector(
            `select[onchange="changeStatus('${pid}', this.value, '${currentStatus}')"]`
        );
        if (selectElement) {
            selectElement.selectedIndex = 0;
        }
        modalElement.remove();
    });

    // Configurar acción para el botón confirmar
    document
        .getElementById("btnConfirmar")
        .addEventListener("click", function () {
            // Cerrar el modal
            modal.hide();

            // Preparar datos para enviar
            let data = {
                pid: pid,
                pestado: pestado,
            };

            // Convertir a JSON
            let json = JSON.stringify(data);

            let url = "../../Controlador/Intermediarios/Periodo/CambiarEstado.php";

            // Enviar datos por json al script CambiarEsatdo.php
            $.post(url, json, function (responseText, status) {

                try {
                    // Verificar si la respuesta es JSON válido
                    let respuesta = JSON.parse(responseText.trim()); // Trim para eliminar cualquier espacio extra

                    if (respuesta.estado === "OK") {
                        mostrarDatosGuardados(
                            `El estado del período ${pid} ha sido cambiado a "${pestado}" correctamente.`,
                            function () {
                                // Recargar la tabla de periodos después de la actualización exitosa
                                goTo("period", "");
                            }
                        );
                    } else {
                        mostrarErrorCaptura(
                            respuesta.mensaje || "No se pudo cambiar el estado."
                        );
                    }
                } catch (error) {
                    // Mostrar el error y el contenido de la respuesta para depuración
                    console.error("Error al parsear JSON:", error);
                    console.error("Respuesta problemática:", responseText);
                    mostrarErrorCaptura(
                        "Error al Cambiar Estado. Por favor, inténtalo de nuevo más tarde. " +
                        error.message
                    );
                }
            }).fail(function (jqXHR, textStatus, errorThrown) {
                mostrarErrorCaptura(
                    "Hubo un error de conexión. Asegúrate de estar conectado a Internet e intenta nuevamente. " +
                    textStatus +
                    " - " +
                    errorThrown
                );
            });
        });
}

function AgregarPeriodo(mensaje) {
    // Obtener los valores de los campos del formulario
    const id = document.getElementById("txtId").value.trim();
    const periodo = document.getElementById("txtPeriodo").value.trim();
    const fechaInicio = document.getElementById("txtFechaInicio").value.trim();
    const fechaTermino = document.getElementById("txtFechaTermino").value.trim();
    const fechaInicioAjuste = document.getElementById("txtFechaInicioAjuste").value.trim();
    const fechaFinalAjuste = document.getElementById("txtFechaFinalAjuste").value.trim();

    // Validar que los campos no estén vacíos
    if (!periodo || !fechaInicio || !fechaTermino || !fechaInicioAjuste || !fechaFinalAjuste) {
        mostrarFaltaDatos("Algunos campos obligatorios están vacíos. Por favor revisa e ingrésalos antes de continuar.");
        return false;
    }

    // Validar el formato del campo periodo (solo letras, números, guion medio y espacio)
    const regexPeriodo = /^[A-Za-z0-9\- ]+$/;
    if (!regexPeriodo.test(periodo)) {
        mostrarErrorCaptura("El nombre del periodo solo puede contener letras, números, guiones y espacios. Ejemplo válido: 'Febrero 2025 - Julio 2025'.");
        return false;
    }

    // Llamar a la función de validación de fechas
    const resultadoValidacion = validarFechasAgregarPeriodo(
        periodo,
        fechaInicio,
        fechaTermino,
        fechaInicioAjuste,
        fechaFinalAjuste
    );

    // Si la validación de fechas falla, mostrar mensaje de error y detener el proceso
    if (resultadoValidacion !== true) {
        mostrarErrorCaptura(resultadoValidacion); // Mostrar mensaje de error
        return false; // Detener el proceso de guardado
    }

    //Guardar los datos del fomulario en la bd
    try {
        let url = "../../Controlador/Intermediarios/Periodo/AgregarPeriodo.php";
        let datos = new Object();
        datos.id = id;
        datos.periodo = periodo;
        datos.fechaInicio = fechaInicio;
        datos.fechaTermino = fechaTermino;
        datos.fechaInicioAjuste = fechaInicioAjuste;
        datos.fechaFinalAjuste = fechaFinalAjuste;

        let json = JSON.stringify(datos);

        $.post(url, json, function (responseText, status) {
            console.log("Datos a enviar:", JSON.stringify(datos));
            console.log("Texto de respuesta:", responseText);
            console.log("Tipo de respuesta:", typeof responseText);

            try {
                if (status === "success") {
                    // Verificar si la respuesta es una cadena que necesita ser parseada
                    let respuesta;
                    if (typeof responseText === 'string') {
                        // Limpiar cualquier espacio en blanco al inicio o final
                        responseText = responseText.trim();

                        // Verificar si la respuesta comienza con < (HTML)
                        if (responseText.startsWith('<')) {
                            console.error("Error: El servidor devolvió HTML en lugar de JSON");
                            console.error("Respuesta completa:", responseText);
                            mostrarErrorCaptura(
                                "Error del servidor: Se recibió una respuesta inválida. Por favor, verifica la consola del navegador para más detalles."
                            );
                            return false;
                        }

                        respuesta = JSON.parse(responseText);
                    } else {
                        respuesta = responseText;
                    }

                    console.log("Respuesta parseada:", respuesta);

                    if (respuesta.estado === "OK") {
                        mostrarDatosGuardados(mensaje, function () {
                            goTo("period", "");
                        });

                        console.log("Datos guardados correctamente en la BD.");
                    } else {
                        mostrarErrorCaptura(respuesta.mensaje);
                    }
                }
            } catch (error) {
                // Mostrar mensaje de error con el detalle del problema
                console.error("Error al procesar respuesta:", error);
                console.error("Respuesta que causó el error:", responseText);
                mostrarErrorCaptura(
                    "Error de Captura. El servidor devolvió una respuesta inválida. Verifica la consola para más detalles."
                );
                return false;
            }
        }).fail(function (jqXHR, textStatus, errorThrown) {
            // Mostrar mensaje de error con los detalles de la falla
            console.error("Error de conexión:", textStatus, errorThrown);
            console.error("Respuesta del servidor:", jqXHR.responseText);
            mostrarErrorCaptura(
                "Hubo un error de conexión. Asegúrate de estar conectado a Internet e intenta nuevamente. " +
                textStatus +
                " - " +
                errorThrown
            );
            return false;
        });
    } catch (error) {
        mostrarErrorCaptura(
            "Error de Captura. Ocurrio un error fatal. " + error.message
        );
        return false;
    }

    return true;
}

//Funcion para buscar periodo (JC)
function buscarPeriodo() {
    let id = document.getElementById("txtId").value.trim();
    let nombre = document.getElementById("txtPeriodo").value.trim();
    let url = "../../Controlador/Intermediarios/Periodo/ModificarPeriodo.php";

    let datos = id ? {id: id, buscar: true} : {nombre: nombre, buscar: true};
    let json = JSON.stringify(datos);

    $.post(
        url,
        json,
        function (response, status) {
            console.log("Respuesta del servidor:", response);

            if (status == "success") {
                console.log(
                    "Recibiendo datos:" +
                    response.datos.clave_periodo +
                    response.datos.periodo +
                    response.datos.fecha_de_inicio +
                    response.datos.fecha_de_termino +
                    response.datos.fecha_de_inicio_ajustes +
                    response.datos.fecha_de_termino_ajustes +
                    response.datos.estado
                );

                // Asigna los valores a los campos del formulario correctamente
                document.getElementById("txtId").value = response.datos.clave_periodo;
                document.getElementById("txtPeriodo").value = response.datos.periodo;
                document.getElementById("txtFechaInicio").value = response.datos.fecha_de_inicio;
                document.getElementById("txtFechaTermino").value = response.datos.fecha_de_termino;
                document.getElementById("txtFechaInicioAjuste").value = response.datos.fecha_de_inicio_ajustes;
                document.getElementById("txtFechaFinalAjuste").value = response.datos.fecha_de_termino_ajustes;
                document.getElementById("txtEstatus").value = response.datos.estado;

                if (
                    response.datos.estado === "Abierto" ||
                    response.datos.estado === "Pendiente"
                ) {
                    bloquearFormulario(false, true);

                    // Almacenar los valores originales después de que el formulario se ha llenado
                    storeOriginalValues();

                    // Configurar los listeners para detectar cambios
                    setupFormChangeListeners();
                } else {
                    errorActualizacion(
                        "No se puede modificar este periodo porque su estatus es: " +
                        response.datos.estado
                    );
                    bloquearFormulario(true, false);
                }
            } else {
                console.warn("No se encontraron datos válidos.");
                sinres("No se encontraron coincidencias.");
            }
        },
        "json" // Indica que la respuesta esperada es JSON
    ).fail(function (xhr, status, error) {
        // Manejo de error
        console.error("Error en la solicitud POST:", xhr.responseText);
        mostrarErrorCaptura("Error al buscar el periodo.");
    });
}

// Funcion para guardar periodo (JC)
function ModificarPeriodo(mensaje) {
    const estatus = document.getElementById("txtEstatus").value.trim();

    if (estatus !== "Abierto" && estatus !== "Pendiente") {
        errorActualizacion(
            "No se puede guardar cambios en este periodo porque su estatus es: " +
            estatus
        );
        return false;
    }
    //capturar los valores de los campos
    const id = document.getElementById("txtId").value.trim();
    const periodo = document.getElementById("txtPeriodo").value.trim();
    const fechaInicio = document.getElementById("txtFechaInicio").value.trim();
    const fechaTermino = document.getElementById("txtFechaTermino").value.trim();
    const fechaInicioAjuste = document.getElementById("txtFechaInicioAjuste").value.trim();
    const fechaFinalAjuste = document.getElementById("txtFechaFinalAjuste").value.trim();

    /*

    // Validar que los campos no estén vacíos
    if (!fechaInicio || !fechaTermino || !fechaInicioAjuste || !fechaFinalAjuste) {
        mostrarFaltaDatos("Algunos campos obligatorios están vacíos. Por favor revisa e ingrésalos antes de continuar.");
        return false;
    }

    */

    // Validar el formato del campo periodo (solo letras, números, guion medio y espacio)
    const regexPeriodo = /^[A-Za-z0-9\- ]+$/;
    if (!regexPeriodo.test(periodo)) {
        mostrarErrorCaptura("El nombre del periodo solo puede contener letras, números, guiones y espacios. Ejemplo válido: 'Febrero 2025 - Julio 2025'.");
        return false;
    }

    // Llamar a la función de validación de fechas
    const resultadoValidacion = validarFechasAgregarPeriodo(
        periodo,
        fechaInicio,
        fechaTermino,
        fechaInicioAjuste,
        fechaFinalAjuste
    );

    // Si la validación de fechas falla, mostrar mensaje de error y detener el proceso
    if (resultadoValidacion !== true) {
        mostrarErrorCaptura(resultadoValidacion); // Mostrar mensaje de error
        return false; // Detener el proceso de guardado
    }

    let datos = {
        idPeriodo: id,
        periodo: periodo,
        fechaInicio: fechaInicio,
        fechaTermino: fechaTermino,
        fechaInicioAjustes: fechaInicioAjuste,
        fechaTerminoAjustes: fechaFinalAjuste,
        guardar: true,
    };

    let json = JSON.stringify(datos);
    let url = "../../Controlador/Intermediarios/Periodo/ModificarPeriodo.php";

    $.post(
        url,
        json,
        function (response, status) {
            if (response.success) {
                console.log("Datos a enviar:", JSON.stringify(datos));
                mostrarDatosGuardados(mensaje, function () {
                    goTo("period", "");
                });
            } else {
                mostrarErrorCaptura("Error al Modificar el período.");
                return false;
            }
        },
        "json" // Indica que la respuesta esperada es JSON
    ).fail(function (xhr, status, error) {
        // Manejo de error
        console.error("Error en la solicitud POST:", xhr.responseText);
        mostrarErrorCaptura("Error al Modificar el periodo.");
    });

    return true;
}

/**
 * Función para obtener el Nombre del Periodo en base a la fecha que se obtiene del sistema
 */
function obtenerPeriodo() {
    let fechaActual = new Date();
    let mes = fechaActual.getMonth() + 1; // Enero = 0, por eso +1
    let anio = fechaActual.getFullYear();
    let periodo = "";

    if (mes >= 2 && mes <= 7) {
        // Próximo periodo después de Febrero-Julio -> Agosto-Enero
        periodo = `Agosto ${anio} - Enero ${anio + 1}`;
    } else {
        // Próximo periodo después de Agosto-Enero -> Febrero-Julio
        let anioPeriodo = (mes >= 8) ? anio + 1 : anio;
        periodo = `Febrero ${anioPeriodo} - Julio ${anioPeriodo}`;
    }

    // Asignar el nombre del periodo al campo de texto
    let txtPeriodo = document.getElementById("txtPeriodo");
    if (txtPeriodo) {
        txtPeriodo.value = periodo;
    }
}


// Función para validar las fechas de inicio y término según el tipo de periodo
function validarFechasAgregarPeriodo(
    periodo,
    fechaInicio,
    fechaTermino,
    fechaInicioAjuste,
    fechaTerminoAjuste
) {
    // Obtener la fecha actual
    const hoy = new Date();
    hoy.setHours(0, 0, 0, 0); // Resetear horas para comparación exacta

    const fecha_inicio = new Date(fechaInicio);
    const fecha_fin = new Date(fechaTermino);
    const fecha_inicio_ajuste = new Date(fechaInicioAjuste);
    const fecha_final_ajuste = new Date(fechaTerminoAjuste);

    // Validar periodo Febrero - Julio
    const regexFebrero = /^Febrero (\d{4}) - Julio (\d{4})$/;
    const matchFebrero = periodo.match(regexFebrero);

    if (matchFebrero) {
        const anio = parseInt(matchFebrero[1]);

        // Fechas límite para Febrero-Julio
        const inicio_min = new Date(Date.UTC(anio, 0, 1)); // 1 enero
        const inicio_max = new Date(Date.UTC(anio, 0, 31)); // 31 enero
        const fin_min = new Date(Date.UTC(anio, 5, 1)); // 1 junio
        const fin_max = new Date(Date.UTC(anio, 5, 30)); // 30 junio

        // Validar fecha de inicio
        if (fecha_inicio < hoy) {
            return "La fecha de inicio debe ser mayor a hoy.";
        }
        if (fecha_inicio < inicio_min || fecha_inicio > inicio_max) {
            return `La fecha de inicio debe estar entre el 01 y el 31 de enero del ${anio}.`;
        }
        if (fecha_inicio >= fecha_fin) {
            return "La fecha de inicio debe ser anterior a la fecha de término.";
        }

        // Validar fecha de término
        if (fecha_fin < hoy) {
            return "La fecha de término debe ser mayor a hoy.";
        }
        if (fecha_fin < fin_min || fecha_fin > fin_max) {
            return `La fecha de término debe estar entre el 01 y el 30 de junio del ${anio}.`;
        }
    } else {
        // Validar periodo Agosto - Enero
        const regexAgosto = /^Agosto (\d{4}) - Enero (\d{4})$/;
        const matchAgosto = periodo.match(regexAgosto);

        if (matchAgosto) {
            const anio_inicio = parseInt(matchAgosto[1]);

            // Fechas límite para Agosto-Enero
            const inicio_min = new Date(Date.UTC(anio_inicio, 7, 1)); // 1 agosto del año inicio
            const inicio_max = new Date(Date.UTC(anio_inicio, 7, 31)); // 31 agosto del año inicio
            const fin_min = new Date(Date.UTC(anio_inicio, 11, 1)); // 1 diciembre del año inicio
            const fin_max = new Date(Date.UTC(anio_inicio, 11, 31)); // 31 diciembre del año inicio

            // Validar fecha de inicio
            if (fecha_inicio < hoy) {
                return "La fecha de inicio debe ser mayor a hoy.";
            }
            if (fecha_inicio < inicio_min || fecha_inicio > inicio_max) {
                return `La fecha de inicio debe estar entre el 01 y el 31 de agosto del ${anio_inicio}.`;
            }
            if (fecha_inicio >= fecha_fin) {
                return "La fecha de inicio debe ser anterior a la fecha de término.";
            }

            // Validar fecha de término
            if (fecha_fin < hoy) {
                return "La fecha de término debe ser mayor a hoy.";
            }
            if (fecha_fin < fin_min || fecha_fin > fin_max) {
                return `La fecha de término debe estar entre el 01 y el 31 de diciembre del ${anio_inicio}.`;
            }
        } else {
            // Ningún formato válido
            return "El formato del nombre del periodo no es válido. Ejemplos correctos:\n- Febrero 2025 - Julio 2025\n- Agosto 2025 - Enero 2026";
        }
    }

    // Validar fecha de inicio de ajustes
    if (fecha_inicio_ajuste < fecha_inicio) {
        return "La fecha de inicio de ajustes no puede ser anterior a la fecha de inicio del periodo.";
    }

    const maxFechaInicioAjuste = new Date(fecha_inicio);
    maxFechaInicioAjuste.setDate(maxFechaInicioAjuste.getDate() + 7);

    if (fecha_inicio_ajuste > maxFechaInicioAjuste) {
        return "La fecha de inicio de ajustes no puede ser mayor a 7 días después del inicio del periodo.";
    }

    // Validar fecha de término de ajustes
    if (fecha_final_ajuste <= fecha_inicio_ajuste) {
        return "La fecha de término de ajustes debe ser posterior a la fecha de inicio de ajustes.";
    }

    const maxFechaFinalAjuste = new Date(fecha_inicio_ajuste);
    maxFechaFinalAjuste.setDate(maxFechaFinalAjuste.getDate() + 22);

    if (fecha_final_ajuste > maxFechaFinalAjuste) {
        return "La fecha de término de ajustes no puede ser mayor a 22 días después de la fecha de inicio de ajustes.";
    }

    return true; // Todas las validaciones pasaron
}


//Funcion de bloquear formulario (JC)
function bloquearFormulario(bloquearTodo, soloIDyPeriodo) {
    document.getElementById("txtId").disabled = soloIDyPeriodo || bloquearTodo;
    document.getElementById("txtPeriodo").disabled = soloIDyPeriodo || bloquearTodo;
    document.getElementById("txtFechaInicio").disabled = bloquearTodo;
    document.getElementById("txtFechaTermino").disabled = bloquearTodo;
    document.getElementById("txtFechaInicioAjuste").disabled = bloquearTodo;
    document.getElementById("txtFechaFinalAjuste").disabled = bloquearTodo;
    document.getElementById("btnActualizar").disabled = bloquearTodo;
}

function validarCaracteres(input) {
    // Patrón para permitir solo letras, números, espacios y guiones
    const patron = /^[A-Za-z0-9\s\-]*$/;

    // Obtener el botón de guardar
    const btnGuardar = document.querySelector('button[onclick*="validafrmPeriodo"]');

    // Verificar si el valor actual cumple con el patrón
    if (!patron.test(input.value)) {
        // Si hay caracteres no permitidos, mostrar mensaje de error
        input.setCustomValidity("Caracteres no permitidos");
        input.classList.add("is-invalid");
        document.getElementById("periodoFeedback").style.display = "block";

        // Desactivar el botón de guardar independientemente de otras modificaciones
        if (btnGuardar) {
            btnGuardar.disabled = true;
        }
    } else {
        // Si es válido, quitar mensaje de error
        input.setCustomValidity("");
        input.classList.remove("is-invalid");
        document.getElementById("periodoFeedback").style.display = "none";

        // Reactivar el botón de guardar cuando el input es válido
        if (btnGuardar) {
            btnGuardar.disabled = false;
        }

        // Verificar si el formulario ha sido modificado (para formulario de edición)
        checkFormModified();
    }
}

// Función para almacenar los valores originales después de cargar el formulario
function storeOriginalValues() {
    originalValues = {
        periodo: document.getElementById("txtPeriodo").value,
        fechaInicio: document.getElementById("txtFechaInicio").value,
        fechaTermino: document.getElementById("txtFechaTermino").value,
        fechaInicioAjuste: document.getElementById("txtFechaInicioAjuste").value,
        fechaFinalAjuste: document.getElementById("txtFechaFinalAjuste").value
    };

    // Inicialmente deshabilitamos el botón ya que no hay cambios (solo si existe)
    const btnActualizar = document.getElementById("btnActualizar");
    if (btnActualizar) {
        btnActualizar.disabled = true;
    }
}

// Función para verificar si el formulario ha sido modificado
function checkFormModified() {
    const currentValues = {
        periodo: document.getElementById("txtPeriodo").value,
        fechaInicio: document.getElementById("txtFechaInicio").value,
        fechaTermino: document.getElementById("txtFechaTermino").value,
        fechaInicioAjuste: document.getElementById("txtFechaInicioAjuste").value,
        fechaFinalAjuste: document.getElementById("txtFechaFinalAjuste").value
    };

    // Comparar cada valor
    const isModified =
        currentValues.periodo !== originalValues.periodo ||
        currentValues.fechaInicio !== originalValues.fechaInicio ||
        currentValues.fechaTermino !== originalValues.fechaTermino ||
        currentValues.fechaInicioAjuste !== originalValues.fechaInicioAjuste ||
        currentValues.fechaFinalAjuste !== originalValues.fechaFinalAjuste;

    // Habilitar/deshabilitar botón según el estado de modificación (solo si existe)
    const btnActualizar = document.getElementById("btnActualizar");
    if (btnActualizar) {
        btnActualizar.disabled = !isModified;
    }
}

// Función para agregar oyentes de eventos a todos los campos del formulario
function setupFormChangeListeners() {
    const formElements = [
        "txtPeriodo",
        "txtFechaInicio",
        "txtFechaTermino",
        "txtFechaInicioAjuste",
        "txtFechaFinalAjuste"
    ];

    formElements.forEach(elementId => {
        const element = document.getElementById(elementId);
        if (element) {
            // Usar evento input para campos de texto y change para fechas

            element.addEventListener("input", checkFormModified);
            element.addEventListener("change", checkFormModified);
        }
    });
}


<?php

//Autor Miguel Angel Lara Hermosillo
//Fecha 12-08-2025
/**
Funcionamiento: Este archivo verifica si el usuario ha iniciado sesión y lo redirige al panel correspondiente o al login.
 */
session_start();
require_once "config.php"; // si lo usas

// Si el usuario YA inició sesión → enviarlo a su panel
if (isset($_SESSION["rol"])) {
    header("Location: " . BASE_URL . "Vista/redirect.php");
    exit;
}

// Si NO tiene sesión → enviarlo al login
header("Location: " . BASE_URL . "Vista/login.php");
exit;

